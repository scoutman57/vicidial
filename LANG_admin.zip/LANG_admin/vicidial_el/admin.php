<?
# admin.php - VICIDIAL administration page
# 
# 
# Copyright (C) 2006  Matt Florell <vicidial@gmail.com>    LICENSE: GPLv2
#

require("dbconnect.php");

$PHP_AUTH_USER=$_SERVER['PHP_AUTH_USER'];
$PHP_AUTH_PW=$_SERVER['PHP_AUTH_PW'];
$PHP_SELF=$_SERVER['PHP_SELF'];
if (isset($_GET["ADD"]))				{$ADD=$_GET["ADD"];}
	elseif (isset($_POST["ADD"]))		{$ADD=$_POST["ADD"];}
if (isset($_GET["groups"]))				{$groups=$_GET["groups"];}
	elseif (isset($_POST["groups"]))		{$groups=$_POST["groups"];}
if (isset($_GET["remote_agent_id"]))				{$remote_agent_id=$_GET["remote_agent_id"];}
	elseif (isset($_POST["remote_agent_id"]))		{$remote_agent_id=$_POST["remote_agent_id"];}
if (isset($_GET["user"]))				{$user=$_GET["user"];}
	elseif (isset($_POST["user"]))		{$user=$_POST["user"];}
if (isset($_GET["pass"]))				{$pass=$_GET["pass"];}
	elseif (isset($_POST["pass"]))		{$pass=$_POST["pass"];}
if (isset($_GET["full_name"]))				{$full_name=$_GET["full_name"];}
	elseif (isset($_POST["full_name"]))		{$full_name=$_POST["full_name"];}
if (isset($_GET["user_level"]))				{$user_level=$_GET["user_level"];}
	elseif (isset($_POST["user_level"]))		{$user_level=$_POST["user_level"];}
if (isset($_GET["user_group"]))				{$user_group=$_GET["user_group"];}
	elseif (isset($_POST["user_group"]))		{$user_group=$_POST["user_group"];}
if (isset($_GET["campaign_id"]))				{$campaign_id=$_GET["campaign_id"];}
	elseif (isset($_POST["campaign_id"]))		{$campaign_id=$_POST["campaign_id"];}
if (isset($_GET["campaign_name"]))				{$campaign_name=$_GET["campaign_name"];}
	elseif (isset($_POST["campaign_name"]))		{$campaign_name=$_POST["campaign_name"];}
if (isset($_GET["active"]))				{$active=$_GET["active"];}
	elseif (isset($_POST["active"]))		{$active=$_POST["active"];}
if (isset($_GET["park_ext"]))				{$park_ext=$_GET["park_ext"];}
	elseif (isset($_POST["park_ext"]))		{$park_ext=$_POST["park_ext"];}
if (isset($_GET["park_file_name"]))				{$park_file_name=$_GET["park_file_name"];}
	elseif (isset($_POST["park_file_name"]))		{$park_file_name=$_POST["park_file_name"];}
if (isset($_GET["web_form_address"]))				{$web_form_address=$_GET["web_form_address"];}
	elseif (isset($_POST["web_form_address"]))		{$web_form_address=$_POST["web_form_address"];}
if (isset($_GET["allow_closers"]))				{$allow_closers=$_GET["allow_closers"];}
	elseif (isset($_POST["allow_closers"]))		{$allow_closers=$_POST["allow_closers"];}
if (isset($_GET["hopper_level"]))				{$hopper_level=$_GET["hopper_level"];}
	elseif (isset($_POST["hopper_level"]))		{$hopper_level=$_POST["hopper_level"];}
if (isset($_GET["auto_dial_level"]))				{$auto_dial_level=$_GET["auto_dial_level"];}
	elseif (isset($_POST["auto_dial_level"]))		{$auto_dial_level=$_POST["auto_dial_level"];}
if (isset($_GET["next_agent_call"]))				{$next_agent_call=$_GET["next_agent_call"];}
	elseif (isset($_POST["next_agent_call"]))		{$next_agent_call=$_POST["next_agent_call"];}
if (isset($_GET["local_call_time"]))				{$local_call_time=$_GET["local_call_time"];}
	elseif (isset($_POST["local_call_time"]))		{$local_call_time=$_POST["local_call_time"];}
if (isset($_GET["voicemail_ext"]))				{$voicemail_ext=$_GET["voicemail_ext"];}
	elseif (isset($_POST["voicemail_ext"]))		{$voicemail_ext=$_POST["voicemail_ext"];}
if (isset($_GET["submit"]))				{$submit=$_GET["submit"];}
	elseif (isset($_POST["submit"]))		{$submit=$_POST["submit"];}
if (isset($_GET["list_id"]))				{$list_id=$_GET["list_id"];}
	elseif (isset($_POST["list_id"]))		{$list_id=$_POST["list_id"];}
if (isset($_GET["list_name"]))				{$list_name=$_GET["list_name"];}
	elseif (isset($_POST["list_name"]))		{$list_name=$_POST["list_name"];}
if (isset($_GET["group_id"]))				{$group_id=$_GET["group_id"];}
	elseif (isset($_POST["group_id"]))		{$group_id=$_POST["group_id"];}
if (isset($_GET["group_name"]))				{$group_name=$_GET["group_name"];}
	elseif (isset($_POST["group_name"]))		{$group_name=$_POST["group_name"];}
if (isset($_GET["group_color"]))				{$group_color=$_GET["group_color"];}
	elseif (isset($_POST["group_color"]))		{$group_color=$_POST["group_color"];}
if (isset($_GET["fronter_display"]))				{$fronter_display=$_GET["fronter_display"];}
	elseif (isset($_POST["fronter_display"]))		{$fronter_display=$_POST["fronter_display"];}
if (isset($_GET["user_start"]))				{$user_start=$_GET["user_start"];}
	elseif (isset($_POST["user_start"]))		{$user_start=$_POST["user_start"];}
if (isset($_GET["number_of_lines"]))				{$number_of_lines=$_GET["number_of_lines"];}
	elseif (isset($_POST["number_of_lines"]))		{$number_of_lines=$_POST["number_of_lines"];}
if (isset($_GET["server_ip"]))				{$server_ip=$_GET["server_ip"];}
	elseif (isset($_POST["server_ip"]))		{$server_ip=$_POST["server_ip"];}
if (isset($_GET["conf_exten"]))				{$conf_exten=$_GET["conf_exten"];}
	elseif (isset($_POST["conf_exten"]))		{$conf_exten=$_POST["conf_exten"];}
if (isset($_GET["status"]))				{$status=$_GET["status"];}
	elseif (isset($_POST["status"]))		{$status=$_POST["status"];}
if (isset($_GET["group_name"]))				{$group_name=$_GET["group_name"];}
	elseif (isset($_POST["group_name"]))		{$group_name=$_POST["group_name"];}
if (isset($_GET["dial_status_a"]))				{$dial_status_a=$_GET["dial_status_a"];}
	elseif (isset($_POST["dial_status_a"]))		{$dial_status_a=$_POST["dial_status_a"];}
if (isset($_GET["dial_status_b"]))				{$dial_status_b=$_GET["dial_status_b"];}
	elseif (isset($_POST["dial_status_b"]))		{$dial_status_b=$_POST["dial_status_b"];}
if (isset($_GET["dial_status_c"]))				{$dial_status_c=$_GET["dial_status_c"];}
	elseif (isset($_POST["dial_status_c"]))		{$dial_status_c=$_POST["dial_status_c"];}
if (isset($_GET["dial_status_d"]))				{$dial_status_d=$_GET["dial_status_d"];}
	elseif (isset($_POST["dial_status_d"]))		{$dial_status_d=$_POST["dial_status_d"];}
if (isset($_GET["dial_status_e"]))				{$dial_status_e=$_GET["dial_status_e"];}
	elseif (isset($_POST["dial_status_e"]))		{$dial_status_e=$_POST["dial_status_e"];}
if (isset($_GET["lead_order"]))				{$lead_order=$_GET["lead_order"];}
	elseif (isset($_POST["lead_order"]))		{$lead_order=$_POST["lead_order"];}
if (isset($_GET["dial_timeout"]))				{$dial_timeout=$_GET["dial_timeout"];}
	elseif (isset($_POST["dial_timeout"]))		{$dial_timeout=$_POST["dial_timeout"];}
if (isset($_GET["dial_prefix"]))				{$dial_prefix=$_GET["dial_prefix"];}
	elseif (isset($_POST["dial_prefix"]))		{$dial_prefix=$_POST["dial_prefix"];}
if (isset($_GET["campaign_cid"]))				{$campaign_cid=$_GET["campaign_cid"];}
	elseif (isset($_POST["campaign_cid"]))		{$campaign_cid=$_POST["campaign_cid"];}
if (isset($_GET["campaign_vdad_exten"]))				{$campaign_vdad_exten=$_GET["campaign_vdad_exten"];}
	elseif (isset($_POST["campaign_vdad_exten"]))		{$campaign_vdad_exten=$_POST["campaign_vdad_exten"];}
if (isset($_GET["campaign_rec_exten"]))				{$campaign_rec_exten=$_GET["campaign_rec_exten"];}
	elseif (isset($_POST["campaign_rec_exten"]))		{$campaign_rec_exten=$_POST["campaign_rec_exten"];}
if (isset($_GET["campaign_recording"]))				{$campaign_recording=$_GET["campaign_recording"];}
	elseif (isset($_POST["campaign_recording"]))		{$campaign_recording=$_POST["campaign_recording"];}
if (isset($_GET["campaign_rec_filename"]))				{$campaign_rec_filename=$_GET["campaign_rec_filename"];}
	elseif (isset($_POST["campaign_rec_filename"]))		{$campaign_rec_filename=$_POST["campaign_rec_filename"];}
if (isset($_GET["hotkey"]))				{$hotkey=$_GET["hotkey"];}
	elseif (isset($_POST["hotkey"]))		{$hotkey=$_POST["hotkey"];}
if (isset($_GET["reset_list"]))				{$reset_list=$_GET["reset_list"];}
	elseif (isset($_POST["reset_list"]))		{$reset_list=$_POST["reset_list"];}
if (isset($_GET["old_campaign_id"]))				{$old_campaign_id=$_GET["old_campaign_id"];}
	elseif (isset($_POST["old_campaign_id"]))		{$old_campaign_id=$_POST["old_campaign_id"];}
if (isset($_GET["OLDuser_group"]))				{$OLDuser_group=$_GET["OLDuser_group"];}
	elseif (isset($_POST["OLDuser_group"]))		{$OLDuser_group=$_POST["OLDuser_group"];}
if (isset($_GET["status_name"]))				{$status_name=$_GET["status_name"];}
	elseif (isset($_POST["status_name"]))		{$status_name=$_POST["status_name"];}
if (isset($_GET["selectable"]))				{$selectable=$_GET["selectable"];}
	elseif (isset($_POST["selectable"]))		{$selectable=$_POST["selectable"];}
if (isset($_GET["HKstatus"]))				{$HKstatus=$_GET["HKstatus"];}
	elseif (isset($_POST["HKstatus"]))		{$HKstatus=$_POST["HKstatus"];}
if (isset($_GET["force_logout"]))				{$force_logout=$_GET["force_logout"];}
	elseif (isset($_POST["force_logout"]))		{$force_logout=$_POST["force_logout"];}
if (isset($_GET["phone_login"]))				{$phone_login=$_GET["phone_login"];}
	elseif (isset($_POST["phone_login"]))		{$phone_login=$_POST["phone_login"];}
if (isset($_GET["phone_pass"]))				{$phone_pass=$_GET["phone_pass"];}
	elseif (isset($_POST["phone_pass"]))		{$phone_pass=$_POST["phone_pass"];}
if (isset($_GET["delete_users"]))				{$delete_users=$_GET["delete_users"];}
	elseif (isset($_POST["delete_users"]))		{$delete_users=$_POST["delete_users"];}
if (isset($_GET["delete_user_groups"]))				{$delete_user_groups=$_GET["delete_user_groups"];}
	elseif (isset($_POST["delete_user_groups"]))		{$delete_user_groups=$_POST["delete_user_groups"];}
if (isset($_GET["delete_lists"]))				{$delete_lists=$_GET["delete_lists"];}
	elseif (isset($_POST["delete_lists"]))		{$delete_lists=$_POST["delete_lists"];}
if (isset($_GET["delete_campaigns"]))				{$delete_campaigns=$_GET["delete_campaigns"];}
	elseif (isset($_POST["delete_campaigns"]))		{$delete_campaigns=$_POST["delete_campaigns"];}
if (isset($_GET["delete_ingroups"]))				{$delete_ingroups=$_GET["delete_ingroups"];}
	elseif (isset($_POST["delete_ingroups"]))		{$delete_ingroups=$_POST["delete_ingroups"];}
if (isset($_GET["delete_remote_agents"]))				{$delete_remote_agents=$_GET["delete_remote_agents"];}
	elseif (isset($_POST["delete_remote_agents"]))		{$delete_remote_agents=$_POST["delete_remote_agents"];}
if (isset($_GET["load_leads"]))				{$load_leads=$_GET["load_leads"];}
	elseif (isset($_POST["load_leads"]))		{$load_leads=$_POST["load_leads"];}
if (isset($_GET["campaign_detail"]))				{$campaign_detail=$_GET["campaign_detail"];}
	elseif (isset($_POST["campaign_detail"]))		{$campaign_detail=$_POST["campaign_detail"];}
if (isset($_GET["ast_admin_access"]))				{$ast_admin_access=$_GET["ast_admin_access"];}
	elseif (isset($_POST["ast_admin_access"]))		{$ast_admin_access=$_POST["ast_admin_access"];}
if (isset($_GET["ast_delete_phones"]))				{$ast_delete_phones=$_GET["ast_delete_phones"];}
	elseif (isset($_POST["ast_delete_phones"]))		{$ast_delete_phones=$_POST["ast_delete_phones"];}
if (isset($_GET["CoNfIrM"]))				{$CoNfIrM=$_GET["CoNfIrM"];}
	elseif (isset($_POST["CoNfIrM"]))		{$CoNfIrM=$_POST["CoNfIrM"];}
if (isset($_GET["delete_scripts"]))				{$delete_scripts=$_GET["delete_scripts"];}
	elseif (isset($_POST["delete_scripts"]))		{$delete_scripts=$_POST["delete_scripts"];}
if (isset($_GET["script_id"]))				{$script_id=$_GET["script_id"];}
	elseif (isset($_POST["script_id"]))		{$script_id=$_POST["script_id"];}
if (isset($_GET["script_name"]))				{$script_name=$_GET["script_name"];}
	elseif (isset($_POST["script_name"]))		{$script_name=$_POST["script_name"];}
if (isset($_GET["script_comments"]))				{$script_comments=$_GET["script_comments"];}
	elseif (isset($_POST["script_comments"]))		{$script_comments=$_POST["script_comments"];}
if (isset($_GET["script_text"]))				{$script_text=$_GET["script_text"];}
	elseif (isset($_POST["script_text"]))		{$script_text=$_POST["script_text"];}
if (isset($_GET["reset_hopper"]))				{$reset_hopper=$_GET["reset_hopper"];}
	elseif (isset($_POST["reset_hopper"]))		{$reset_hopper=$_POST["reset_hopper"];}
if (isset($_GET["get_call_launch"]))				{$get_call_launch=$_GET["get_call_launch"];}
	elseif (isset($_POST["get_call_launch"]))		{$get_call_launch=$_POST["get_call_launch"];}
if (isset($_GET["am_message_exten"]))				{$am_message_exten=$_GET["am_message_exten"];}
	elseif (isset($_POST["am_message_exten"]))		{$am_message_exten=$_POST["am_message_exten"];}
if (isset($_GET["amd_send_to_vmx"]))				{$amd_send_to_vmx=$_GET["amd_send_to_vmx"];}
	elseif (isset($_POST["amd_send_to_vmx"]))		{$amd_send_to_vmx=$_POST["amd_send_to_vmx"];}
if (isset($_GET["xferconf_a_dtmf"]))				{$xferconf_a_dtmf=$_GET["xferconf_a_dtmf"];}
	elseif (isset($_POST["xferconf_a_dtmf"]))		{$xferconf_a_dtmf=$_POST["xferconf_a_dtmf"];}
if (isset($_GET["xferconf_a_number"]))				{$xferconf_a_number=$_GET["xferconf_a_number"];}
	elseif (isset($_POST["xferconf_a_number"]))		{$xferconf_a_number=$_POST["xferconf_a_number"];}
if (isset($_GET["xferconf_b_dtmf"]))				{$xferconf_b_dtmf=$_GET["xferconf_b_dtmf"];}
	elseif (isset($_POST["xferconf_b_dtmf"]))		{$xferconf_b_dtmf=$_POST["xferconf_b_dtmf"];}
if (isset($_GET["xferconf_b_number"]))				{$xferconf_b_number=$_GET["xferconf_b_number"];}
	elseif (isset($_POST["xferconf_b_number"]))		{$xferconf_b_number=$_POST["xferconf_b_number"];}
if (isset($_GET["modify_leads"]))				{$modify_leads=$_GET["modify_leads"];}
	elseif (isset($_POST["modify_leads"]))		{$modify_leads=$_POST["modify_leads"];}
if (isset($_GET["hotkeys_active"]))				{$hotkeys_active=$_GET["hotkeys_active"];}
	elseif (isset($_POST["hotkeys_active"]))		{$hotkeys_active=$_POST["hotkeys_active"];}
if (isset($_GET["change_agent_campaign"]))				{$change_agent_campaign=$_GET["change_agent_campaign"];}
	elseif (isset($_POST["change_agent_campaign"]))		{$change_agent_campaign=$_POST["change_agent_campaign"];}
if (isset($_GET["agent_choose_ingroups"]))				{$agent_choose_ingroups=$_GET["agent_choose_ingroups"];}
	elseif (isset($_POST["agent_choose_ingroups"]))		{$agent_choose_ingroups=$_POST["agent_choose_ingroups"];}
if (isset($_GET["alt_number_dialing"]))				{$alt_number_dialing=$_GET["alt_number_dialing"];}
	elseif (isset($_POST["alt_number_dialing"]))		{$alt_number_dialing=$_POST["alt_number_dialing"];}
if (isset($_GET["scheduled_callbacks"]))				{$scheduled_callbacks=$_GET["scheduled_callbacks"];}
	elseif (isset($_POST["scheduled_callbacks"]))		{$scheduled_callbacks=$_POST["scheduled_callbacks"];}
if (isset($_GET["lead_filter_id"]))				{$lead_filter_id=$_GET["lead_filter_id"];}
	elseif (isset($_POST["lead_filter_id"]))		{$lead_filter_id=$_POST["lead_filter_id"];}
if (isset($_GET["lead_filter_name"]))				{$lead_filter_name=$_GET["lead_filter_name"];}
	elseif (isset($_POST["lead_filter_name"]))		{$lead_filter_name=$_POST["lead_filter_name"];}
if (isset($_GET["lead_filter_comments"]))				{$lead_filter_comments=$_GET["lead_filter_comments"];}
	elseif (isset($_POST["lead_filter_comments"]))		{$lead_filter_comments=$_POST["lead_filter_comments"];}
if (isset($_GET["lead_filter_sql"]))				{$lead_filter_sql=$_GET["lead_filter_sql"];}
	elseif (isset($_POST["lead_filter_sql"]))		{$lead_filter_sql=$_POST["lead_filter_sql"];}
if (isset($_GET["agentonly_callbacks"]))				{$agentonly_callbacks=$_GET["agentonly_callbacks"];}
	elseif (isset($_POST["agentonly_callbacks"]))		{$agentonly_callbacks=$_POST["agentonly_callbacks"];}
if (isset($_GET["agentcall_manual"]))				{$agentcall_manual=$_GET["agentcall_manual"];}
	elseif (isset($_POST["agentcall_manual"]))		{$agentcall_manual=$_POST["agentcall_manual"];}
if (isset($_GET["vicidial_recording"]))				{$vicidial_recording=$_GET["vicidial_recording"];}
	elseif (isset($_POST["vicidial_recording"]))		{$vicidial_recording=$_POST["vicidial_recording"];}
if (isset($_GET["vicidial_transfers"]))				{$vicidial_transfers=$_GET["vicidial_transfers"];}
	elseif (isset($_POST["vicidial_transfers"]))		{$vicidial_transfers=$_POST["vicidial_transfers"];}
if (isset($_GET["delete_filters"]))				{$delete_filters=$_GET["delete_filters"];}
	elseif (isset($_POST["delete_filters"]))		{$delete_filters=$_POST["delete_filters"];}
if (isset($_GET["alter_agent_interface_options"]))	{$alter_agent_interface_options=$_GET["alter_agent_interface_options"];}
	elseif (isset($_POST["alter_agent_interface_options"]))		{$alter_agent_interface_options=$_POST["alter_agent_interface_options"];}
if (isset($_GET["closer_default_blended"]))				{$closer_default_blended=$_GET["closer_default_blended"];}
	elseif (isset($_POST["closer_default_blended"]))	{$closer_default_blended=$_POST["closer_default_blended"];}

	if (isset($script_id)) {$script_id= strtoupper($script_id);}
	if (isset($lead_filter_id)) {$lead_filter_id = strtoupper($lead_filter_id);}

# AST GUI database administration
# admin.php
# 
# CHANGES
# 50315-1110 - Added Custom Campaign Statuses
# 50317-1438 - Added Fronter Display var to inbound groups
# 50322-1355 - Added custom callerID per campaign
# 50517-1356 - Added user_groups sections and user_group to vicidial_users
# 50517-1440 - Added ability to logout (must click OK with empty user/pass)
# 50602-1622 - Added lead loader pages to load new files into vicidial_list
# 50620-1351 - Added custom vdad transfer AGI extension per campaign
# 50810-1414 - modified in groups to kick out spaces and dashes
# 50908-2136 - Added Custom Campaign HotKeys
# 50914-0950 - Fixed user search by user_group
# 50926-1358 - Modified to allow for language translation
# 50926-1615 - Added WeBRooTWritablE write controls
# 51020-1008 - Added editable web address and park ext - NEW dial campaigns
# 51020-1056 - Added fields and help for campaign recording control
# 51123-1335 - Altered code to function in php globals=off
# 51208-1038 - Added user_level changes, function controls and default user phones
# 51208-1556 - Added deletion of users/lists/campaigns/in groups/remote agents
# 51213-1706 - Added add/delete/modify vicidial scripts
# 51214-1737 - Added preview of vicidial script in popup window
# 51219-1225 - Added campaign and ingroups script selector and get_call_launch field
# 51222-1055 - Added am_message_exten to campaigns to allow for AM Message button
# 51222-1125 - Fixed new vicidial_campaigns default values not being assigned bug
# 51222-1156 - Added LOG OUT ALL AGENTS ON THIS CAMPAIGN button to campaign screen
# 60204-0659 - Fixed hopper reset bug
# 60207-1413 - Added AMD send to voicemail extension and xfer-conf dtmf presets
# 60213-1100 - Added several vicidial_users permissions fields
# 60215-1319 - Added On-hold CallBacks display and links
# 60227-1226 - Fixed vicidial_inbound_groups insert bug
# 60413-1308 - Fixed list display to have 1 row/status: count and time zone tables
#            - Added status name in selected dial statuses in campaign screen
# 60417-1416 - Added vicidial_lead_filters sections
#            - Changed the header links to color-coded sectional with sublinks below
#            - Added filter name and script name to campaign and in-group modify sections
#            - Added callback and alt dial options to campaigns section
#            - Added callback, alt dial and other options to users section
# 60419-1628 - Alter Callbacks display to include status and LIVE listings, reordered
# 60421-1441 - check GET/POST vars lines with isset to not trigger PHP NOTICES
# 60425-2355 - Added agent options to vicidial_users, reformatted user page
#

# make sure you have added a user to the vicidial_users MySQL table with at least user_level 8 to access this page the first time

$version = '1.1.10-10';
$build = '60425-2355';

$STARTtime = date("U");

if ($force_logout)
{
  if( (strlen($PHP_AUTH_USER)>0) or (strlen($PHP_AUTH_PW)>0) )
	{
    Header("WWW-Authenticate: Basic realm=\"VICI-PROJECTS\"");
    Header("HTTP/1.0 401 Unauthorized");
	}
    echo "Έχετε αποσυνδεθεί. Σας ευχαριστούμε\n";
    exit;
}

	$stmt="SELECT count(*) from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW' and user_level > 7;";
	if ($DB) {echo "|$stmt|\n";}
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$auth=$row[0];

if ($WeBRooTWritablE > 0)
	{$fp = fopen ("./project_auth_entries.txt", "a");}

$date = date("r");
$ip = getenv("REMOTE_ADDR");
$browser = getenv("HTTP_USER_AGENT");

  if( (strlen($PHP_AUTH_USER)<2) or (strlen($PHP_AUTH_PW)<2) or ($auth<1))
	{
    Header("WWW-Authenticate: Basic realm=\"VICI-PROJECTS\"");
    Header("HTTP/1.0 401 Unauthorized");
    echo "Ακυρο Ονομα Χρήστη/Κωδικός Πρόσβασης: |$PHP_AUTH_USER|$PHP_AUTH_PW|\n";
    exit;
	}
  else
	{

	if($auth>0)
		{
		$office_no=strtoupper($PHP_AUTH_USER);
		$password=strtoupper($PHP_AUTH_PW);
			$stmt="SELECT * from vicidial_users where user='$PHP_AUTH_USER' and pass='$PHP_AUTH_PW'";
			$rslt=mysql_query($stmt, $link);
			$row=mysql_fetch_row($rslt);
			$LOGfullname				=$row[3];
			$LOGuser_level				=$row[4];
			$LOGdelete_users			=$row[8];
			$LOGdelete_user_groups		=$row[9];
			$LOGdelete_lists			=$row[10];
			$LOGdelete_campaigns		=$row[11];
			$LOGdelete_ingroups			=$row[12];
			$LOGdelete_remote_agents	=$row[13];
			$LOGload_leads				=$row[14];
			$LOGcampaign_detail			=$row[15];
			$LOGdelete_scripts			=$row[18];
			$LOGdelete_filters			=$row[29];
			$LOGalter_agent_interface	=$row[30];

		if ($WeBRooTWritablE > 0)
			{
			fwrite ($fp, "VICIDIAL|GOOD|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|$LOGfullname|\n");
			fclose($fp);
			}
		}
	else
		{
		if ($WeBRooTWritablE > 0)
			{
			fwrite ($fp, "VICIDIAL|FAIL|$date|$PHP_AUTH_USER|$PHP_AUTH_PW|$ip|$browser|\n");
			fclose($fp);
			}
		}
	}

header ("Content-type: text/html; charset=utf-8");
echo "<html>\n";
echo "<head>\n";
echo "<!-- ΕΚΔΟΣΗ: $version   ΔΗΜΙΟΥΡΓΙΑ: $build   ADD: $ADD   PHP_SELF: $PHP_SELF-->\n";
echo "<title>VICIDIAL ΔΙΑΧ: ";

if (!isset($ADD))   {$ADD=0;}

if ($ADD==1)		{$hh='users';		echo "Πρόσθετε Νέο Χρήστη";}
if ($ADD==11)		{$hh='campaigns';	echo "Πρόσθετε Νέα Εκστρατεία";}
if ($ADD==111)		{$hh='lists';		echo "Πρόσθετε Νέα Λίστα";}
if ($ADD==1111)		{$hh='ingroups';	echo "Πρόσθετε Νέα Εισ-Ομάδα";}
if ($ADD==11111)	{$hh='remoteagent';	echo "Πρόσθετε Νέους Απομακρυσμένους Χρήστες";}
if ($ADD==111111)	{$hh='usergroups';	echo "Πρόσθετε Νέο Χρήστηs Group";}
if ($ADD==1111111)	{$hh='scripts';		echo "Προσθέστε το νέο χειρόγραφο";}
if ($ADD==11111111)	{$hh='filters';		echo "Προσθέστε το νέο φίλτρο";}
if ($ADD==2)		{$hh='users';		echo "Προσθήκη Νέου Χρήστη";}
if ($ADD==21)		{$hh='campaigns';	echo "Προσθήκη Νέας Εκστρατείας";}
if ($ADD==22)		{$hh='campaigns';	echo "Προσθήκη Νέας Κατάστασης Εκστρατείας";}
if ($ADD==23)		{$hh='campaigns';	echo "Προσθήκη Νέου Κλειδιού Εκστρατείας";}
if ($ADD==211)		{$hh='lists';		echo "Προσθήκη Νέας Λίστας";}
if ($ADD==2111)		{$hh='ingroups';	echo "Προσθήκη Νέας Εισ-Ομάδας";}
if ($ADD==21111)	{$hh='remoteagent';	echo "Προσθήκη Νέων Απομακρυσμένων Χρηστών";}
if ($ADD==211111)	{$hh='usergroups';	echo "Προσθήκη Νέας Ομάδας Χρηστών";}
if ($ADD==2111111)	{$hh='scripts';		echo "Νέα προσθήκη χειρογράφων";}
if ($ADD==21111111)	{$hh='filters';		echo "Νέα προσθήκη φίλτρων";}
if ($ADD==3)		{$hh='users';		echo "Τροποποίηση Χρήστη";}
if ($ADD==31)		{$hh='campaigns';	echo "Τροποποίηση Εκστρατείας";}
if ($ADD==34)		{$hh='campaigns';	echo "Τροποποίηση Εκστρατείας - Βασική Επισκόπηση";}
if ($ADD==311)		{$hh='lists';		echo "Τροποποίηση Λίστας";}
if ($ADD==3111)		{$hh='ingroups';	echo "Τροποποίηση Εισ-Ομάδων";}
if ($ADD==31111)	{$hh='remoteagent';	echo "Τροποποίηση Απομακρυσμένων Χρηστών";}
if ($ADD==311111)	{$hh='usergroups';	echo "Τροποποίηση Χρήστηs Groups";}
if ($ADD==3111111)	{$hh='scripts';		echo "Τροποποιήστε το χειρόγραφο";}
if ($ADD==31111111)	{$hh='filters';		echo "Τροποποιήστε το φίλτρο";}
if ($ADD=="4A")		{$hh='users';		echo "Τροποποίηση Χρήστη - Admin";}
if ($ADD=="4B")		{$hh='users';		echo "Τροποποίηση Χρήστη - Admin";}
if ($ADD==4)		{$hh='users';		echo "Τροποποίηση Χρήστη";}
if ($ADD==41)		{$hh='campaigns';	echo "Τροποποίηση Εκστρατείας";}
if ($ADD==42)		{$hh='campaigns';	echo "Τροποποίηση Εκστρατείας Status";}
if ($ADD==43)		{$hh='campaigns';	echo "Τροποποίηση Εκστρατείας HotKey";}
if ($ADD==44)		{$hh='campaigns';	echo "Τροποποίηση Εκστρατείας - Βασική Επισκόπηση";}
if ($ADD==411)		{$hh='lists';		echo "Τροποποίηση Λίστας";}
if ($ADD==4111)		{$hh='ingroups';	echo "Τροποποίηση Εισ-Ομάδων";}
if ($ADD==41111)	{$hh='remoteagent';	echo "Τροποποίηση Απομακρυσμένων Χρηστών";}
if ($ADD==411111)	{$hh='usergroups';	echo "Τροποποίηση Χρήστηs Groups";}
if ($ADD==4111111)	{$hh='scripts';		echo "Τροποποιήστε το χειρόγραφο";}
if ($ADD==41111111)	{$hh='filters';		echo "Τροποποιήστε το φίλτρο";}
if ($ADD==5)		{$hh='users';		echo "Delete User";}
if ($ADD==51)		{$hh='campaigns';	echo "Delete Εκστρατείας";}
if ($ADD==52)		{$hh='campaigns';	echo "Πράκτορες αποσύνδεσης";}
if ($ADD==511)		{$hh='lists';		echo "Delete List";}
if ($ADD==5111)		{$hh='ingroups';	echo "Delete In-Group";}
if ($ADD==51111)	{$hh='remoteagent';	echo "Διαγράψτε τους μακρινούς πράκτορες";}
if ($ADD==511111)	{$hh='usergroups';	echo "Διαγράψτε τους χρήστες Group";}
if ($ADD==5111111)	{$hh='scripts';		echo "Διαγράψτε το χειρόγραφο";}
if ($ADD==51111111)	{$hh='filters';		echo "Διαγράψτε το φίλτρο";}
if ($ADD==6)		{$hh='users';		echo "Delete User";}
if ($ADD==61)		{$hh='campaigns';	echo "Delete Εκστρατείας";}
if ($ADD==62)		{$hh='campaigns';	echo "Πράκτορες αποσύνδεσης";}
if ($ADD==611)		{$hh='lists';		echo "Delete List";}
if ($ADD==6111)		{$hh='ingroups';	echo "Delete In-Group";}
if ($ADD==61111)	{$hh='remoteagent';	echo "Διαγράψτε τους μακρινούς πράκτορες";}
if ($ADD==611111)	{$hh='usergroups';	echo "Διαγράψτε τους χρήστες Group";}
if ($ADD==6111111)	{$hh='scripts';		echo "Διαγράψτε το χειρόγραφο";}
if ($ADD==61111111)	{$hh='filters';		echo "Διαγράψτε το φίλτρο";}
if ($ADD==7111111)	{$hh='scripts';		echo "Χειρόγραφο πρόβλεψης";}
if ($ADD==0)		{$hh='users';		echo "Οι χρήστες απαριθμούν";}
if ($ADD==8)		{$hh='users';		echo "CallBacks μέσα στον πράκτορα";}
if ($ADD==81)		{$hh='campaigns';	echo "CallBacks μέσα στην εκστρατεία";}
if ($ADD==811)		{$hh='campaigns';	echo "CallBacks μέσα στον κατάλογο";}
if ($ADD==10)		{$hh='campaigns';	echo "Εκστρατείες";}
if ($ADD==100)		{$hh='lists';		echo "Λίστες";}
if ($ADD==1000)		{$hh='ingroups';	echo "Εισ-Ομάδες";}
if ($ADD==10000)	{$hh='remoteagent';	echo "Απομακρυσμένοι Χρήστες";}
if ($ADD==100000)	{$hh='usergroups';	echo "Ομάδες Χρήστη";}
if ($ADD==1000000)	{$hh='scripts';		echo "Χειρόγραφα";}
if ($ADD==10000000)	{$hh='filters';		echo "Φίλτρα";}
if ($ADD==55)		{$hh='users';		echo "Φόρμα Αναζήτησης";}
if ($ADD==66)		{$hh='users';		echo "Αποτελέσματα Αναζήτησης";}
if ($ADD==99999)	{$hh='users';		echo "ΒΟΗΘΕΙΑ";}

if ( ($ADD>9) && ($ADD < 99998) )
	{
	##### get scripts listing for dynamic pulldown
	$stmt="SELECT script_id,script_name from vicidial_scripts order by script_id";
	$rsltx=mysql_query($stmt, $link);
	$scripts_to_print = mysql_num_rows($rsltx);
	$scripts_list="<option value=\"\">NONE</option>\n";

	$o=0;
	while ($scripts_to_print > $o)
		{
		$rowx=mysql_fetch_row($rsltx);
		$scripts_list .= "<option value=\"$rowx[0]\">$rowx[0] - $rowx[1]</option>\n";
		$scriptname_list["$rowx[0]"] = "$rowx[1]";
		$o++;
		}

	##### get filters listing for dynamic pulldown
	$stmt="SELECT lead_filter_id,lead_filter_name,lead_filter_sql from vicidial_lead_filters order by lead_filter_id";
	$rsltx=mysql_query($stmt, $link);
	$filters_to_print = mysql_num_rows($rsltx);
	$filters_list="<option value=\"\">NONE</option>\n";

	$o=0;
	while ($filters_to_print > $o)
		{
		$rowx=mysql_fetch_row($rsltx);
		$filters_list .= "<option value=\"$rowx[0]\">$rowx[0] - $rowx[1]</option>\n";
		$filtername_list["$rowx[0]"] = "$rowx[1]";
		$filtersql_list["$rowx[0]"] = "$rowx[2]";
		$o++;
		}
	}

if ( ( (strlen($ADD)>4) && ($ADD < 99998) ) or ($ADD==3) or ($ADD=="4A")  or ($ADD=="4B") )
	{
	##### get server listing for dynamic pulldown
	$stmt="SELECT server_ip,server_description from servers order by server_ip";
	$rsltx=mysql_query($stmt, $link);
	$servers_to_print = mysql_num_rows($rsltx);
	$servers_list='';

	$o=0;
	while ($servers_to_print > $o)
		{
		$rowx=mysql_fetch_row($rsltx);
		$servers_list .= "<option value=\"$rowx[0]\">$rowx[0] - $rowx[1]</option>\n";
		$o++;
		}

	##### get campaigns listing for dynamic pulldown
	$stmt="SELECT campaign_id,campaign_name from vicidial_campaigns order by campaign_id";
	$rsltx=mysql_query($stmt, $link);
	$campaigns_to_print = mysql_num_rows($rsltx);
	$campaigns_list='';

	$o=0;
	while ($campaigns_to_print > $o)
		{
		$rowx=mysql_fetch_row($rsltx);
		$campaigns_list .= "<option value=\"$rowx[0]\">$rowx[0] - $rowx[1]</option>\n";
		$o++;
		}

	##### get inbound groups listing for checkboxes
	if ( (($ADD==31111) or ($ADD==31111)) and (count($groups)<1) )
	{
	$stmt="SELECT closer_campaigns from vicidial_remote_agents where remote_agent_id='$remote_agent_id';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$closer_campaigns =	$row[0];
	$closer_campaigns = preg_replace("/ -$/","",$closer_campaigns);
	$groups = explode(" ", $closer_campaigns);
	}

	if ($ADD==3)
	{
	$stmt="SELECT closer_campaigns from vicidial_users where user='$user';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$closer_campaigns =	$row[0];
	$closer_campaigns = preg_replace("/ -$/","",$closer_campaigns);
	$groups = explode(" ", $closer_campaigns);
	}

	$stmt="SELECT group_id,group_name from vicidial_inbound_groups order by group_id";
	$rsltx=mysql_query($stmt, $link);
	$groups_to_print = mysql_num_rows($rsltx);
	$groups_list='';
	$groups_value='';

	$o=0;
	while ($groups_to_print > $o)
		{
		$rowx=mysql_fetch_row($rsltx);
		$group_id_value = $rowx[0];
		$group_name_value = $rowx[1];
		$groups_list .= "<input type=\"checkbox\" name=\"groups[]\" value=\"$group_id_value\"";
		$p=0;
		while ($p<100)
			{
			if ($group_id_value == $groups[$p]) 
				{
				$groups_list .= " CHECKED";
				$groups_value .= " $group_id_value";
				}
			$p++;
			}
		$groups_list .= "> $group_id_value - $group_name_value<BR>\n";
		$o++;
		}
	if (strlen($groups_value)>2) {$groups_value .= " -";}
	}





$NWB = " &nbsp; <a href=\"javascript:openNewWindow('$PHP_SELF?ADD=99999";
$NWE = "')\"><IMG SRC=\"help.gif\" WIDTH=20 HEIGHT=20 BORDER=0 ALT=\"ΒΟΗΘΕΙΑ\" ALIGN=TOP></A>";
######################
# ADD=99999 display the HELP SCREENS
######################

if ($ADD==99999)
{
echo "</title>\n";
echo "</head>\n";
echo "<BODY BGCOLOR=white marginheight=0 marginwidth=0 leftmargin=0 topmargin=0>\n";
echo "<CENTER>\n";
echo "<TABLE WIDTH=98% BGCOLOR=#E6E6E6 cellpadding=2 cellspacing=0><TR><TD ALIGN=LEFT><FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=4><B>VICIDIAL ΔΙΑΧ: ΒΟΗΘΕΙΑ<BR></B></FONT><FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2><BR><BR>\n";

?>
<B><FONT SIZE=3>VICIDIAL_ΧΡΗΣΤΩΝ ΠΙΝΑΚΑΣ</FONT></B><BR><BR>
<A NAME="vicidial_users-user">
<BR>
<B>ID Χρήστη -</B> Σε αυτό το πεδίο τοποθετείται ο αριθμός ID του χρήστη, μπορεί να είναι μεταξ 2 και 8 ψηφία.

<BR>
<A NAME="vicidial_users-pass">
<BR>
<B>Κωδικός -</B> Σε αυτό το πεδίο τοποθετείται ο κωδικός του χρήστη στο VICIDIAL. Πρέπει να είναι τουλάχιστον 2 χαρακτήρες.

<BR>
<A NAME="vicidial_users-full_name">
<BR>
<B>Πλήρες Ονομα -</B> Αυτό το πεδίο είναι που μπορείτε να ορίσετε το πλήρες όνομα των χρηστών VICIDIAL. Πρέπει να είναι τουλάχιστον 2 χαρακτήρες.

<BR>
<A NAME="vicidial_users-user_level">
<BR>
<B>Επίπεδο Χρήστη -</B> Αυτός ο κατάλογος επιλογών είναι που μπορείτε να επιλέξετε το επίπεδο χρήστη των VICIDIAL χρηστών. Πρέπει να έχει επίπεδο 1 για να συνδεθεί στο σύστημα. Πρέπει να έχει επίπεδο μεγαλύτερο από 2 για να συνδεθεί ως closer. Πρέπει να έχει επίπεδο 8 ή μεγαλύτερο για ενέργειες διαχειριστή.

<BR>
<A NAME="vicidial_users-user_group">
<BR>
<B>Ομάδα Χρήστη -</B> Αυτός ο κατάλογος επιλογών είναι που μπορείτε να επιλέξετε την ομάδα χρηστών που ανήκει ο χρήστης.

<BR>
<A NAME="vicidial_users-phone_login">
<BR>
<B>Τηλεφωνική σύνδεση -</B> εδώ είναι όπου εσείς μπορεί να θέσει μια αξία τηλεφωνικής σύνδεσης προεπιλογής για όταν τα κούτσουρα χρηστών σε vicidial.php. Αυτή η αξία θα εποικήσει το phone_login αυτόματα όταν συνδέεται ο χρήστης με την χρήστης-πέρασμα-εκστρατεία τους στην οθόνη σύνδεσης vicidial.php.

<BR>
<A NAME="vicidial_users-phone_pass">
<BR>
<B>Τηλεφωνικό πέρασμα -</B> εδώ είναι όπου εσείς μπορεί να θέσει μια αξία τηλεφωνικών περασμάτων προεπιλογής για όταν τα κούτσουρα χρηστών σε vicidial.php. Αυτή η αξία θα εποικήσει τα phone_pass αυτόματα όταν συνδέεται ο χρήστης με την χρήστης-πέρασμα-εκστρατεία τους στην οθόνη σύνδεσης vicidial.php.

<BR>
<A NAME="vicidial_users-hotkeys_active">
<BR>
<B>HotKeys ενεργός -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο χρήστη για να χρησιμοποιήσει τη γρήγορος- dispositioning λειτουργία HotKeys μέσα vicidial.php.

<BR>
<A NAME="vicidial_users-agent_choose_ingroups">
<BR>
<B>Ο πράκτορας επιλέγει Ingroups -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο χρήστη για να επιλέξει τα ingroups ότι θα λάβουν τις κλήσεις από όταν αυτοί σύνδεση σε μια ΠΙΟ ΣΤΕΝΉ ή ΕΙΣΕΡΧΟΜΕΝΗ εκστρατεία. Διαφορετικά ο διευθυντής θα πρέπει να θέσει αυτό στην οθόνη λεπτομέρειας χρηστών τους της σελίδας admin.

<BR>
<A NAME="vicidial_users-closer_campaigns">
<BR>
<B>Εισερχόμενες Ομάδες -</B> Εδώ μπορείτε να επιλέξετε τις εισερχόμενες ομάδες που θέλετε να λαμβάνουν τις κλήσεις , εάν έχετε επιλέξει την εκστρατεία CLOSER.

<BR>
<A NAME="vicidial_users-scheduled_callbacks">
<BR>
<B>Σχέδισσες επανακλήσεις -</B> αυτή η επιλογή επιτρέπει σε έναν πράκτορα στη διάθεση μια κλήση ως CALLBK και επιλέγει τα στοιχεία και το χρόνο στους οποίους ο μόλυβδος θα επανενεργοποιηθεί.

<BR>
<A NAME="vicidial_users-agentonly_callbacks">
<BR>
<B>Πράκτορας-μόνο επανακλήσεις -</B> αυτή η επιλογή επιτρέπει σε έναν πράκτορα για να θέσει μια επανάκληση έτσι ώστε είναι ο μόνος πράκτορας που μπορεί να καλέσει την πλάτη πελατών. Αυτό επιτρέπει επίσης στον πράκτορα για να δει τις λίστες επανάκλησής τους και να τις καλέσει πίσω οποτεδήποτε θέλουν.

<BR>
<A NAME="vicidial_users-agentcall_manual">
<BR>
<B>Εγχειρίδιο κλήσης πρακτόρων -</B> αυτή η επιλογή επιτρέπει σε έναν πράκτορα για να εισαγάγει με το χέρι έναν νέο μόλυβδο στο σύστημα και να τους καλέσει. Αυτό επιτρέπει επίσης την κλήση οποιουδήποτε τηλεφωνικού αριθμού από την vicidial οθόνη τους και βάζει ότι κλήση στη σύνοδό τους. Χρησιμοποιήστε αυτήν την επιλογή με την προσοχή.

<BR>
<A NAME="vicidial_users-vicidial_recording">
<BR>
<B>Καταγραφή Vicidial -</B> αυτή η επιλογή μπορεί να αποτρέψει έναν πράκτορα από να κάνει οποιεσδήποτε καταγραφές αφότου συνδέονται σε vicidial. Αυτή η επιλογή πρέπει να είναι ανοικτή για vicidial να ακολουθηθεί η σύνοδος καταγραφής εκστρατείας.

<BR>
<A NAME="vicidial_users-vicidial_transfers">
<BR>
<B>Μεταφορές Vicidial -</B> αυτή η επιλογή μπορεί να αποτρέψει έναν πράκτορα από το άνοιγμα της μεταφοράς - σύνοδος διασκέψεων vicidial. Εάν αυτό είναι εκτός λειτουργίας, ο πράκτορας δεν μπορεί τρίτος να καλέσει ή τυφλή μεταφορά οποιεσδήποτε κλήσεις.

<BR>
<A NAME="vicidial_users-closer_default_blended">
<BR>
<B>Πιό στενή προεπιλογή που συνδυάζεται -</B> αυτή η επιλογή προκαθορίζει απλά το συνδυασμένο τετραγωνίδιο σε μια ΠΙΟ ΣΤΕΝΉ οθόνη σύνδεσης.

<BR>
<A NAME="vicidial_users-alter_agent_interface_options">
<BR>
<B>Αλλάξτε τις επιλογές διεπαφών πρακτόρων -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο διοικητικό χρήστη για να τροποποιήσει τις επιλογές διεπαφών πρακτόρων σε admin.php.

<BR>
<A NAME="vicidial_users-delete_users">
<BR>
<B>Διαγράψτε τους χρήστες -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο χρήστη για να διαγράψει άλλους χρήστες του ίσου ή του μικρότερου επιπέδου χρηστών από το σύστημα.

<BR>
<A NAME="vicidial_users-delete_user_groups">
<BR>
<B>Διαγράψτε τις ομάδες χρηστών -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο χρήστη για να διαγράψει τις ομάδες χρηστών από το σύστημα.

<BR>
<A NAME="vicidial_users-delete_lists">
<BR>
<B>Διαγράψτε τους καταλόγους -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο χρήστη για να διαγράψει τους vicidial καταλόγους από το σύστημα.

<BR>
<A NAME="vicidial_users-delete_campaigns">
<BR>
<B>Διαγράψτε τις εκστρατείες -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο χρήστη για να διαγράψει τις vicidial εκστρατείες από το σύστημα.

<BR>
<A NAME="vicidial_users-delete_ingroups">
<BR>
<B>Διαγράψτε τις-ΟΜΑΔΕΣ -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο χρήστη για να διαγράψει τις vicidial-OMA'DES από το σύστημα.

<BR>
<A NAME="vicidial_users-delete_remote_agents">
<BR>
<B>Διαγράψτε τους μακρινούς πράκτορες -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο χρήστη για να διαγράψει τους vicidial μακρινούς πράκτορες από το σύστημα.

<BR>
<A NAME="vicidial_users-load_leads">
<BR>
<B>Το φορτίο οδηγεί -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο χρήστη για να φορτώσει τους vicidial μολύβδους στον πίνακα vicidial_list μέσω του βασισμένου στον Ιστό φορτωτή μολύβδου.

<BR>
<A NAME="vicidial_users-campaign_detail">
<BR>
<B>Λεπτομέρεια εκστρατείας -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο χρήστη για να δει και να τροποποιήσει τα στοιχεία οθόνης λεπτομέρειας εκστρατείας.

<BR>
<A NAME="vicidial_users-ast_admin_access">
<BR>
<B>Πρόσβαση AGC Admin -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο χρήστη στη σύνδεση στις σελίδες admin astGUIclient.

<BR>
<A NAME="vicidial_users-ast_delete_phones">
<BR>
<B>Το AGC διαγράφει τα τηλέφωνα -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο χρήστη για να διαγράψει τα τηλεφωνικά λήμματα στις σελίδες admin astGUIclient.

<BR>
<A NAME="vicidial_users-delete_scripts">
<BR>
<B>Διαγράψτε τα χειρόγραφα -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο χρήστη για να διαγράψει τα χειρόγραφα εκστρατείας στην οθόνη τροποποίησης χειρογράφων.

<BR>
<A NAME="vicidial_users-modify_leads">
<BR>
<B>Τροποποιήστε τους μολύβδους -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο χρήστη για να τροποποιήσει τους μολύβδους στη σελίδα αποτελεσμάτων αναζήτησης μολύβδου τμημάτων admin.

<BR>
<A NAME="vicidial_users-change_agent_campaign">
<BR>
<B>Εκστρατεία πρακτόρων αλλαγής -</B> αυτή η επιλογή εάν θέστε 1 επιτρέπει στο χρήστη για να αλλάξει την εκστρατεία ότι ένας πράκτορας καταγράφεται ενώ καταγράφονται σε την.

<BR>
<A NAME="vicidial_users-delete_filters">
<BR>
<B>Διαγράψτε τα φίλτρα -</B> αυτή η επιλογή επιτρέπει στο χρήστη για να είναι σε θέση να διαγράψει τα vicidial φίλτρα μολύβδου από το σύστημα.




<BR><BR><BR><BR>

<B><FONT SIZE=3>VICIDIAL_ΕΚΣΤΡΑΤΕΙΩΝ ΠΙΝΑΚΑΣ</FONT></B><BR><BR>
<A NAME="vicidial_campaigns-campaign_id">
<BR>
<B>ID Εκστρατείας -</B> Αυτό είναι το σύντομο όνομα της εκστρατείας, δεν μπορεί ν διορθωθεί μετά από την αρχική παράδοση, δεν μπορεί να περιέχει κενά και πρέπει να είναι μεταξύ 2 και 8 χαρακτήρεςh.

<BR>
<A NAME="vicidial_campaigns-campaign_name">
<BR>
<B>Ονομα Εκστρατείας -</B> Αυτό είναι η περιγραφή της εκστρατείας, πρέπει να είναι μεταξύ 6 και 40 χαρακτήρες.

<BR>
<A NAME="vicidial_campaigns-active">
<BR>
<B>Ενεργοποίηση -</B> Εδώ μπορείτε να θέσετε την εκστρατεία ενεργή ή μη ενεργή. Εάν είναι μη ενεργή, κανένας δεν μπορεί να συνδεθεί σε αυτήν.

<BR>
<A NAME="vicidial_campaigns-park_ext">
<BR>
<B>Τηλ.Σύνδεση Στάθμευσης -</B> Εδώ μπορείτε να προσετε την μουσική αναμονής για το VICIDIAL. Επιβεβαιώστε, ότι η εσωτ.σύνδεση βρίσκεται στο extensions.conf και ότι δείχνει το αρχείο παρακάτω.

<BR>
<A NAME="vicidial_campaigns-park_file_name">
<BR>
<B>Ον Αρχείου Στάθμευσης -</B> Εδώ μπορείτε να προσαρμόσετε την μουσική αναμονής για το VICIDIAL. Επιβεβαιώστε ότι το αρχείο έχει 10 χαρακτήρες ή λιγότερους και ότι το αρχείο βρίσκεται στον κατάλογο /var/lib/asterisk/sounds.

<BR>
<A NAME="vicidial_campaigns-web_form_address">
<BR>
<B>Ιστοσελίδα -</B> Αυτή είναι η προσαρμοσμένη διεύθυνση που θα σας κατευθύνει για κλήσεις που έρχονται σε αυτήν την ομάδα.

<BR>
<A NAME="vicidial_campaigns-allow_closers">
<BR>
<B>Επιτρέπει τους Closers -</B> Εδώ ορίζετε εάν οι χρήστες της εκστρατείας θα έχουν την επιλογή να στείλουν την κλήση σε έναν closer.

<BR>
<A NAME="vicidial_campaigns-dial_status">
<BR>
<B>Κατάσταση Κλήσης -</B> Εδώ ορίζετε τις καταστάσεις που θέλετε να κληθούν μέσα στις λίστες, οι οποίες είναι ενεργές γ τις εκστρατείες παρακάτω

<BR>
<A NAME="vicidial_campaigns-lead_order">
<BR>
<B>Ταξινόμηση Λίστας -</B> Σε αυτόν τον κατάλογο επιλογών μπορείτε να επιλέξετε πώς οι καθοδηγητές, που ταιριάζουν με τις καταστάσεις που επιλέξατε παραπάνω, θα τοποθετηθούν hopper καθοδηγητών:
 <BR> &nbsp; - DOWN: επιλογή των πρώτων καθοδηγητών που φορτώθηκαν στον πίνακα vicidial_list
 <BR> &nbsp; - UP: επιλογή των τελευταίων καθοδηγητών που φορτώθηκαν στον πίνακα vicidial_list
 <BR> &nbsp; - UP PHONE: επιλογή του υψηλότερου τηλεφωνικού αριθμού και συνεχίζει προς τα κάτω
 <BR> &nbsp; - DOWN PHONE: επιλογή του χαμηλότερου τηλεφωνικού αριθμού και συνεχίζει προς τα πάνω
 <BR> &nbsp; - UP LAST NAME: έναρξη με τα επίθετα να ξεκινάνε με Ζ και συνεχίζει προς τα κάτω
 <BR> &nbsp; - DOWN LAST NAME: έναρξη με τα επίθετα να ξεκινάνε με Α και συνεχίζει προς τα πάνω
 <BR> &nbsp; - UP COUNT: έναρξη με τους λιγότερους σε κλήση καθοδηγητές και συνεχίζει προς τα κάτω
 <BR> &nbsp; - DOWN COUNT: έναρξη με τους λιγότερους σε κλήση καθοδηγητές και συνεχίζει
 <BR> &nbsp; - DOWN COUNT 2nd NEW: έναρξη με τους λιγότερους σε κλήση καθοδηγητές και συνεχίζει προς τα πάνω με την εισαγωγή ενός ΝΕΟΥ καθοδηγητή για κάθε άλλο καθοδηγητή - Πρέπει να ΜΗΝ έχει νέα επιλεγμένα στις καταστάσεις κλήσεων
 <BR> &nbsp; - DOWN COUNT 3nd NEW: έναρξη με τους λιγότερους σε κλήση καθοδηγητές και συνεχίζει προς τα πάνω με την εισαγωγή ενός ΝΕΟΥ καθοδηγητή για κάθε τρίτο καθοδηγητή - Πρέπει να ΜΗΝ έχει νέα επιλεγμένα στις καταστάσεις κλήσεων
 <BR> &nbsp; - DOWN COUNT 4th NEW: έναρξη με τους λιγότερους σε κλήση καθοδηγητές και συνεχίζει προς τα πάνω με την εισαγωγή ενός ΝΕΟΥ καθοδηγητή για κάθε τέταρτο καθοδηγητή - Πρέπει να ΜΗΝ έχει νέα επιλεγμένα στις καταστάσεις κλήσεων

<BR>
<A NAME="vicidial_campaigns-hopper_level">
<BR>
<B>Επίπεδο Hopper -</B> Αυτό είναι το πόσους καθοδηγητές η διαδικασία VDhopper, προσπαθεί να διατηρήσει στον πίνακα vicidial_hopper για αυτήν την εκστρατεία. Εάν η διαδικασία VDhopper τρέχει κάθε λεπτό, ρυθμίστε αυτό λίγο περισσότερο από τον αριθμό των καθοδηγητών που περνούν σε ένα λεπτό.

<BR>
<A NAME="vicidial_campaigns-lead_filter_id">
<BR>
<B>Φίλτρο μολύβδου -</B> αυτό είναι μια μέθοδος τους μολύβδους σας που χρησιμοποιούν ένα τεμάχιο μιας ερώτησης SQL. Χρησιμοποιήστε αυτό το χαρακτηριστικό γνώρισμα με την προσοχή, είναι εύκολο να σταματήσει τυχαία με τη μικρότερη αλλαγή στη δήλωση SQL. Η προεπιλογή δεν είναι ΚΑΜΙΑ.

<BR>
<A NAME="vicidial_campaigns-force_reset_hopper">
<BR>
<B>Υποχρεωτική Επαναφορά του Hopper -</B> Αυτό σας επιτρέπει καθαρίσετε τα περιεχόμενα κατά  επιβεβαίωση της φόρμας. Αυτό θα συμβεί πάλι όταν η διαδικασία VDhopper θα τρέξει.

<BR>
<A NAME="vicidial_campaigns-auto_dial_level">
<BR>
<B>Επίπεδο Αυτόματης Κλήσης -</B> Εδώ είναι που καθορίζεται πόσες γραμμές θα χρησιμοποιούνται ανά ενεργό χρήστη. Μηδέν (0) σημαίνει ότι η αυτόματη κλήση είναι μη ενεργή και οι χρήστες πατούν το πλήκτρο για την κλήση κάθε αριθμού. Διαφορετικά, το σύστημα καλεί γραμμές ίσες με τους ενεργούς χρήστες, πολλαπλασιασμένους με το επίπεδο κλήσης και σύμφωνα με το πόσες γραμμές η εκστρατεία σε κάθε διακομιστή επιτρέπει.

<BR>
<A NAME="vicidial_campaigns-next_agent_call">
<BR>
<B>Επόμενη Κλήση Χρήστη -</B> Αυτό προσδιορίζει ποιος χρήστης λαμβάνει την επόμενη κλήση που είναι διαθέσιμη:
 <BR> &nbsp; - random: ταξινομημένο με τυχαία τιμή ενημέρωσης στον πίνακα vicidial_live_agents
 <BR> &nbsp; - oldest_call_start: ταξινομημένο με την τελευταία φορά που σε ένα χρήστη στάλθηκε  μία κλήση. Με αποτέλεσμα, ο χρήστης να λαμβάνει συνολικά το ίδιο αριθμό κλήσεων.
 <BR> &nbsp; - oldest_call_finish: ταξινομημένο με την τελευταία φορά που ένας χρήστης τελείωσε μία κλήση. Ο χρήστης που περιμένει περισσότερο λαμβάνει την πρώτη κλήση.
 <BR> &nbsp; - overall_user_level: οι διαταγές από το user_level του πράκτορα όπως καθορίζεται στα vicidial_users παρουσιάζουν ένα υψηλότερο user_level θα λάβουν περισσότερες κλήσεις.

<BR>
<A NAME="vicidial_campaigns-local_call_time">
<BR>
<B>Τοπική Ωρα Κλήσης -</B> Εδώ, μπορείτε να ορίσετε τις ώρες που θα θέλατε να γίνουν οι κλήσεις. Αυτό ελέγχετε από τον κωδικό περις και ρυθμίζεται για Daylight Savings εάν είναι εφαρμόσιμο.

<BR>
<A NAME="vicidial_campaigns-voicemail_ext">
<BR>
<B>Φωνητικό Ταχυδρομείο -</B> Εάν έχει οριστεί, οι κλήσεις που φυσιολογικά θα γινόντουσαν DROP, θα κατευθυνθούν σε αυτό το φωνητικό ταχυδρομείο, ώστε να ακούσετε και να αφήσετε ένα μήνυμα.

<BR>
<A NAME="vicidial_campaigns-dial_timeout">
<BR>
<B>Κλήση Εκτός Χρόνου -</B> Εάν έχει οριστεί, οι κλήσεις που φυσιολογικά θα έκλειναν μετά το χρόνο που έχει οριστεί στο extensions.conf, θα κλείσουν σε αυτόν τον χρόνο εάν είναι μικρότερος του extensions.conf. Αυτό επιτρέπει στην γρήγορη αλλαγή των χρόνων από διακομιστή σε διακομιστή και περιορίζοντας τα αποτελέσματα σε μία εκστρατεία. Εάν έχετε πολλές κλήσεις με Αυτόματους Τηλεφωνητές ή Φωνητικών Ταχυδρομείων, μπορείτε να αλλάξετε αυτή την τιμή μεταξύ 21-26 και να δείτε αν τα αποτελέσματα είναι καλύτερα.

<BR>
<A NAME="vicidial_campaigns-dial_prefix">
<BR>
<B>Πρόθεμα Κλήσης -</B> Αυτό το ο επιτρέπει την πιο εύκολη αλλαγή της διαδρομής της κλήσης να βγει έξω μέσω διαφορετικής μεθόδου, χωρίς να γίνει επαναφόρτωση στο Asterisk. Προκαθορισμένο είναι το 9 βασισμένο σύμφωνα με το 91NXXNXXXXXX στο σχέδιο κλήσεων - extensions.conf.

<BR>
<A NAME="vicidial_campaigns-campaign_cid">
<BR>
<B>CallerID Εκστρατείας -</B> Αυτό το πεδίο επιτρέπει την αποστολεί ενός προσαρμοσμένου callerid αριθμού στις εξερχόμενες κλήσεις. Αυτός είναι ο αριθμός που θα εμφανιστεί στο callerid του προσώπου που καλείται. Το προκαθορισμένο είναι ΑΓΝΩΣΤΟ. Αυτή η επιλογή είναι διαθέσιμη μόνο εάν χρησιμοποιείται PRIs - ISDN T1s ή E1s - που έχουν προσαρμοσμένο callerid χαρακτηριστικό ενεργοποιημένο. Αυτό το χαρακτηριστικό μπορεί να δουλεύει και με IAX2 trunks εξαρτώμενο με το τι επιτρέπει ο παροχέας. Το προσαρμοσμένο callerID εφαρμόζεται μόνο σε κλήσεις που τοποθετήθηκαν απευθείας για την εκστρατεία VICIDIAL, οποιαδήποτε κλήση με 3 μέρη ή μεταφορές δεν θα το στείλουν.

<BR>
<A NAME="vicidial_campaigns-campaign_vdad_exten">
<BR>
<B>Τηλ.Σύνδεση Εκστρατείας VDAD -</B> Αυτό το πεδίο επιτρέπει γι μία προσαρμόσιμη VDAD  εσωτ.σύνδεση μεταφοράς. Αυτό σας επιτρέπει να χρησιμοποιήσετε διαφορετικές διαδικασίες VDADtransfer.agi, σύμφωνα με την εκστρατεία. Η προκαθορισμένη AGI μεταφορά - εσωτ.σύνδ. 8365 agi VDADtransfer.agi - στέλνει αμέσως τις κλήσεις στον χρήστη, μόλις το σηκώσουν. Ενα πρόσθετο AGI παράεα πολιτικής έρευνας συμπεριλαμβάνεται - 8366 agi - VDADtransferSURVEY.agi - όπου παίζει ένα μήνυμα στο κληθέν πρόσωπο και επιτρέπει να κάνουν επιλογές με τα πλήκτρα.

<BR>
<A NAME="vicidial_campaigns-campaign_rec_exten">
<BR>
<B>Επέκταση εκστρατείας REC -</B> αυτός ο τομέας επιτρέπει μια επέκταση καταγραφής συνήθειας που χρησιμοποιείται με VICIDIAL. Αυτό επιτρέπει σε σας για να χρησιμοποιήσει τις διαφορετικές επεκτάσεις ανάλογα με πόσο καιρό πολύ θέλετε να επιτρέψετε μια μέγιστη καταγραφή και ποιος τύπος κωδικοποιητή-αποκωδικοποιητή εσείς θέλει να καταγράψει μέσα. Η προεπιλογή είναι 8309 για τα οποία εάν ακολουθήσετε τα παραδείγματα SCRATCH_INSTALL θα καταγράψουν με το σχήμα WAV μέχρι μια ώρα. Μια άλλη επιλογή που περιλαμβάνεται στα παραδείγματα είναι 8310 που θα καταγράψουν με το σχήμα GSM για μέχρι μια ώρα.

<BR>
<A NAME="vicidial_campaigns-campaign_recording">
<BR>
<B>Καταγραφή εκστρατείας -</B> αυτές οι επιλογές επιτρέπουν σε σας για να επιλέξουν ποιο επίπεδο καταγραφής επιτρέπεται σε αυτήν την εκστρατεία. Δεν θα θέσει εκτός λειτουργίας ΠΟΤΕ την καταγραφή στον πελάτη. ONDEMAND είναι η προεπιλογή και επιτρέπει στον πράκτορα για να αρχίσει και να σταματήσει όπως απαιτείται. ALLCALLS θα αρχίσει την καταγραφή στον πελάτη όποτε μια κλήση στέλνεται σε έναν πράκτορα.

<BR>
<A NAME="vicidial_campaigns-campaign_rec_filename">
<BR>
<B>Όνομα αρχείου εκστρατείας REC -</B> αυτός ο τομέας επιτρέπει σε σας για να προσαρμόσει το όνομα της καταγραφής όταν η καταγραφή εκστρατείας είναι ONDEMAND ή ALLCALLS. Οι μεταβλητές είναι ΠΡΑΚΤΟΡΑΣ EPOCH FULLDATE TINYDATE ΕΚΣΤΡΑΤΕΙΑΣ CUSTPHONE. Η προεπιλογή είναι FULLDATE_ΠΡΑΚΤΟΡΑΣ και θα εμοίαζε με αυτά τα 20051020-103108_6666. Ένα άλλο παράδειγμα είναι CAMPAIGN_TINYDATE_CUSTPHONE που θα εμοίαζε με αυτό το TESTCAMP_51020103108_3125551212. 50 char max.

<BR>
<A NAME="vicidial_campaigns-campaign_script">
<BR>
<B>Χειρόγραφο εκστρατείας -</B> αυτές οι επιλογές επιτρέπουν σε σας για να επιλέξουν το χειρόγραφο που θα εμφανιστεί στην οθόνη πρακτόρων για αυτήν την εκστρατεία. Μην επιλέξτε NONE για να μην παρουσιάσετε κανένα χειρόγραφο για αυτήν την εκστρατεία.

<BR>
<A NAME="vicidial_campaigns-get_call_launch">
<BR>
<B>Πάρτε την έναρξη κλήσης -</B> αυτές οι επιλογές επιτρέπουν σε σας για να επιλέξουν εάν θέλετε την αυτόματος-έναρξη η σελίδα Ιστός-μορφής σε ένα χωριστό παράθυρο, αυτόματος-διακόπτης στην ετικέττα ΧΕΙΡΟΓΡΑΦΩΝ ή δεν κάνετε τίποτα όταν στέλνεται μια κλήση στον πράκτορα για αυτήν την εκστρατεία. 

<BR>
<A NAME="vicidial_campaigns-am_message_exten">
<BR>
<B>Μήνυμα αυτόματων τηλεφωνητών -</B> αυτός ο τομέας είναι για την είσοδο σε μια επέκταση στις τυφλές κλήσεις μεταφοράς όταν παίρνει ο πράκτορας έναν αυτόματο τηλεφωνητή και χτυπά στο κουμπί μηνυμάτων αυτόματων τηλεφωνητών στο πλαίσιο διασκέψεων μεταφοράς. Πρέπει να θέσετε αυτό επάνω στον dialplan - extensions.conf - και σιγουρεύεστε ότι παίζει ένα ακουστικό αρχείο κατόπιν κλείνει το τηλέφωνο. 

<BR>
<A NAME="vicidial_campaigns-amd_send_to_vmx">
<BR>
<B>AMD στέλνει στο VM -</B> αυτές οι επιλογές επιτρέπουν σε σας για να καθορίσουν εάν ένα μήνυμα αφήνεται σε έναν αυτόματο τηλεφωνητή όταν ανιχνεύεται ότι η κλήση θα διαβιβαστεί αμέσως στην επέκταση απαντώ-μηχανή-μηνυμάτων εάν AMD είναι ενεργό και καθορίζεται ότι η κλήση είναι ένας αυτόματος τηλεφωνητής.

<BR>
<A NAME="vicidial_campaigns-xferconf_a_dtmf">
<BR>
<B>Ξφερ- Conf DTMF -</B> αυτοί οι τέσσερις τομείς επιτρέπουν σας να έχουν δύο σύνολα διάσκεψης μεταφοράς και DTMF προετοιμάζει. Όταν η κλήση ή η εκστρατεία φορτώνεται, το χειρόγραφο vicidial.php θα παρουσιάσει δύο κουμπιά στο πλαίσιο μεταφορά-διασκέψεων και αυτόματος-θα εποικήσει τον αριθμός-ΠΊΝΑΚΑ και στείλετε -στέλνω-δτμφ τους τομείς όταν πιέζεται.

<BR>
<A NAME="vicidial_campaigns-alt_number_dialing">
<BR>
<B>Σχηματισμός πρακτόρων ALT Num -</B> αυτή η επιλογή επιτρέπει σε έναν πράκτορα για να σχηματίσει με το χέρι τον εναλλάσσομαι τηλεφωνικό αριθμό ή τον τομέα address3 αφότου έχει κληθεί ο κύριος αριθμός.

<BR>
<A NAME="vicidial_campaigns-scheduled_callbacks">
<BR>
<B>Σχέδισσες επανακλήσεις -</B> αυτή η επιλογή επιτρέπει σε έναν πράκτορα στη διάθεση μια κλήση ως CALLBK και επιλέγει τα στοιχεία και το χρόνο στους οποίους ο μόλυβδος θα επανενεργοποιηθεί.




<BR><BR><BR><BR>

<B><FONT SIZE=3>VICIDIAL_ΛΙΣΤΩΝ ΠΙΝΑΚΑΣ</FONT></B><BR><BR>
<A NAME="vicidial_lists-list_id">
<BR>
<B>ID Λίστας -</B> Αυτό είναι το αριθμητικό όνομα της λίστας, δεν μπορεί να διορθωθεί μετά από την αρχική παράδοση, πρέπει να περιέχει μόνο αριθμούς και πρέπει να είναι μεταξύ 2 και 8 χαρακτήρες.

<BR>
<A NAME="vicidial_lists-list_name">
<BR>
<B>Ονομα Λίστας -</B> Αυτή είναι η περιγραφή της λίστας, πρέπει να είναι μεταξύ 2 και 20 χαρακτήρες.

<BR>
<A NAME="vicidial_lists-campaign_id">
<BR>
<B>Εκστρατεία -</B> Αυτή είναι η εκστρατεία όπου ανήκει η λίστα. Μία λίστα μπορεί μόνο να κληθεί από μία εκστρατεία κάθε φορά.

<BR>
<A NAME="vicidial_lists-active">
<BR>
<B>Ενεργοποίηση -</B> Αυτό ορίζει κατά πόσον η λίστα πρόκειται να κληθεί ή όχι.

<BR>
<A NAME="vicidial_lists-reset_list">
<BR>
<B>Επαναφορά Κατάστασης-Κλήσης-Καθοδήγησης για την λίστα -</B> Αυτό επαναφέρει τις καθοδηγήσεις σε αυτή την λίστα στο Ν για \"μη κληθέντα  από την τελευταία επαναφορά\" και σημαίνει ότι για οποιαδήποτε καθοδήγηση μπορεί να γίνει κλήση εάν είναι η σωστή κατάσταση, όπως ορίσθηκε στην οθόνη της εκστρατείας.


<BR><BR><BR><BR>

<B><FONT SIZE=3>VICIDIAL_INBOUND_GROUPS ΠΙΝΑΚΑΣ</FONT></B><BR><BR>
<A NAME="vicidial_inbound_groups-group_id">
<BR>
<B>ID Ομάδας -</B> Αυτό είναι το σύντομο όνομα της εισερχόμενης ομάδας, δεν μπορεί να διορθωθεί μετά από την αρχική παράδοση, δεν μπορεί να περιέχει κενά και πρέπει να είναι μεταξύ 2 και 20χαρακτήρες.

<BR>
<A NAME="vicidial_inbound_groups-group_name">
<BR>
<B>Ονομα Ομάδας -</B> Αυτή είναι η περιγραφή της ομάδας, πρέπει να είναι μεταξύ 2 και 30 χαρακτήρες. Δεν μπορεί να συμπεριλαμβάνει παύλες, συν ή κενά .

<BR>
<A NAME="vicidial_inbound_groups-group_color">
<BR>
<B>Χρώμα Ομάδας -</B> Αυτό είναι το χρώμα που εμφανίζεται στην VICIDIAL  εφαρμογή όταν η κλήση έρχεται σε αυτή την ομάδα. Πρέπει να είναι μεταξύ 2 και 7 χαρακτήρες. Εάν αυτό είναι ορισμένο ως hex , θα πρέπει να τοποθετήσετε ένα # στην αρχή του κειμένου ή το VICIDIAL δεν θα δουλεύει σωστά.

<BR>
<A NAME="vicidial_inbound_groups-active">
<BR>
<B>Ενεργοποίηση -</B> Αυτό καθορίζει κατά πόσον αυτή η ομάδα εμφανίζεται στο κουτί επιλογής όταν ένας χρήστης συνδέεται.

<BR>
<A NAME="vicidial_inbound_groups-web_form_address">
<BR>
<B>Ιστοσελίδα -</B> Αυτή είναι η προσαρμοσμένη διεύθυνση που θα σας κατευθύνει για κλήσεις που έρχονται σε αυ την ομάδα.

<BR>
<A NAME="vicidial_inbound_groups-voicemail_ext">
<BR>
<B>Φωνητικό Ταχυδρομείο -</B> Εάν ορίζεται, αυτό είναι το περιεχόμενο φωνητικού ταχυδρομείου όπου οι κλήσεις θα πηγαίνουν, αντί να γίνονται dropped εάν δεν υπάρχουν διαθέσιμοι χρήστες μετά τον χρόνο αναμονής.

<BR>
<A NAME="vicidial_inbound_groups-next_agent_call">
<BR>
<B>Επόμενη Κλήση Χρήστη -</B> Αυτό προσδιορίζει ποιος χρήστης λαμβάνει την επόμενη κλήση που είναι διαθέσιμη:
 <BR> &nbsp; - random: ταξινομημένο με τυχαία τιμή ενημέρωσης στον πίνακα vicidial_live_agents
 <BR> &nbsp; - oldest_call_start: ταξινομημένο με την τελευταία φορά που σε ένα χρήστη στάλθηκε  μία κλήση. Με αποτέλεσμα, ο χρήστης να λαμβάνει συνολικά το ίδιο αριθμό κλήσεων.
 <BR> &nbsp; - oldest_call_finish: ταξινομημένο με την τελευταία φορά που ένας χρήστης τελείωσε μία κλήση. Ο χρήστης που περιμένει περισσότερο λαμβάνει την πρώτη κλήση.
 <BR> &nbsp; - overall_user_level: οι διαταγές από το user_level του πράκτορα όπως καθορίζεται στα vicidial_users παρουσιάζουν ένα υψηλότερο user_level θα λάβουν περισσότερες κλήσεις.

<BR>
<A NAME="vicidial_inbound_groups-fronter_display">
<BR>
<B>Οθόνη Μπροστινού -</B> Αυτό το πεδίο καθορίζει κατά πόσον στον VICIDIAL  χόμενος χρήστης θα εμφανίζεται το όνομα του μπροστινού - εάν υπάρχει κάποιο - στο πεδίο κατάστασης όταν η κλήση έρχεται στον χρήστη.

<BR>
<A NAME="vicidial_inbound_groups-ingroup_script">
<BR>
<B>Χειρόγραφο εκστρατείας -</B> αυτές οι επιλογές επιτρέπουν σε σας για να επιλέξουν το χειρόγραφο που θα εμφανιστεί στην οθόνη πρακτόρων για αυτήν την εκστρατεία. Μην επιλέξτε NONE για να μην παρουσιάσετε κανένα χειρόγραφο για αυτήν την εκστρατεία.

<BR>
<A NAME="vicidial_inbound_groups-get_call_launch">
<BR>
<B>Πάρτε την έναρξη κλήσης -</B> αυτές οι επιλογές επιτρέπουν σε σας για να επιλέξουν εάν θέλετε την αυτόματος-έναρξη η σελίδα Ιστός-μορφής σε ένα χωριστό παράθυρο, αυτόματος-διακόπτης στην ετικέττα ΧΕΙΡΟΓΡΑΦΩΝ ή δεν κάνετε τίποτα όταν στέλνεται μια κλήση στον πράκτορα για αυτήν την εκστρατεία. 

<BR>
<A NAME="vicidial_inbound_groups-xferconf_a_dtmf">
<BR>
<B>Ξφερ- Conf DTMF -</B> αυτοί οι τέσσερις τομείς επιτρέπουν σας να έχουν δύο σύνολα διάσκεψης μεταφοράς και DTMF προετοιμάζει. Όταν η κλήση ή η εκστρατεία φορτώνεται, το χειρόγραφο vicidial.php θα παρουσιάσει δύο κουμπιά στο πλαίσιο μεταφορά-διασκέψεων και αυτόματος-θα εποικήσει τον αριθμός-ΠΊΝΑΚΑ και στείλετε -στέλνω-δτμφ τους τομείς όταν πιέζεται.




<BR><BR><BR><BR>

<B><FONT SIZE=3>VICIDIAL_REMOTE_AGENTS ΠΙΝΑΚΑΣ</FONT></B><BR><BR>
<A NAME="vicidial_remote_agents-user_start">
<BR>
<B>Αρχή ID Χρήστη -</B> Αυτό είναι η αρχή του ID Χρήστη που χρησιμοποιείται όταν οι καταχωρήσεις των απομακρυσμένων χρηστών παρεμβάλλονται στο σύστημα. Εάν ο αριθμός των γραμμών είναι μεγαλύτερος από 1, αυτός ο αριθμός αυξάνει κατά ένα μέχρι κάθε γραμμή να έχει μία καταχώρηση. Επιβεβαιώστε, ότι δημιουργήσατε ένα νέο VICIDIAL λογαριασμό η  με επίπεδο χρήσης 4 ή μεγαλύτερο, εάν θέλετε να μπορεί να χρησιμοποιήσει την σελίδα vdremote για απομακρυσμένη πρόσβαση του λογαριασμού του.

<BR>
<A NAME="vicidial_remote_agents-number_of_lines">
<BR>
<B>Αριθμός Γραμμών -</B> Αυτό ορίζει πόσες καταχωρήσεις απομακρυσμένων χρηστών το σύστημα δημιουρ, και καθορίζει πόσες γραμμές μπορεί με ασφάλεια να στείλει στον αριθμό παρακάτω.

<BR>
<A NAME="vicidial_remote_agents-server_ip">
<BR>
<B>IP Διακομιστή -</B> Μία καταχώρηση απομακρυσμένου χρήστη είναι μόνο καλό για ένα συγκεκριμένο διακομιστή, εδώ είναι που επιλέ τον διακομιστή που ανήκει.

<BR>
<A NAME="vicidial_remote_agents-conf_exten">
<BR>
<B>Εξωτερική Τηλ.Σύνδεση -</B> Αυτός είναι ο αριθμός που θέλετε οι κλήσεις να προωθούνται. Επιβεβαιώστε ότι είναι ένας πλήρης αριθμός από το σχέδιο κλήσεων και εάν θέλετε ένα 9 στην αρχή το βάζετε εδώ. Κάντε μία δοκιμή καλώντας αυτόν τον αριθμό από ένα τηλέφωνο του συστήματος.

<BR>
<A NAME="vicidial_remote_agents-status">
<BR>
<B>Κατάσταση -</B> Εδώ μπορείτε να θέσετε τον απομακρυσμένο χρήστη σε ενεργό και μη ενεργό. Μόλις ο χρήστης γίνει ενεργός το σύστημα μπορεί να στείλει κλήσεις σε αυτόν. Μπορεί να διαρκέσει μέχρι 30 δευτερόλεπτα μετά την αλλαγή της κατάστασης σε μη ενεργός, ώστε να σταματήσει να δέχεται κς.

<BR>
<A NAME="vicidial_remote_agents-campaign_id">
<BR>
<B>Εκστρατεία -</B> Εδώ μπο να επιλέξετε την εκστρατεία όπου οι απομακρυσμένοι χρήστες θα συνδεθούν. Για εισερχόμενες πρέπει να χρησιμοποιηθεί η εκστρατεία CLOSER και επιλέξτε τις εισερχόμενες εκστρατείες παρακάτω, από που θέλετε να λαμβάνεται τις κλήσεις.

<BR>
<A NAME="vicidial_remote_agents-closer_campaigns">
<BR>
<B>Εισερχόμενες Ομάδες -</B> Εδώ μπορείτε να επιλέξετε τις εισερχόμενες ομάδες που θέλετε να λαμβάνουν τις κλήσεις , εάν έχετε επιλέξει την εκστρατεία CLOSER.


<BR><BR><BR><BR>

<B><FONT SIZE=3>VICIDIAL_CAMPAIGN_ΛΙΣΤΩΝ</FONT></B><BR><BR>
<A NAME="vicidial_campaign_lists">
<BR>
<B>Οι λίστες της εκστρατείας παρουσιάζονται εδώ,  και εάν είναι ενεργές δηαι με Υ ή Ν και μπορείτε να πάτε στην οθόνη λίστας με το να πατήσετε στο ID λίστας, στην πρώτη στήλη.</B>


<BR><BR><BR><BR>

<B><FONT SIZE=3>VICIDIAL_CAMPAIGN_STATUSES ΠΙΝΑΚΑΣ</FONT></B><BR><BR>
<A NAME="vicidial_campaign_statuses">
<BR>
<B>Με την χρήση προσαρμοσμένων καταστάσεων εκστρατείας, μπορείτε να έχετε καταστάσεις μόνο για συγκεκριμένες εκστρατείες. Η κατάσταση πρέπει να είναι 1-8 χαρακτήρες, η περιγραφή 2-30 χαρακτήρες και Επιλέξιμα καθορίζεται αν εμφανίζεται στο VICIDIAL ως τερματισμός.</B>



<BR><BR><BR><BR>

<B><FONT SIZE=3>VICIDIAL_CAMPAIGN_HOTKEYS ΠΙΝΑΚΑΣ</FONT></B><BR><BR>
<A NAME="vicidial_campaign_hotkeys">
<BR>
<B>Με την χρήση προσαρμοσμένων κλειδιών εκστρατείας, οι χρήστες που χρησιμοποιούν την εφαρμογή vicidial μπορούν να κλείσουν και να τερματίσουν την κλήση, με ένα μόνο πάτημα πλήκτρου.</B>





<BR><BR><BR><BR>

<B><FONT SIZE=3>VICIDIAL_USER_GROUPS ΠΙΝΑΚΑΣ</FONT></B><BR><BR>
<A NAME="vicidial_user_groups-user_group">
<BR>
<B>Ομάδα Χρήστη  -</B> Αυτό είναι το σύντομο όνομα της Vicidial ομάδας χρήστη, προσπαθήστε να μην χρησιμοποιήσετε κενά ή στίξεις για αυτό το πεδίο. Από 2 μέχρι 20 χαρακτήρες.

<BR>
<A NAME="vicidial_user_groups-group_name">
<BR>
<B>Ονομα Ομάδας-</B> Αυτή είναι η περιγραφή της vicidial ομάδας χρήστη μέχρι 40 χαρακτήρες.





<BR><BR><BR><BR>

<B><FONT SIZE=3>VICIDIAL_ΧΕΙΡΟΓΡΑΦΑ ΠΙΝΑΚΑΣ</FONT></B><BR><BR>
<A NAME="vicidial_scripts-script_id">
<BR>
<B>Ταυτότητα χειρογράφων -</B> αυτό είναι το σύντομο όνομα ενός χειρογράφου Vicidial. Αυτό πρέπει να είναι ένα μοναδικό προσδιοριστικό. Προσπαθήστε να μην χρησιμοποιήσετε οποιαδήποτε διαστήματα ή στίξη για ανώτατους 10 χαρακτήρες αυτών των τομέων, ελάχιστο 2 χαρακτήρων.

<BR>
<A NAME="vicidial_scripts-script_name">
<B>Όνομα χειρογράφων -</B> αυτό είναι ο τίτλος ενός χειρογράφου Vicidial. Αυτό είναι μια σύντομη περίληψη των ανώτατων 50 χαρακτήρων χειρογράφων, ελάχιστο 2 χαρακτήρων. Δεν πρέπει να υπάρξουν καμία διάστημα ή στίξη οποιουδήποτε είδους στον τομέα theis.

<BR>
<A NAME="vicidial_scripts-script_comments">
<B>Τα σχόλια χειρογράφων -</B> αυτό είναι όπου μπορείτε να τοποθετήσετε τα σχόλια για ένα χειρόγραφο Vicidial όπως - άλλαξαν στην ελεύθερη βελτίωση στις 23 του Σεπτεμβρίου -. ανώτατοι 255 χαρακτήρες, ελάχιστο 2 χαρακτήρων.

<BR>
<A NAME="vicidial_scripts-script_text">
<B>Κείμενο χειρογράφων -</B> This is where you place the content of a Vicidial Script. Minimum of 2 characters. You can have customer information be auto-populated in this script using "--A--field--B--" where field is one of the following fieldnames: vendor_lead_code, source_id, list_id, gmt_offset_now, called_since_last_reset, phone_code, phone_number, title, first_name, middle_initial, last_name, address1, address2, address3, city, state, province, postal_code, country_code, gender, date_of_birth, alt_phone, email, security_phrase, comments. For example, this sentence would print the persons name in it----<BR><BR>  Hello, can I speak with --A--first_name--B-- --A--last_name--B-- please? Well hello --A--title--B-- --A--last_name--B-- how are you today?<BR><BR> This would read----<BR><BR>Hello, can I speak with John Doe please? Well hello Mr. Doe how are you today?

<BR>
<A NAME="vicidial_scripts-active">
<BR>
<B>Ενεργός - αυτό καθορίζει εάν αυτό το χειρόγραφο μπορεί να επιλεχτεί για να χρησιμοποιηθεί από μια εκστρατεία.





<BR><BR><BR><BR>

<B><FONT SIZE=3>VICIDIAL_LEAD_ΦΙΛΤΡΑ ΠΙΝΑΚΑΣ</FONT></B><BR><BR>
<A NAME="vicidial_lead_filters-lead_filter_id">
<BR>
<B>Ταυτότητα φίλτρων -</B> αυτό είναι το σύντομο όνομα ενός φίλτρου μολύβδου Vicidial. Αυτό πρέπει να είναι ένα μοναδικό προσδιοριστικό. Μην χρησιμοποιήστε οποιαδήποτε διαστήματα ή στίξη για ανώτατους 10 χαρακτήρες αυτών των τομέων, ελάχιστο 2 χαρακτήρων.

<BR>
<A NAME="vicidial_lead_filters-lead_filter_name">
<B>Όνομα φίλτρων -</B> αυτό είναι ένα περιγραφικότερο όνομα του φίλτρου. Αυτό είναι μια σύντομη περίληψη των ανώτατων 30 χαρακτήρων φίλτρων, ελάχιστο 2 χαρακτήρων.

<BR>
<A NAME="vicidial_lead_filters-lead_filter_comments">
<B>Σχόλια φίλτρων -</B> αυτό είναι όπου μπορείτε να τοποθετήσετε τα σχόλια για ένα φίλτρο Vicidial όπως - κλήσεις όλοι οι μόλυβδοι Καλιφόρνιας -. ανώτατοι 255 χαρακτήρες, ελάχιστο 2 χαρακτήρων.

<BR>
<A NAME="vicidial_lead_filters-lead_filter_sql">
<B>Φίλτρο SQL -</B> αυτό είναι όπου τοποθετείτε το τεμάχιο ερώτησης SQL που θέλετε να φιλτραρίσετε κοντά δεν αρχίζετε ή δεν τελειώνετε με ΚΑΙ, το οποίο θα προστεθεί από το χειρόγραφο χοανών cron αυτόματα. μια ερώτηση παραδείγματος SQL που θα λειτουργούσε εδώ είναι - called_count 4 και called_count.





<BR><BR><BR><BR>

<B><FONT SIZE=3>VICIDIAL ΛΕΙΤΟΥΡΓΙΑ ΦΟΡΤΩΣΗΣ ΛΙΣΤΑΣ</FONT></B><BR><BR>
<A NAME="vicidial_list_loader">
<BR>
Ο VICIDIAL φορτωτής καθοδηγητών είναι απλά σχεδιασμένος, ώστε να παίρνει ένα αρχείο - μέχρι 8ΜΒ - που είναι  διαχωρισμένο με tab ή pipe και να το φορτώνει στον πίνακα vicidial_list. Υπάρχει επίσης ένας νέος βήτα φορτωτής μολύβδου έκδοσης έξοχος που επιτρέπει τον τομέα επιλέγοντας και TXT - σαφές κείμενο, CSV - κόμμα χώρισε τις τιμές και XLS - σχήματα αρχείων Excel. Ο φορτωτής δεν κάνει εξακρίβωση δεδομένων ή έλεγχο σε διπλές καταχωρήσεις, το οποί είναι κάτι που πρέπει να κάνετε πριν την φόρτωση. Επίσης, διευκρινίστε ότι έχετε δημιουργήσει την λίστα όπου οι καθοδηγητές θα είναι από κάτω, ώστε να τους χρησιμοποιήσετε.Υπάρχει επίσης το θέμα με τις ζώνες κωδικοποίησης χρόνου των καθοδηγητών. Μπορεί να θέλετε να αυξήσετε την συχνότητα όπου το ADMIN_adjust_GMTnow_on_leads.pl τρέχει στον cron, ώστε οποιαδήποτε φόρτωση καθοδηγητών να κωδικοποιείται πιο γρήγορα. Εδώ είναι μία λίστα από πεδία στην πρέπουσα ταξινόμηση για τα αρχεία καθοδήγησης.:
	<OL>
	<LI>Κωδικός Καθοδηγητού Προμηθευτού
	<LI>Πηγαίος Κώδικας - εσωτερική χρήση μόνο από διαχειριστές και DBAs
	<LI>ID λίστας - ο αριθμός λίστας που οι καθοδηγητές θα παρουσιαστούν κάτω από
	<LI>Κωδικός τηλεφώνου - το πρόθεμα του τηλεφωνικού αριθμού (1 για ΗΠΑ, 01144 για Βρετανία κλπ)
	<LI>Ο αριθμός τηλεφώνου - πρέπει να είναι τουλάχιστον 8 ψηφία
	<LI>Τίτλος - ο τίτλος του πελάτη (κος. κα. κλπ)
	<LI>Ονομα
	<LI>Μεσαίο Αρχικό
	<LI>Επίθετο
	<LI>1 Γραμμή Διεύθυνσης
	<LI>2 Γραμμή Διεύθυνσης
	<LI>3 Γραμμή Διεύθυνσης
	<LI>Πόλη
	<LI>Κράτος - περιορισμός σε 2 χαρακτήρες
	<LI>Επαρχία
	<LI>Ταχ.Κωδ.
	<LI>Χώρα
	<LI>Φύλον
	<LI>Ημερ. Γέννησης
	<LI>Εναλ. Αριθμός Τηλ.
	<LI>Διεύθυνση Ηλεκτρ.Ταχυδρομείου
	<LI>Φράση Ασφαλείας
	<LI>Σχόλια
	</OL>

<BR>ΣΗΜΕΙΩΣΕΙΣ: Η λειτουργία φορτωτών μολύβδου Excel επιτρέπεται από μια σειρά χειρογράφων perl και πρέπει να έχει κατάλληλα διαμορφωμένη/ένα αρχείο home/cron/AST_SERVER_conf.pl σε ισχύ στον κεντρικό υπολογιστή δικτύου. Επίσης, οι ενότητες ζευγών perl πρέπει να φορτωθούν για το για να εργαστούν επίσης - ολε- Storage_Lite και υπολογισμός με λογιστικό φύλλο (spreadsheet)- ParseExcel. Μπορείτε να ελέγξετε για τα λάθη χρόνου εκτέλεσης σε αυτοί με την εξέταση το αρχείο apache σας error_log.

<BR><BR><BR><BR><BR><BR><BR><BR>
<BR><BR><BR><BR><BR><BR><BR><BR>
ΤΕΛΟΣ
</TD></TR></TABLE></BODY></HTML>
<?
exit;

#### END HELP SCREENS
}





######################
# ADD=7111111 view sample script with test variables
######################

if ($ADD==7111111)
{
	##### TEST VARIABLES #####
	$vendor_lead_code = 'VENDORLEADCODE';
	$list_id = 'LISTID';
	$gmt_offset_now = 'GMTOFFSET';
	$phone_code = '1';
	$phone_number = '7275551212';
	$title = 'Mr.';
	$first_name = 'JOHN';
	$middle_initial = 'Q';
	$last_name = 'PUBLIC';
	$address1 = '1234 Main St.';
	$address2 = 'Apt. 3';
	$address3 = 'ADDRESS3';
	$city = 'CHICAGO';
	$state = 'IL';
	$province = 'PROVINCE';
	$postal_code = '33760';
	$country_code = 'USA';
	$gender = 'M';
	$date_of_birth = '1970-01-01';
	$alt_phone = '3125551212';
	$email = 'test@test.com';
	$security_phrase = 'SECUTIRY';
	$comments = 'COMMENTS FIELD';
	$RGfullname = 'JOE AGENT';
	$RGuser = '6666';

echo "</title>\n";
echo "</head>\n";
echo "<BODY BGCOLOR=white marginheight=0 marginwidth=0 leftmargin=0 topmargin=0>\n";
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

$stmt="SELECT * from vicidial_scripts where script_id='$script_id';";
$rslt=mysql_query($stmt, $link);
$row=mysql_fetch_row($rslt);
$script_name =		$row[1];
$script_text =		$row[3];

$script_text = eregi_replace('--A--vendor_lead_code--B--',"$vendor_lead_code",$script_text);
$script_text = eregi_replace('--A--list_id--B--',"$list_id",$script_text);
$script_text = eregi_replace('--A--gmt_offset_now--B--',"$gmt_offset_now",$script_text);
$script_text = eregi_replace('--A--phone_code--B--',"$phone_code",$script_text);
$script_text = eregi_replace('--A--phone_number--B--',"$phone_number",$script_text);
$script_text = eregi_replace('--A--title--B--',"$title",$script_text);
$script_text = eregi_replace('--A--first_name--B--',"$first_name",$script_text);
$script_text = eregi_replace('--A--middle_initial--B--',"$middle_initial",$script_text);
$script_text = eregi_replace('--A--last_name--B--',"$last_name",$script_text);
$script_text = eregi_replace('--A--address1--B--',"$address1",$script_text);
$script_text = eregi_replace('--A--address2--B--',"$address2",$script_text);
$script_text = eregi_replace('--A--address3--B--',"$address3",$script_text);
$script_text = eregi_replace('--A--city--B--',"$city",$script_text);
$script_text = eregi_replace('--A--state--B--',"$state",$script_text);
$script_text = eregi_replace('--A--province--B--',"$province",$script_text);
$script_text = eregi_replace('--A--postal_code--B--',"$postal_code",$script_text);
$script_text = eregi_replace('--A--country_code--B--',"$country_code",$script_text);
$script_text = eregi_replace('--A--gender--B--',"$gender",$script_text);
$script_text = eregi_replace('--A--date_of_birth--B--',"$date_of_birth",$script_text);
$script_text = eregi_replace('--A--alt_phone--B--',"$alt_phone",$script_text);
$script_text = eregi_replace('--A--email--B--',"$email",$script_text);
$script_text = eregi_replace('--A--security_phrase--B--',"$security_phrase",$script_text);
$script_text = eregi_replace('--A--comments--B--',"$comments",$script_text);
$script_text = eregi_replace('--A--fullname--B--',"$RGfullname",$script_text);
$script_text = eregi_replace('--A--user--B--',"$RGuser",$script_text);
$script_text = eregi_replace("\n","<BR>",$script_text);


echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

echo "Χειρόγραφο πρόβλεψης: $script_id<BR>\n";
echo "<TABLE WIDTH=400><TR><TD>\n";
echo "<center><B>$script_name</B><BR></center>\n";
echo "$script_text\n";
echo "</TD></TR></TABLE></center>\n";

echo "</BODY></HTML>\n";

exit;
}




######################### HTML HEADER BEGIN #######################################
if ($hh=='users') {$users_hh='bgcolor ="#FFFF99"'; $users_fc='BLACK';}	# yellow
	else {$users_hh=''; $users_fc='WHITE';}
if ($hh=='campaigns') {$campaigns_hh='bgcolor ="#FFCC99"'; $campaigns_fc='BLACK';}	# orange
	else {$campaigns_hh=''; $campaigns_fc='WHITE';}
if ($hh=='lists') {$lists_hh='bgcolor ="#FFCCCC"'; $lists_fc='BLACK';}	# red
	else {$lists_hh=''; $lists_fc='WHITE';}
if ($hh=='ingroups') {$ingroups_hh='bgcolor ="#CC99FF"'; $ingroups_fc='BLACK';} # purple
	else {$ingroups_hh=''; $ingroups_fc='WHITE';}
if ($hh=='remoteagent') {$remoteagent_hh='bgcolor ="#CCFFCC"'; $remoteagent_fc='BLACK';}	# green
	else {$remoteagent_hh=''; $remoteagent_fc='WHITE';}
if ($hh=='usergroups') {$usergroups_hh='bgcolor ="#CCFFFF"'; $usergroups_fc='BLACK';}	# cyan
	else {$usergroups_hh=''; $usergroups_fc='WHITE';}
if ($hh=='scripts') {$scripts_hh='bgcolor ="#99FFCC"'; $scripts_fc='BLACK';}	# teal
	else {$scripts_hh=''; $scripts_fc='WHITE';}
if ($hh=='filters') {$filters_hh='bgcolor ="#CCCCCC"'; $filters_fc='BLACK';} # grey
	else {$filters_hh=''; $filters_fc='WHITE';}

?>
</title>
<script language="Javascript">
function openNewWindow(url) {
  window.open (url,"",'width=500,height=300,scrollbars=yes,menubar=yes,address=yes');
}
</script>
</head>
<BODY BGCOLOR=white marginheight=0 marginwidth=0 leftmargin=0 topmargin=0>
<?
echo "<!-- ILPV -->\n";
echo "<TD WIDTH=100 ALIGN=RIGHT VALIGN=TOP  NOWRAP><a href=\"../vicidial_en/admin.php?relogin=YES&VD_login=$VD_login&VD_campaign=$VD_campaign&phone_login=$phone_login&phone_pass=$phone_pass&VD_pass=$VD_pass\">English <img src=\"../agc/images/en.gif\" BORDER=0 HEIGHT=14 WIDTH=20></a></TD>\n";echo "<TD WIDTH=100 ALIGN=RIGHT VALIGN=TOP  NOWRAP><a href=\"../vicidial_es/admin.php?relogin=YES&VD_login=$VD_login&VD_campaign=$VD_campaign&phone_login=$phone_login&phone_pass=$phone_pass&VD_pass=$VD_pass\">Español <img src=\"../agc/images/es.gif\" BORDER=0 HEIGHT=14 WIDTH=20></a></TD>\n";echo "<TD WIDTH=100 ALIGN=RIGHT VALIGN=TOP  BGCOLOR=\"#CCFFCC\" NOWRAP><a href=\"../vicidial_el/admin.php?relogin=YES&VD_login=$VD_login&VD_campaign=$VD_campaign&phone_login=$phone_login&phone_pass=$phone_pass&VD_pass=$VD_pass\">Ελληνικά <img src=\"../agc/images/el.gif\" BORDER=0 HEIGHT=14 WIDTH=20></a></TD>\n";?>
<CENTER>
<TABLE WIDTH=620 BGCOLOR=#D9E6FE cellpadding=2 cellspacing=0><TR BGCOLOR=#015B91><TD ALIGN=LEFT COLSPAN=6><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=2><B> &nbsp; VICIDIAL ΔΙΑΧ - <a href="<? echo $PHP_SELF ?>?force_logout=1"><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=1>ΑΠΟΣΥΝΔΕΣΗ</a></TD><TD ALIGN=RIGHT COLSPAN=3><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=2><B><? echo date("l F j, Y G:i:s A") ?> &nbsp; </TD></TR>

<TR BGCOLOR=#000000>
<TD ALIGN=CENTER <?=$users_hh?>><a href="<? echo $PHP_SELF ?>?ADD=0"><FONT FACE="ARIAL,HELVETICA" COLOR=<?=$users_fc?> SIZE=1><B> ΧΡΗΣΤΩΝ </a></TD>
<TD ALIGN=CENTER <?=$campaigns_hh?>><a href="<? echo $PHP_SELF ?>?ADD=10"><FONT FACE="ARIAL,HELVETICA" COLOR=<?=$campaigns_fc?> SIZE=1><B> ΕΚΣΤΡΑΤΕΙΩΝ </a></TD>
<TD ALIGN=CENTER <?=$lists_hh?>><a href="<? echo $PHP_SELF ?>?ADD=100"><FONT FACE="ARIAL,HELVETICA" COLOR=<?=$lists_fc?> SIZE=1><B> ΛΙΣΤΩΝ </a></TD>
<TD ALIGN=CENTER <?=$scripts_hh?>><a href="<? echo $PHP_SELF ?>?ADD=1000000"><FONT FACE="ARIAL,HELVETICA" COLOR=<?=$scripts_fc?> SIZE=1><B> ΧΕΙΡΟΓΡΑΦΑ </a></TD>
<TD ALIGN=CENTER <?=$filters_hh?>><a href="<? echo $PHP_SELF ?>?ADD=10000000"><FONT FACE="ARIAL,HELVETICA" COLOR=<?=$filters_fc?> SIZE=1><B> ΦΙΛΤΡΑ </a></TD>
<TD ALIGN=CENTER <?=$ingroups_hh?>><a href="<? echo $PHP_SELF ?>?ADD=1000"><FONT FACE="ARIAL,HELVETICA" COLOR=<?=$ingroups_fc?> SIZE=1><B> ΕΙΣΕΡΧΟΜΕΝΩΝ ΟΜΑΔΩΝ </a></TD>
<TD ALIGN=CENTER <?=$usergroups_hh?>><a href="<? echo $PHP_SELF ?>?ADD=100000"><FONT FACE="ARIAL,HELVETICA" COLOR=<?=$usergroups_fc?> SIZE=1><B> ΟΜΑΔΩΝ ΧΡΗΣΤΗ </a></TD>
<TD ALIGN=CENTER <?=$remoteagent_hh?>><a href="<? echo $PHP_SELF ?>?ADD=10000"><FONT FACE="ARIAL,HELVETICA" COLOR=<?=$remoteagent_fc?> SIZE=1><B> ΑΠΟΜΑΚΡΥΣΜΕΝΟΙ ΧΡΗΣΤΕΣ </a></TD>
<TD ALIGN=CENTER <?=$reports_hh?>><a href="server_stats.php"><FONT FACE="ARIAL,HELVETICA" COLOR=WHITE SIZE=1><B> ΕΚΘΕΣΕΙΣ </a></TD>
</TR>


<? if (strlen($users_hh) > 1) { 
	?>
<TR BGCOLOR=#FFFF99><TD ALIGN=CENTER COLSPAN=9><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1><B> &nbsp; <a href="<? echo $PHP_SELF ?>"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΛΙΣΤΑ ΧΡΗΣΤΩΝ</a> &nbsp; &nbsp; | &nbsp; &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=1"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΠΡΟΣΘΗΚΗ ΝΕΟΥ ΧΡΗΣΤΗ</a> &nbsp; &nbsp; | &nbsp; &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=55"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΑΝΑΖΗΤΗΣΗ ΧΡΗΣΤΗ</a></TD></TR>
<? } 
if (strlen($campaigns_hh) > 1) { 
	?>
<TR BGCOLOR=#FFCC99><TD ALIGN=CENTER COLSPAN=9><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1><B> &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=11"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΠΡΟΣΘΗΚΗ ΕΚΣΤΡΑΤΕΙΑΣ</a> &nbsp; &nbsp; | &nbsp; &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=10"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΛΙΣΤΑΣ ΕΚΣΤΡΑΤΕΙΩΝ</a></TD></TR>
<? } 
if (strlen($lists_hh) > 1) { 
	?>
<TR BGCOLOR=#FFCCCC><TD ALIGN=CENTER COLSPAN=9><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1><B> &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=100"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΕΜΦΑΝΙΣΗ ΛΙΣΤΩΝ</a> &nbsp; &nbsp; | &nbsp; &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΠΡΟΣΘΗΚΗ ΝΕΑΣ ΛΙΣΤΑΣ</a> &nbsp; &nbsp; | &nbsp; &nbsp; <a href="admin_search_lead.php"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΑΝΑΖΗΤΗΣΗ ΚΑΘΟΔΗΓΗΣΗΣ</a> | &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; | &nbsp; &nbsp; <a href="./listloaderMAIN.php"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΦΌΡΤΙΣΗ ΝΕΩΝ ΚΑΘΟΔΗΓΗΤΩΝ</a></TD></TR>
<? } 
if (strlen($scripts_hh) > 1) { 
	?>
<TR BGCOLOR=#99FFCC><TD ALIGN=CENTER COLSPAN=9><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1><B> &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=1111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΠΡΟΣΘΕΣΤΕ ΤΟ ΧΕΙΡΟΓΡΑΦΟ</a> &nbsp; &nbsp; | &nbsp; &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=1000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΧΕΙΡΟΓΡΑΦΑ ΑΠΟΨΗΣ</a></TD></TR>
<? } 
if (strlen($filters_hh) > 1) { 
	?>
<TR BGCOLOR=#CCCCCC><TD ALIGN=CENTER COLSPAN=9><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1><B> &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=11111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΠΡΟΣΘΕΣΤΕ ΤΟ ΦΙΛΤΡΟ</a> &nbsp; &nbsp; | &nbsp; &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=10000000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΦΙΛΤΡΑ ΑΠΟΨΗΣ</a></TD></TR>
<? } 
if (strlen($ingroups_hh) > 1) { 
	?>
<TR BGCOLOR=#CC99FF><TD ALIGN=CENTER COLSPAN=9><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1><B> &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=1000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΕΜΦΑΝΙΣΗ ΕΙΣΕΡΧΟΜΕΝΩΝ ΟΜΑΔΩΝ</a> &nbsp; &nbsp; | &nbsp; &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=1111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΠΡΟΣΘΗΚΗ ΝΈΑΣ ΕΙΣΕΡΜΟΜΕΝΗΣ ΟΜΑΔΑΣ</a></TD></TR>
<? } 
if (strlen($usergroups_hh) > 1) { 
	?>
<TR BGCOLOR=#CCFFFF><TD ALIGN=CENTER COLSPAN=9><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1><B> &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=111111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΠΡΟΣΘΗΚΗ ΟΜΑΔΑΣ ΧΡΗΣΤΗ</a> &nbsp; &nbsp; | &nbsp; &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=100000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΛΙΣΤΑ ΟΜΑΔΩΝ ΧΡΗΣΤΗ</a> &nbsp; &nbsp; | &nbsp; &nbsp; <a href="group_hourly_stats.php"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>Ωριαία Ομάδα</a></TD></TR>
<? } 
if (strlen($remoteagent_hh) > 1) { 
	?>
<TR BGCOLOR=#CCFFCC><TD ALIGN=CENTER COLSPAN=9><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1><B> &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=10000"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΕΜΦΑΝΙΣΗ ΑΠΟΜΑΚΡΥΣΜΕΝΩΝ ΧΡΗΣΤΩΝ</a> &nbsp; &nbsp; | &nbsp; &nbsp; <a href="<? echo $PHP_SELF ?>?ADD=11111"><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1>ΠΡΟΣΘΗΚΗ ΝΕΩΝ ΑΠΟΜΑΚΡΥΣΜΕΝΩΝ ΧΡΗΣΤΩΝ</a></TD></TR>
<? } 
if (strlen($reports_hh) > 1) { 
	?>
<TR BGCOLOR=#FFCC99><TD ALIGN=CENTER COLSPAN=9><FONT FACE="ARIAL,HELVETICA" COLOR=BLACK SIZE=1><B> &nbsp; </TD></TR>
<? } ?>


<TR><TD ALIGN=LEFT COLSPAN=9 HEIGHT=2 BGCOLOR=BLACK></TD></TR>
<TR><TD ALIGN=LEFT COLSPAN=9>
<? 
######################### HTML HEADER BEGIN #######################################





######################################################################################################
######################################################################################################
#######   1 series, ADD NEW forms for inserting new records into the database
######################################################################################################
######################################################################################################


######################
# ADD=1 display the ADD NEW USER FORM SCREEN
######################

if ($ADD==1)
{
echo "<TABLE><TR><TD>\n";
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

echo "<br>ΠΡΟΣΘΗΚΗ ΝΕΟΥ ΧΡΗΣΤΗ<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=2>\n";
echo "<center><TABLE width=600 cellspacing=3>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Αριθμός Χρήστη: </td><td align=left><input type=text name=user size=20 maxlength=10>$NWB#vicidial_users-user$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Κωδικός:</td><td align=left><input type=text name=pass size=20 maxlength=10>$NWB#vicidial_users-pass$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Πλήρες Ονομα: </td><td align=left><input type=text name=full_name size=20 maxlength=100>$NWB#vicidial_users-full_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Επίπεδο Χρήστη: </td><td align=left><select size=1 name=user_level>";
$h=1;
while ($h<=$LOGuser_level)
	{
	echo "<option>$h</option>";
	$h++;
	}
echo "</select>$NWB#vicidial_users-user_level$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ομάδα Χρήστη: </td><td align=left><select size=1 name=user_group>\n";

	$stmt="SELECT user_group,group_name from vicidial_user_groups order by user_group";
	$rsltx=mysql_query($stmt, $link);
	$Ugroups_to_print = mysql_num_rows($rsltx);
	$Ugroups_list='';

	$o=0;
	while ($Ugroups_to_print > $o) {
		$rowx=mysql_fetch_row($rsltx);
		$Ugroups_list .= "<option value=\"$rowx[0]\">$rowx[0] - $rowx[1]</option>\n";
		$o++;
	}
echo "$Ugroups_list";
echo "<option SELECTED>$user_group</option>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Τηλεφωνική σύνδεση: </td><td align=left><input type=text name=phone_login size=20 maxlength=20>$NWB#vicidial_users-phone_login$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Τηλεφωνικός κωδικός πρόσβασης: </td><td align=left><input type=text name=phone_pass size=20 maxlength=20>$NWB#vicidial_users-phone_pass$NWE</td></tr>\n";
echo "</select>$NWB#vicidial_users-user_group$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center>\n";

}


######################
# ADD=11 display the ADD NEW CAMPAIGN FORM SCREEN
######################

if ($ADD==11)
{
echo "<TABLE><TR><TD>\n";
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

echo "<br>ΠΡΟΣΘΗΚΗ ΝΕΑΣ ΕΚΣΤΡΑΤΕΙΑΣ<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=21>\n";
echo "<center><TABLE width=600 cellspacing=3>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>ID Εκστρατείας: </td><td align=left><input type=text name=campaign_id size=8 maxlength=8>$NWB#vicidial_campaigns-campaign_id$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ονομα Εκστρατείας: </td><td align=left><input type=text name=campaign_name size=30 maxlength=30>$NWB#vicidial_campaigns-campaign_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ενεργός:</td><td align=left><select size=1 name=active><option>Y</option><option>N</option></select>$NWB#vicidial_campaigns-active$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Τηλ.σύνδ. Στάθμευσης: </td><td align=left><input type=text name=park_ext size=10 maxlength=10>$NWB#vicidial_campaigns-park_ext$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ονομα Αρχείου Στάθμευσης: </td><td align=left><input type=text name=park_file_name size=10 maxlength=10>$NWB#vicidial_campaigns-park_file_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ιστο-σελίδα: </td><td align=left><input type=text name=web_form_address size=50 maxlength=255>$NWB#vicidial_campaigns-web_form_address$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Επιτρέπω Τους Closers: </td><td align=left><select size=1 name=allow_closers><option>Y</option><option>N</option></select>$NWB#vicidial_campaigns-allow_closers$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>ΕΠΙΠΕΔΟ Hopper: </td><td align=left><select size=1 name=hopper_level><option>1</option><option>5</option><option>10</option><option>50</option><option>100</option><option>200</option><option>500</option><option>1000</option></select>$NWB#vicidial_campaigns-hopper_level$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>ΕΠΙΠΕΔΟ ΑΥΤΟΜΑΤΗΣ ΚΛΗΣΗΣ: </td><td align=left><select size=1 name=auto_dial_level><option selected>0</option><option>1</option><option>1.1</option><option>1.2</option><option>1.3</option><option>1.4</option><option>1.5</option><option>1.6</option><option>1.7</option><option>1.8</option><option>1.9</option><option>2.0</option><option>2.2</option><option>2.5</option><option>2.7</option><option>3.0</option><option>3.5</option><option>4.0</option></select>(0 = off)$NWB#vicidial_campaigns-auto_dial_level$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Επόμενη Κλήση Χρήστη: </td><td align=left><select size=1 name=next_agent_call><option >random</option><option>oldest_call_start</option><option>oldest_call_finish</option><option>overall_user_level</option></select>$NWB#vicidial_campaigns-next_agent_call$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Χρόνος Τοπικής Κλήσης: </td><td align=left><select size=1 name=local_call_time><option >24hours</option><option >9am-9pm</option><option>9am-5pm</option><option>12pm-5pm</option><option>12pm-9pm</option><option>5pm-9pm</option></select>$NWB#vicidial_campaigns-local_call_time$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>ΦΩΝΗΤΙΚΟ ΤΑΧΥΔΡΟΜΕΙΟ: </td><td align=left><input type=text name=voicemail_ext size=10 maxlength=10 value=\"$voicemail_ext\">$NWB#vicidial_campaigns-voicemail_ext$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Χειρόγραφο: </td><td align=left><select size=1 name=script_id>\n";
echo "$scripts_list";
echo "</select>$NWB#vicidial_campaigns-campaign_script$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Πάρτε την έναρξη κλήσης: </td><td align=left><select size=1 name=get_call_launch><option selected>NONE</option><option>SCRIPT</option><option>WEBFORM</option></select>$NWB#vicidial_campaigns-get_call_launch$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center>\n";

}


######################
# ADD=111 display the ADD NEW LIST FORM SCREEN
######################

if ($ADD==111)
{
echo "<TABLE><TR><TD>\n";
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

echo "<br>ADD A NEW LIST<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=211>\n";
echo "<center><TABLE width=600 cellspacing=3>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>ID Λίστας: </td><td align=left><input type=text name=list_id size=8 maxlength=8> (μόνο αριθμοί)$NWB#vicidial_lists-list_id$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ονομα Λίστας: </td><td align=left><input type=text name=list_name size=20 maxlength=20>$NWB#vicidial_lists-list_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Εκστρατείας: </td><td align=left><select size=1 name=campaign_id>\n";

	$stmt="SELECT campaign_id,campaign_name from vicidial_campaigns order by campaign_id";
	$rsltx=mysql_query($stmt, $link);
	$campaigns_to_print = mysql_num_rows($rsltx);
	$campaigns_list='';

	$o=0;
	while ($campaigns_to_print > $o) {
		$rowx=mysql_fetch_row($rsltx);
		$campaigns_list .= "<option value=\"$rowx[0]\">$rowx[0] - $rowx[1]</option>\n";
		$o++;
	}
echo "$campaigns_list";
echo "<option SELECTED>$campaign_id</option>\n";
echo "</select>$NWB#vicidial_lists-campaign_id$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ενεργός:</td><td align=left><select size=1 name=active><option>Y</option><option SELECTED>N</option></select>$NWB#vicidial_lists-active$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center>\n";

}


######################
# ADD=1111 display the ADD NEW INBOUND GROUP SCREEN
######################

if ($ADD==1111)
{
echo "<TABLE><TR><TD>\n";
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

echo "<br>ΠΡΟΣΘΗΚΗ ΝΈΑΣ ΕΙΣΕΡΧΟΜΕΝΗΣ ΟΜΑΔΑΣ<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=2111>\n";
echo "<center><TABLE width=600 cellspacing=3>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>ID Ομάδας: </td><td align=left><input type=text name=group_id size=20 maxlength=20> (no spaces)$NWB#vicidial_inbound_groups-group_id$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ονομα Ομάδας: </td><td align=left><input type=text name=group_name size=30 maxlength=30>$NWB#vicidial_inbound_groups-group_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Χρώμα Ομάδας: </td><td align=left><input type=text name=group_color size=7 maxlength=7>$NWB#vicidial_inbound_groups-group_color$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ενεργός:</td><td align=left><select size=1 name=active><option SELECTED>Y</option><option>N</option></select>$NWB#vicidial_inbound_groups-active$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ιστο-σελίδα: </td><td align=left><input type=text name=web_form_address size=50 maxlength=255 value=\"$web_form_address\">$NWB#vicidial_inbound_groups-web_form_address$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>ΦΩΝΗΤΙΚΟ ΤΑΧΥΔΡΟΜΕΙΟ: </td><td align=left><input type=text name=voicemail_ext size=10 maxlength=10 value=\"$voicemail_ext\">$NWB#vicidial_inbound_groups-voicemail_ext$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Επόμενη Κλήση Χρήστη: </td><td align=left><select size=1 name=next_agent_call><option >random</option><option>oldest_call_start</option><option>oldest_call_finish</option><option>overall_user_level</option></select>$NWB#vicidial_inbound_groups-next_agent_call$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Οθόνη Μπροστινού: </td><td align=left><select size=1 name=fronter_display><option SELECTED>Y</option><option>N</option></select>$NWB#vicidial_inbound_groups-fronter_display$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Χειρόγραφο: </td><td align=left><select size=1 name=script_id>\n";
echo "$scripts_list";
echo "</select>$NWB#vicidial_inbound_groups-ingroup_script$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Πάρτε την έναρξη κλήσης: </td><td align=left><select size=1 name=get_call_launch><option selected>NONE</option><option>SCRIPT</option><option>WEBFORM</option></select>$NWB#vicidial_inbound_groups-get_call_launch$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center>\n";

}


######################
# ADD=11111 display the ADD NEW REMOTE AGENTS SCREEN
######################

if ($ADD==11111)
{
echo "<TABLE><TR><TD>\n";
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

echo "<br>ΠΡΟΣΘΗΚΗ ΝΕΩΝ ΑΠΟΜΑΚΡΥΣΜΕΝΩΝ ΧΡΗΣΤΩΝ<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=21111>\n";
echo "<center><TABLE width=600 cellspacing=3>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>ID Χρήστη Ξεκίνημα: </td><td align=left><input type=text name=user_start size=6 maxlength=6> (μόνο αριθμοί, incremented)$NWB#vicidial_remote_agents-user_start$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Αριθμός Γραμμών: </td><td align=left><input type=text name=number_of_lines size=3 maxlength=3> (μόνο αριθμοί)$NWB#vicidial_remote_agents-number_of_lines$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>IP Διακομιστή: </td><td align=left><select size=1 name=server_ip>\n";
echo "$servers_list";
echo "</select>$NWB#vicidial_remote_agents-server_ip$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Εξωτερική Τηλ. Σύνδεση: </td><td align=left><input type=text name=conf_exten size=20 maxlength=20> ()$NWB#vicidial_remote_agents-conf_exten$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Κατάσταση:</td><td align=left><select size=1 name=status><option>ΕΝΕΡΓΑ</option><option SELECTED>INACTIVE</option></select>$NWB#vicidial_remote_agents-status$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Εκστρατείας: </td><td align=left><select size=1 name=campaign_id>\n";
echo "$campaigns_list";
echo "</select>$NWB#vicidial_remote_agents-campaign_id$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Εισερχόμενες Ομάδες: </td><td align=left>\n";
echo "$groups_list";
echo "$NWB#vicidial_remote_agents-closer_campaigns$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center>\n";
echo "ΣΗΜΕΙΩΣΗ: Μπορεί να διαρκέσει και 30 δευτερόλεπτα για να καταχωρηθούν οι αλλαγές της οθόνης\n";

}


######################
# ADD=111111 display the ADD NEW USERS GROUP SCREEN
######################

if ($ADD==111111)
{
echo "<TABLE><TR><TD>\n";
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

echo "<br>ΠΡΟΣΘΗΚΗ ΝΕΑ ΟΜΑΔΑ ΧΡΗΣΤΩΝ<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=211111>\n";
echo "<center><TABLE width=600 cellspacing=3>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ομάδα:</td><td align=left><input type=text name=user_group size=15 maxlength=20> (όχι κενά ή στίξη)$NWB#vicidial_user_groups-user_group$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Περιγραφή:</td><td align=left><input type=text name=group_name size=40 maxlength=40> (περιγραφή ομάδας)$NWB#vicidial_user_groups-group_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center>\n";

}


######################
# ADD=1111111 display the ADD NEW SCRIPT SCREEN
######################

if ($ADD==1111111)
{
echo "<TABLE><TR><TD>\n";
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

echo "<br>ADD NEW SCRIPT<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=2111111>\n";
echo "<center><TABLE width=600 cellspacing=3>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ταυτότητα χειρογράφων:: </td><td align=left><input type=text name=script_id size=12 maxlength=10> (όχι κενά ή στίξη)$NWB#vicidial_scripts-script_id$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Όνομα χειρογράφων: </td><td align=left><input type=text name=script_name size=40 maxlength=50> (τίτλος του χειρογράφου)$NWB#vicidial_scripts-script_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Τα σχόλια χειρογράφων: </td><td align=left><input type=text name=script_comments size=50 maxlength=255> $NWB#vicidial_scripts-script_comments$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ενεργός:</td><td align=left><select size=1 name=active><option SELECTED>Y</option><option>N</option></select>$NWB#vicidial_scripts-active$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Κείμενο χειρογράφων: </td><td align=left><TEXTAREA NAME=script_text ROWS=20 COLS=50 value=\"\"></TEXTAREA> $NWB#vicidial_scripts-script_text$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center>\n";

}


######################
# ADD=11111111 display the ADD NEW FILTER SCREEN
######################

if ($ADD==11111111)
{
echo "<TABLE><TR><TD>\n";
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

echo "<br>ΠΡΟΣΘΕΣΤΕ ΤΟ ΝΕΟ ΦΙΛΤΡΟ<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=21111111>\n";
echo "<center><TABLE width=600 cellspacing=3>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ταυτότητα φίλτρων:</td><td align=left><input type=text name=lead_filter_id size=12 maxlength=10> (όχι κενά ή στίξη)$NWB#vicidial_lead_filters-lead_filter_id$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Όνομα φίλτρων:</td><td align=left><input type=text name=lead_filter_name size=30 maxlength=30> (σύντομη περιγραφή του φίλτρου)$NWB#vicidial_lead_filters-lead_filter_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Το φίλτρο σχολιάζει: </td><td align=left><input type=text name=lead_filter_comments size=50 maxlength=255> $NWB#vicidial_lead_filters-lead_filter_comments$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Φίλτρο SQL: </td><td align=left><TEXTAREA NAME=lead_filter_sql ROWS=20 COLS=50 value=\"\"></TEXTAREA> $NWB#vicidial_lead_filters-lead_filter_sql$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center>\n";
}


######################################################################################################
######################################################################################################
#######   2 series, validates form data and inserts the new record into the database
######################################################################################################
######################################################################################################


######################
# ADD=2 adds the new user to the system
######################

if ($ADD==2)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
	$stmt="SELECT count(*) from vicidial_users where user='$user';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	if ($row[0] > 0)
		{echo "<br>Ο ΧΡΗΣΤΗΣ ΔΕΝ ΠΡΟΣΤΕΘΗΚΕ  - υπάρχει ήδη ένας χρήστης με αυτό τον αριθμό\n";}
	else
		{
		 if ( (strlen($user) < 2) or (strlen($pass) < 2) or (strlen($full_name) < 2) or (strlen($user) > 8) )
			{
			 echo "<br>USER NOT ADDED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
			 echo "<br>το id χρήστη πρέπει να είναι μεταξύ 2 και 8 χαρακτήρες\n";
			 echo "<br>το πλήρες όνομα και κωδικός πρέπει να είναι τουλάχιστον 2 χαρακτήρες\n";
			}
		 else
			{
			echo "<br><B>ΧΡΗΣΤΗΣ ΠΡΟΣΤΕΘΗΚΕ: $user</B>\n";

			$stmt="INSERT INTO vicidial_users (user,pass,full_name,user_level,user_group,phone_login,phone_pass) values('$user','$pass','$full_name','$user_level','$user_group','$phone_login','$phone_pass');";
			$rslt=mysql_query($stmt, $link);

			### LOG CHANGES TO LOG FILE ###
			if ($WeBRooTWritablE > 0)
				{
				$fp = fopen ("./admin_changes_log.txt", "a");
				fwrite ($fp, "$date|ADD A USER          |$PHP_AUTH_USER|$ip|'$user','$pass','$full_name','$user_level','$user_group','$phone_login','$phone_pass'|\n");
				fclose($fp);
				}
			}
		}
$ADD=3;
}

######################
# ADD=21 adds the new campaign to the system
######################

if ($ADD==21)
{

	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
	$stmt="SELECT count(*) from vicidial_campaigns where campaign_id='$campaign_id';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	if ($row[0] > 0)
		{echo "<br>Η ΕΚΣΤΡΑΤΕΙΑ ΔΕΝ ΠΡΟΣΤΕΘΗΚΕ - υπάρχει ήδη μία εκστρατεία με αυτό το ID\n";}
	else
		{
		 if ( (strlen($campaign_id) < 2) or (strlen($campaign_id) > 8) or (strlen($campaign_name) < 6)  or (strlen($campaign_name) > 40) )
			{
			 echo "<br>CAMPAIGN NOT ADDED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
			 echo "<br>το ID της εκστρατείας πρέπει να είναι μεταξύ 2 και 8 χαρακτήρες\n";
			 echo "<br>το όνομα της εκστρατείας πρέπει να είναι μεταξύ 6 και 40 χαρακτήρες\n";
			}
		 else
			{
			echo "<br><B>ΚΣΤΡΑΤΕΙΑ ΠΡΟΣΤΕΘΗΚΕ: $campaign_id</B>\n";

			$stmt="INSERT INTO vicidial_campaigns (campaign_id,campaign_name,active,dial_status_a,lead_order,park_ext,park_file_name,web_form_address,allow_closers,hopper_level,auto_dial_level,next_agent_call,local_call_time,voicemail_ext,campaign_script,get_call_launch) values('$campaign_id','$campaign_name','$active','NEW','DOWN','$park_ext','$park_file_name','$web_form_address','$allow_closers','$hopper_level','$auto_dial_level','$next_agent_call','$local_call_time','$voicemail_ext','$script_id','$get_call_launch');";
			$rslt=mysql_query($stmt, $link);

			echo "<!-- $stmt -->";
			### LOG CHANGES TO LOG FILE ###
			if ($WeBRooTWritablE > 0)
				{
				$fp = fopen ("./admin_changes_log.txt", "a");
				fwrite ($fp, "$date|ADD A NEW CAMPAIGN  |$PHP_AUTH_USER|$ip|INSERT INTO vicidial_campaigns (campaign_id,campaign_name,active,dial_status_a,lead_order,park_ext,park_file_name,web_form_address,allow_closers,hopper_level,auto_dial_level,next_agent_call,local_call_time,voicemail_ext,campaign_script,get_call_launch) values('$campaign_id','$campaign_name','$active','NEW','DOWN','$park_ext','$park_file_name','$web_form_address','$allow_closers','$hopper_level','$auto_dial_level','$next_agent_call','$local_call_time','$voicemail_ext','$script_id','$get_call_launch')|\n");
				fclose($fp);
				}

			}
		}
$ADD=31;
}

######################
# ADD=22 adds the new campaign status to the system
######################

if ($ADD==22)
{

	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
	$stmt="SELECT count(*) from vicidial_campaign_statuses where campaign_id='$campaign_id' and status='$status';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	if ($row[0] > 0)
		{echo "<br>Η ΚΑΤΑΣΤΑΣΗ ΤΗΣ ΕΚΣΤΡΑΤΕΙΑΣ ΔΕΝ ΠΡΟΣΤΕΘΗΚΕ - υπάρχει ήδη κατάσταση-εκστρατείας με αυτό το όνομα\n";}
	else
		{
		$stmt="SELECT count(*) from vicidial_statuses where status='$status';";
		$rslt=mysql_query($stmt, $link);
		$row=mysql_fetch_row($rslt);
		if ($row[0] > 0)
			{echo "<br>Η ΚΑΤΑΣΤΑΣΗ ΤΗΣ ΕΚΣΤΡΑΤΕΙΑΣ ΔΕΝ ΠΡΟΣΤΕΘΗΚΕ - υπάρχει ήδη μία καθολική-κατάσταση με αυτό το όνομα\n";}
		else
			{
			 if ( (strlen($campaign_id) < 2) or (strlen($status) < 1) or (strlen($status_name) < 2) )
				{
				 echo "<br>CAMPAIGN STATUS NOT ADDED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
				 echo "<br>η κατάσταση πρέπει να είναι μεταξύ 1 και 8 χαρακτήρρες\n";
				 echo "<br>το όνομα της κατάστασης πρέπει να είναι μεταξύ 2 και 30 χαρακτήρρες\n";
				}
			 else
				{
				echo "<br><B>ΚΑΤΑΣΤΑΣΗ ΕΚΣΤΡΑΤΕΙΑΣ ΠΡΟΣΤΕΘΗΚΕ: $campaign_id - $status</B>\n";

				$stmt="INSERT INTO vicidial_campaign_statuses values('$status','$status_name','$selectable','$campaign_id');";
				$rslt=mysql_query($stmt, $link);

				### LOG CHANGES TO LOG FILE ###
				if ($WeBRooTWritablE > 0)
					{
					$fp = fopen ("./admin_changes_log.txt", "a");
					fwrite ($fp, "$date|ΠΡΟΣΘΗΚΗ ΝΕΑΣ ΕΚΣΤΡΑΤΕΙΑΣ STATUS |$PHP_AUTH_USER|$ip|'$status','$status_name','$selectable','$campaign_id'|\n");
					fclose($fp);
					}
				}
			}
		}
$ADD=31;
}


######################
# ADD=23 adds the new campaign hotkey to the system
######################

if ($ADD==23)
{
	$HKstatus_data = explode('-----',$HKstatus);
	$status = $HKstatus_data[0];
	$status_name = $HKstatus_data[1];

	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
	$stmt="SELECT count(*) from vicidial_campaign_hotkeys where campaign_id='$campaign_id' and hotkey='$hotkey' and hotkey='$hotkey';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	if ($row[0] > 0)
		{echo "<br>ΤΟ ΚΛΕΙΔΙ ΤΗΣ ΕΚΣΤΡΑΤΕΙΑΣ ΔΕΝ ΠΡΟΣΤΕΘΗΚΕ - υπάρχει ήδη ένα κλειδί-εκστρατείας με αυτό το κλειδί\n";}
	else
		{
		 if ( (strlen($campaign_id) < 2) or (strlen($status) < 1) or (strlen($hotkey) < 1) )
			{
			 echo "<br>CAMPAIGN HOTKEY NOT ADDED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
			 echo "<br>το κλειδί πρέπει να είναι ένας χαρακτηράς μεταξύ 1 και 9 \n";
			 echo "<br>η κατάσταση πρέπει να είναι μεταξύ 1 και 8 χαρακτήρρες\n";
			}
		 else
			{
			echo "<br><B>ΚΛΕΙΔΙ ΕΚΣΤΡΑΤΕΙΑΣ ΠΡΟΣΤΕΘΗΚΕ: $campaign_id - $status - $hotkey</B>\n";

			$stmt="INSERT INTO vicidial_campaign_hotkeys values('$status','$hotkey','$status_name','$selectable','$campaign_id');";
			$rslt=mysql_query($stmt, $link);

			### LOG CHANGES TO LOG FILE ###
			if ($WeBRooTWritablE > 0)
				{
				$fp = fopen ("./admin_changes_log.txt", "a");
				fwrite ($fp, "$date|ΠΡΟΣΘΗΚΗ ΝΕΑΣ ΕΚΣΤΡΑΤΕΙΑΣ HOTKEY |$PHP_AUTH_USER|$ip|'$status','$hotkey','$status_name','$selectable','$campaign_id'|\n");
				fclose($fp);
				}
			}
		}
$ADD=31;
}


######################
# ADD=211 adds the new list to the system
######################

if ($ADD==211)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
	$stmt="SELECT count(*) from vicidial_lists where list_id='$list_id';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	if ($row[0] > 0)
		{echo "<br>Η ΛΙΣΤΑ ΔΕΝ ΠΡΟΣΤΕΘΗΚΕ - υπάρχει ήδη μία λίστα με αυτό το ID\n";}
	else
		{
		 if ( (strlen($campaign_id) < 2) or (strlen($list_name) < 2)  or (strlen($list_id) < 2) or (strlen($list_id) > 8) )
			{
			 echo "<br>LIST NOT ADDED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
			 echo "<br>Το ID λίστας πρέπει να είναι μεταξύ 2 και 8 χαρακτήρες\n";
			 echo "<br>Το όνομα λίστας πρέπει να είναι 2 χαρακτήρες\n";
			 }
		 else
			{
			echo "<br><B>ΛΙΣΤΑ ΠΡΟΣΤΕΘΗΚΕ: $list_id</B>\n";

			$stmt="INSERT INTO vicidial_lists values('$list_id','$list_name','$campaign_id','$active');";
			$rslt=mysql_query($stmt, $link);

			### LOG CHANGES TO LOG FILE ###
			if ($WeBRooTWritablE > 0)
				{
				$fp = fopen ("./admin_changes_log.txt", "a");
				fwrite ($fp, "$date|ADD A NEW LIST      |$PHP_AUTH_USER|$ip|'$list_id','$list_name','$campaign_id','$active'|\n");
				fclose($fp);
				}
			}
		}
$ADD=311;
}



######################
# ADD=2111 adds the new inbound group to the system
######################

if ($ADD==2111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
	$stmt="SELECT count(*) from vicidial_inbound_groups where group_id='$group_id';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	if ($row[0] > 0)
		{echo "<br>Η ΟΜΑΔΑ ΔΕΝ ΠΡΟΣΤΕΘΗΚΕ - υπάρχει ήδη μία ομάδα με αυτό το ID\n";}
	else
		{
		 if ( (strlen($group_id) < 2) or (strlen($group_name) < 2)  or (strlen($group_color) < 2) or (strlen($group_id) > 20) or (eregi(' ',$group_id)) or (eregi("\-",$group_id)) or (eregi("\+",$group_id)) )
			{
			 echo "<br>GROUP NOT ADDED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
			 echo "<br>Το ID ομάδας πρέπει να είναι μεταξύ 2 και 20 χαρακτήρες ' -+'.\n";
			 echo "<br>Το όνομα και χρώμα ομάδας πρέπει να είναι τουλάχιστον 2 χαρακτήρες\n";
			}
		 else
			{
			$stmt="INSERT INTO vicidial_inbound_groups (group_id,group_name,group_color,active,web_form_address,voicemail_ext,next_agent_call,fronter_display,ingroup_script,get_call_launch) values('$group_id','$group_name','$group_color','$active','$web_form_address','$voicemail_ext','$next_agent_call','$fronter_display','$script_id','$get_call_launch');";
			$rslt=mysql_query($stmt, $link);

			echo "<br><B>ΟΜΑΔΑ ΠΡΟΣΤΕΘΗΚΕ: $group_id</B>\n";

			### LOG CHANGES TO LOG FILE ###
			if ($WeBRooTWritablE > 0)
				{
				$fp = fopen ("./admin_changes_log.txt", "a");
				fwrite ($fp, "$date|ADD A NEW GROUP     |$PHP_AUTH_USER|$ip|'$group_id','$group_name','$group_color','$active','$web_form_address','$voicemail_ext','$next_agent_call','$fronter_display','$script_id','$get_call_launch'|\n");
				fclose($fp);
				}
			}
		}
$ADD=1000;
}


######################
# ADD=21111 adds new remote agents to the system
######################

if ($ADD==21111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
	$stmt="SELECT count(*) from vicidial_remote_agents where server_ip='$server_ip' and user_start='$user_start';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	if ($row[0] > 0)
		{echo "<br>ΟΙ ΑΠΟΜΑΚΡΥΣΜΕΝΟΙ ΧΡΗΣΤΕΣ ΔΕΝ ΠΡΟΣΤΕΘΗΚΑΝ - υπάρχει ήδη καταχώρηση απομακρυσμένων χρηστών που ξεκινάει με αυτό το ID χρήστη\n";}
	else
		{
		 if ( (strlen($server_ip) < 2) or (strlen($user_start) < 2)  or (strlen($campaign_id) < 2) or (strlen($conf_exten) < 2) )
			{
			 echo "<br>ΑΠΟΜΑΚΡΥΣΜΕΝΟΙ ΧΡΗΣΤΕΣ NOT ADDED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
			 echo "<br>Το ID χρήστη και η εξωτερική εσωτ.σύνδεση πρέπει να είναι τουλάχιστον 2 χαρακτήρες\n";
			 }
		 else
			{
			$stmt="INSERT INTO vicidial_remote_agents values('','$user_start','$number_of_lines','$server_ip','$conf_exten','$status','$campaign_id','$groups_value');";
			$rslt=mysql_query($stmt, $link);

			echo "<br><B>ΑΠΟΜΑΚΡΥΣΜΕΝΟΙ ΧΡΗΣΤΕΣ ΠΡΟΣΤΕΘΗΚΑΝ: $user_start</B>\n";

			### LOG CHANGES TO LOG FILE ###
			if ($WeBRooTWritablE > 0)
				{
				$fp = fopen ("./admin_changes_log.txt", "a");
				fwrite ($fp, "$date|ADD A NEW ΑΠΟΜΑΚΡΥΣΜΕΝΟΙ ΧΡΗΣΤΕΣ ENTRY     |$PHP_AUTH_USER|$ip|'$user_start','$number_of_lines','$server_ip','$conf_exten','$status','$campaign_id','$groups_value'|\n");
				fclose($fp);
				}
			}
		}
$ADD=10000;
}

######################
# ADD=211111 adds new user group to the system
######################

if ($ADD==211111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
	$stmt="SELECT count(*) from vicidial_user_groups where user_group='$user_group';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	if ($row[0] > 0)
		{echo "<br>ΔΕΝ ΠΡΟΣΤΕΘΗΚΕ Η ΟΜΑΔΑ ΧΡΗΣΤΗ - υπάρχει ήδη μία καταχώρηση ομάδας χρήστη με αυτό το όνομα\n";}
	else
		{
		 if ( (strlen($user_group) < 2) or (strlen($group_name) < 2) )
			{
			 echo "<br>USER GROUP NOT ADDED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
			 echo "<br>Η ομάδα και η περιγραφή πρέπει να είναι τουλάχιστον 2 χαρακτήρες\n";
			 }
		 else
			{
			$stmt="INSERT INTO vicidial_user_groups values('$user_group','$group_name');";
			$rslt=mysql_query($stmt, $link);

			echo "<br><B>USER ΟΜΑΔΑ ΠΡΟΣΤΕΘΗΚΕ: $user_start</B>\n";

			### LOG CHANGES TO LOG FILE ###
			if ($WeBRooTWritablE > 0)
				{
				$fp = fopen ("./admin_changes_log.txt", "a");
				fwrite ($fp, "$date|ΠΡΟΣΘΗΚΗ ΝΕΟΥ ΧΡΗΣΤΗ GROUP ENTRY     |$PHP_AUTH_USER|$ip|'$user_group','$group_name'|\n");
				fclose($fp);
				}
			}
		}
$ADD=100000;
}

######################
# ADD=2111111 adds new script to the system
######################

if ($ADD==2111111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
	$stmt="SELECT count(*) from vicidial_scripts where script_id='$script_id';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	if ($row[0] > 0)
		{echo "<br>ΧΕΙΡΟΓΡΑΦΟ ΠΡΟΣΤΙΘΕΜΕΝΟ - υπάρχει ήδη μια είσοδος χειρογράφων με αυτό το όνομα\n";}
	else
		{
		 if ( (strlen($script_id) < 2) or (strlen($script_name) < 2) or (strlen($script_text) < 2) )
			{
			 echo "<br>ΧΕΙΡΟΓΡΑΦΟ ΠΡΟΣΤΙΘΕΜΕΝΟ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
			 echo "<br>Το όνομα, η περιγραφή και το κείμενο χειρογράφων πρέπει να είναι τουλάχιστον 2 χαρακτήρες στο μήκος\n";
			 }
		 else
			{
			$stmt="INSERT INTO vicidial_scripts values('$script_id','$script_name','$script_comments','$script_text','$active');";
			$rslt=mysql_query($stmt, $link);

			echo "<br><B>ΧΕΙΡΟΓΡΑΦΟ ΠΡΟΣΤΙΘΕΜΕΝΟ: $script_id</B>\n";

			### LOG CHANGES TO LOG FILE ###
			if ($WeBRooTWritablE > 0)
				{
				$fp = fopen ("./admin_changes_log.txt", "a");
				fwrite ($fp, "$date|ADD A NEW SCRIPT ENTRY         |$PHP_AUTH_USER|$ip|'$script_id','$script_name','$script_comments','$script_text','$active'|\n");
				fclose($fp);
				}
			}
		}
$ADD=1000000;
}


######################
# ADD=21111111 adds new filter to the system
######################

if ($ADD==21111111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";
	$stmt="SELECT count(*) from vicidial_lead_filters where lead_filter_id='$lead_filter_id';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	if ($row[0] > 0)
		{echo "<br>ΦΙΛΤΡΟ ΠΡΟΣΤΙΘΕΜΕΝΟ - υπάρχει ήδη μια είσοδος φίλτρων με αυτήν την ταυτότητα\n";}
	else
		{
		 if ( (strlen($lead_filter_id) < 2) or (strlen($lead_filter_name) < 2) or (strlen($lead_filter_sql) < 2) )
			{
			 echo "<br>ΦΙΛΤΡΟ ΠΡΟΣΤΙΘΕΜΕΝΟ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
			 echo "<br>Η ταυτότητα φίλτρων, το όνομα και το SQL πρέπει να είναι τουλάχιστον 2 χαρακτήρες στο μήκος\n";
			 }
		 else
			{
			$stmt="INSERT INTO vicidial_lead_filters SET lead_filter_id='$lead_filter_id',lead_filter_name='$lead_filter_name',lead_filter_comments='$lead_filter_comments',lead_filter_sql='$lead_filter_sql';";
			$rslt=mysql_query($stmt, $link);

			echo "<br><B>ΤΟ ΦΙΛΤΡΟ ΠΡΟΣΘΕΣΕ: $lead_filter_id</B>\n";

			### LOG CHANGES TO LOG FILE ###
			if ($WeBRooTWritablE > 0)
				{
				$fp = fopen ("./admin_changes_log.txt", "a");
				fwrite ($fp, "$date|ADD A NEW FILTER ENTRY         |$PHP_AUTH_USER|$ip|lead_filter_id='$lead_filter_id',lead_filter_name='$lead_filter_name',lead_filter_comments='$lead_filter_comments',lead_filter_sql='$lead_filter_sql'|\n");
				fclose($fp);
				}
			}
		}
$ADD=10000000;
}





######################################################################################################
######################################################################################################
#######   4 series, record modifications submitted and DB is modified, then on to 3 series forms below
######################################################################################################
######################################################################################################



######################
# ADD=4A submit user modifications to the system - ADMIN
######################

if ($ADD=="4A")
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($pass) < 2) or (strlen($full_name) < 2) or (strlen($user_level) < 1) )
		{
		 echo "<br>USER NOT MODIFIED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Ο κωδικός και το πλήρες όνομα πρέπει να είναι τουλάχιστον 2 χαρακτήρες το κάθε ένα\n";
		}
	 else
		{
		echo "<br><B>ΧΡΗΣΤΗΣ ΤΡΟΠΟΠΟΙΗΘΗΚΕ - ADMIN: $user</B>\n";

		$stmt="UPDATE vicidial_users set pass='$pass',full_name='$full_name',user_level='$user_level',user_group='$user_group',phone_login='$phone_login',phone_pass='$phone_pass',delete_users='$delete_users',delete_user_groups='$delete_user_groups',delete_lists='$delete_lists',delete_campaigns='$delete_campaigns',delete_ingroups='$delete_ingroups',delete_remote_agents='$delete_remote_agents',load_leads='$load_leads',campaign_detail='$campaign_detail',ast_admin_access='$ast_admin_access',ast_delete_phones='$ast_delete_phones',delete_scripts='$delete_scripts',modify_leads='$modify_leads',hotkeys_active='$hotkeys_active',change_agent_campaign='$change_agent_campaign',agent_choose_ingroups='$agent_choose_ingroups',closer_campaigns='$groups_value',scheduled_callbacks='$scheduled_callbacks',agentonly_callbacks='$agentonly_callbacks',agentcall_manual='$agentcall_manual',vicidial_recording='$vicidial_recording',vicidial_transfers='$vicidial_transfers',delete_filters='$delete_filters',alter_agent_interface_options='$alter_agent_interface_options',closer_default_blended='$closer_default_blended' where user='$user';";
		$rslt=mysql_query($stmt, $link);



		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|MODIFY USER INFO    |$PHP_AUTH_USER|$ip|pass='$pass',full_name='$full_name',user_level='$user_level',user_group='$user_group',phone_login='$phone_login',phone_pass='$phone_pass',delete_users='$delete_users',delete_user_groups='$delete_user_groups',delete_lists='$delete_lists',delete_campaigns='$delete_campaigns',delete_ingroups='$delete_ingroups',delete_remote_agents='$delete_remote_agents',load_leads='$load_leads',campaign_detail='$campaign_detail',ast_admin_access='$ast_admin_access',ast_delete_phones='$ast_delete_phones',delete_scripts='$delete_scripts',modify_leads='$modify_leads',hotkeys_active='$hotkeys_active',change_agent_campaign='$change_agent_campaign',agent_choose_ingroups='$agent_choose_ingroups', closer_campaigns='$groups_value',scheduled_callbacks='$scheduled_callbacks',agentonly_callbacks='$agentonly_callbacks',agentcall_manual='$agentcall_manual',vicidial_recording='$vicidial_recording',vicidial_transfers='$vicidial_transfers',delete_filters='$delete_filters',alter_agent_interface_options='$alter_agent_interface_options',closer_default_blended='$closer_default_blended' where user='$user'|\n");
			fclose($fp);
			}
		}

$ADD=3;		# go to user modification below
}


######################
# ADD=4B submit user modifications to the system - ADMIN
######################

if ($ADD=="4B")
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($pass) < 2) or (strlen($full_name) < 2) or (strlen($user_level) < 1) )
		{
		 echo "<br>USER NOT MODIFIED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Ο κωδικός και το πλήρες όνομα πρέπει να είναι τουλάχιστον 2 χαρακτήρες το κάθε ένα\n";
		}
	 else
		{
		echo "<br><B>ΧΡΗΣΤΗΣ ΤΡΟΠΟΠΟΙΗΘΗΚΕ - ADMIN: $user</B>\n";

		$stmt="UPDATE vicidial_users set pass='$pass',full_name='$full_name',user_level='$user_level',user_group='$user_group',phone_login='$phone_login',phone_pass='$phone_pass',hotkeys_active='$hotkeys_active',agent_choose_ingroups='$agent_choose_ingroups',closer_campaigns='$groups_value',scheduled_callbacks='$scheduled_callbacks',agentonly_callbacks='$agentonly_callbacks',agentcall_manual='$agentcall_manual',vicidial_recording='$vicidial_recording',vicidial_transfers='$vicidial_transfers',closer_default_blended='$closer_default_blended' where user='$user';";
		$rslt=mysql_query($stmt, $link);



		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|MODIFY USER INFO    |$PHP_AUTH_USER|$ip|pass='$pass',full_name='$full_name',user_level='$user_level',user_group='$user_group',phone_login='$phone_login',phone_pass='$phone_pass',hotkeys_active='$hotkeys_active',agent_choose_ingroups='$agent_choose_ingroups',closer_campaigns='$groups_value',scheduled_callbacks='$scheduled_callbacks',agentonly_callbacks='$agentonly_callbacks',agentcall_manual='$agentcall_manual',vicidial_recording='$vicidial_recording',vicidial_transfers='$vicidial_transfers',closer_default_blended='$closer_default_blended' where user='$user'|\n");
			fclose($fp);
			}
		}

$ADD=3;		# go to user modification below
}



######################
# ADD=4 submit user modifications to the system
######################

if ($ADD==4)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($pass) < 2) or (strlen($full_name) < 2) or (strlen($user_level) < 1) )
		{
		 echo "<br>USER NOT MODIFIED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Ο κωδικός και το πλήρες όνομα πρέπει να είναι τουλάχιστον 2 χαρακτήρες το κάθε ένα\n";
		}
	 else
		{
		echo "<br><B>ΧΡΗΣΤΗΣ ΤΡΟΠΟΠΟΙΗΘΗΚΕ: $user</B>\n";

		$stmt="UPDATE vicidial_users set pass='$pass',full_name='$full_name',user_level='$user_level',user_group='$user_group',phone_login='$phone_login',phone_pass='$phone_pass' where user='$user';";
		$rslt=mysql_query($stmt, $link);

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|MODIFY USER INFO    |$PHP_AUTH_USER|$ip|pass='$pass',full_name='$full_name',user_level='$user_level',user_group='$user_group',phone_login='$phone_login',phone_pass='$phone_pass' where user='$user'|\n");
			fclose($fp);
			}
		}

$ADD=3;		# go to user modification below
}

######################
# ADD=41 submit campaign modifications to the system
######################

if ($ADD==41)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($campaign_name) < 6) or (strlen($active) < 1) )
		{
		 echo "<br>CAMPAIGN NOT MODIFIED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>το όνομα της εκστρατείας πρέπει να είναι τουλάχιστον 6 χαρακτήρες\n";
		}
	 else
		{
		echo "<br><B>ΕΣΤΡΑΤΕΙΑ ΤΡΟΠΟΠΟΙΗΘΗΚΕ: $campaign_id</B>\n";

		$stmt="UPDATE vicidial_campaigns set campaign_name='$campaign_name',active='$active',dial_status_a='$dial_status_a',dial_status_b='$dial_status_b',dial_status_c='$dial_status_c',dial_status_d='$dial_status_d',dial_status_e='$dial_status_e',lead_order='$lead_order',allow_closers='$allow_closers',hopper_level='$hopper_level', auto_dial_level='$auto_dial_level', next_agent_call='$next_agent_call', local_call_time='$local_call_time', voicemail_ext='$voicemail_ext', dial_timeout='$dial_timeout', dial_prefix='$dial_prefix', campaign_cid='$campaign_cid', campaign_vdad_exten='$campaign_vdad_exten', web_form_address='$web_form_address', park_ext='$park_ext', park_file_name='$park_file_name', campaign_rec_exten='$campaign_rec_exten', campaign_recording='$campaign_recording', campaign_rec_filename='$campaign_rec_filename', campaign_script='$script_id', get_call_launch='$get_call_launch', am_message_exten='$am_message_exten', amd_send_to_vmx='$amd_send_to_vmx', xferconf_a_dtmf='$xferconf_a_dtmf',xferconf_a_number='$xferconf_a_number', xferconf_b_dtmf='$xferconf_b_dtmf',xferconf_b_number='$xferconf_b_number',lead_filter_id='$lead_filter_id',alt_number_dialing='$alt_number_dialing',scheduled_callbacks='$scheduled_callbacks' where campaign_id='$campaign_id';";
		$rslt=mysql_query($stmt, $link);

		if ($reset_hopper == 'Y')
			{
			echo "<br>ΕΠΑΝΑΦΟΡΑ ΚΑΘΟΘΗΓΗΤΗ ΕΚΣΤΡΑΤΕΙΑΣ HOPPER\n";
			echo "<br> - Αναμονή 1 λεπτού πριν την κλήση του επόμενου αριθμού\n";
			$stmt="DELETE from vicidial_hopper where campaign_id='$campaign_id' and status='READY';";
			$rslt=mysql_query($stmt, $link);

			### LOG RESET TO LOG FILE ###
			if ($WeBRooTWritablE > 0)
				{
				$fp = fopen ("./admin_changes_log.txt", "a");
				fwrite ($fp, "$date|CAMPAIGN HOPPERRESET|$PHP_AUTH_USER|$ip|campaign_name='$campaign_name'|\n");
				fclose($fp);
				}
			}

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|MODIFY CAMPAIGN INFO|$PHP_AUTH_USER|$ip|campaign_name='$campaign_name',active='$active',dial_status_a='$dial_status_a',dial_status_b='$dial_status_b',dial_status_c='$dial_status_c',dial_status_d='$dial_status_d',dial_status_e='$dial_status_e',lead_order='$lead_order',allow_closers='$allow_closers',hopper_level='$hopper_level', auto_dial_level='$auto_dial_level', next_agent_call='$next_agent_call', local_call_time='$local_call_time', voicemail_ext='$voicemail_ext', dial_timeout='$dial_timeout', dial_prefix='$dial_prefix', campaign_cid='$campaign_cid', campaign_vdad_exten='$campaign_vdad_exten', web_form_address='$web_form_address', park_ext='$park_ext', park_file_name='$park_file_name', campaign_rec_exten='$campaign_rec_exten', campaign_recording='$campaign_recording', campaign_rec_filename='$campaign_rec_filename', campaign_script='$script_id', get_call_launch='$get_call_launch', am_message_exten='$am_message_exten', amd_send_to_vmx='$amd_send_to_vmx', xferconf_a_dtmf='$xferconf_a_dtmf',xferconf_a_number='$xferconf_a_number', xferconf_b_dtmf='$xferconf_b_dtmf',xferconf_b_number='$xferconf_b_number',lead_filter_id='$lead_filter_id',alt_number_dialing='$alt_number_dialing',scheduled_callbacks='$scheduled_callbacks' where campaign_id='$campaign_id'|$reset_hopper|\n");
			fclose($fp);
			}
		}

$ADD=31;	# go to campaign modification form below
}

######################
# ADD=42 delete campaign status in the system
######################

if ($ADD==42)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($campaign_id) < 2) or (strlen($status) < 1) )
		{
		 echo "<br>CAMPAIGN STATUS NOT MODIFIED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>το ID της εκστρατείας πρέπει να είναι τουλάχιστον 2 χαρακτήρες\n";
		 echo "<br>η κατάσταση της εκστρατείας πρέπει να είναι τουλάχιστον 1 χαρακτήρας\n";
		}
	 else
		{
		echo "<br><B>ΔΙΑΓΡΑΦΗΚΕ Η ΠΡΟΣΑΡΜΟΣΜΕΝΗ ΚΑΤΑΣΤΑΣΗ ΤΗΣ ΕΚΣΤΡΑΤΕΙΑΣ: $campaign_id - $status</B>\n";

		$stmt="DELETE FROM vicidial_campaign_statuses where campaign_id='$campaign_id' and status='$status';";
		$rslt=mysql_query($stmt, $link);

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|DELETE CAMPAIGN STATUS|$PHP_AUTH_USER|$ip|DELETE FROM vicidial_campaign_statuses where campaign_id='$campaign_id' and status='$status'|\n");
			fclose($fp);
			}
		}

$ADD=31;	# go to campaign modification form below
}

######################
# ADD=43 delete campaign hotkey in the system
######################

if ($ADD==43)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($campaign_id) < 2) or (strlen($status) < 1) or (strlen($hotkey) < 1) )
		{
		 echo "<br>CAMPAIGN HOTKEY NOT MODIFIED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>το ID της εκστρατείας πρέπει να είναι τουλάχιστον 2 χαρακτήρες\n";
		 echo "<br>η κατάσταση της εκστρατείας πρέπει να είναι τουλάχιστον 1 χαρακτήρας\n";
		 echo "<br>το κλειδί της εκστρατείας πρέπει να είναι τουλάχιστον 1 χαρακτήρας\n";
		}
	 else
		{
		echo "<br><B>ΔΙΑΦΡΑΦΗΚΕ ΤΟ ΠΡΟΣΑΡΜΟΣΜΕΝΟ ΚΛΕΙΔΙ ΤΗΣ ΕΚΣΤΡΑΤΕΙΑΣ: $campaign_id - $status - $hotkey</B>\n";

		$stmt="DELETE FROM vicidial_campaign_hotkeys where campaign_id='$campaign_id' and status='$status' and hotkey='$hotkey';";
		$rslt=mysql_query($stmt, $link);

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|DELETE CAMPAIGN STATUS|$PHP_AUTH_USER|$ip|DELETE FROM vicidial_campaign_statuses where campaign_id='$campaign_id' and status='$status' and hotkey='$hotkey'|\n");
			fclose($fp);
			}
		}

$ADD=31;	# go to campaign modification form below
}

######################
# ADD=44 submit campaign modifications to the system - Basic View
######################

if ($ADD==44)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($campaign_name) < 6) or (strlen($active) < 1) )
		{
		 echo "<br>CAMPAIGN NOT MODIFIED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>το όνομα της εκστρατείας πρέπει να είναι τουλάχιστον 6 χαρακτήρες\n";
		}
	 else
		{
		echo "<br><B>ΕΣΤΡΑΤΕΙΑ ΤΡΟΠΟΠΟΙΗΘΗΚΕ: $campaign_id</B>\n";

		$stmt="UPDATE vicidial_campaigns set campaign_name='$campaign_name',active='$active',dial_status_a='$dial_status_a',dial_status_b='$dial_status_b',dial_status_c='$dial_status_c',dial_status_d='$dial_status_d',dial_status_e='$dial_status_e',lead_order='$lead_order',hopper_level='$hopper_level', auto_dial_level='$auto_dial_level',lead_filter_id='$lead_filter_id' where campaign_id='$campaign_id';";
		$rslt=mysql_query($stmt, $link);

		if ($reset_hopper == 'Y')
			{
			echo "<br>ΕΠΑΝΑΦΟΡΑ ΚΑΘΟΘΗΓΗΤΗ ΕΚΣΤΡΑΤΕΙΑΣ HOPPER\n";
			echo "<br> - Αναμονή 1 λεπτού πριν την κλήση του επόμενου αριθμού\n";
			$stmt="DELETE from vicidial_hopper where campaign_id='$campaign_id' and status='READY';";
			$rslt=mysql_query($stmt, $link);

			### LOG HOPPER RESET TO LOG FILE ###
			if ($WeBRooTWritablE > 0)
				{
				$fp = fopen ("./admin_changes_log.txt", "a");
				fwrite ($fp, "$date|CAMPAIGN HOPPERRESET|$PHP_AUTH_USER|$ip|campaign_name='$campaign_name'|\n");
				fclose($fp);
				}
			}

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|MODIFY CAMPAIGN INFO|$PHP_AUTH_USER|$ip|campaign_name='$campaign_name',active='$active',dial_status_a='$dial_status_a',dial_status_b='$dial_status_b',dial_status_c='$dial_status_c',dial_status_d='$dial_status_d',dial_status_e='$dial_status_e',lead_order='$lead_order',hopper_level='$hopper_level', auto_dial_level='$auto_dial_level',lead_filter_id='$lead_filter_id' where campaign_id='$campaign_id'|$reset_hopper|\n");
			fclose($fp);
			}
		}

$ADD=34;	# go to campaign modification form below
}

######################
# ADD=411 submit list modifications to the system
######################

if ($ADD==411)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($list_name) < 2) or (strlen($campaign_id) < 2) )
		{
		 echo "<br>LIST NOT MODIFIED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>η λίστα πρέπει να είναι τουλαχιστον 2 χαρακτήρες\n";
		}
	 else
		{
		echo "<br><B>ΛΙΣΤΑ ΤΡΟΠΟΠΟΙΗΘΗΚΕ: $list_id</B>\n";

		$stmt="UPDATE vicidial_lists set list_name='$list_name',campaign_id='$campaign_id',active='$active' where list_id='$list_id';";
		$rslt=mysql_query($stmt, $link);

		if ($reset_list == 'Y')
			{
			echo "<br>ΕΠΑΝΑΦΟΡΑ ΚΑΤΑΣΤΑΣΗΣ ΚΛΗΣΗΣ ΛΙΣΤΑΣ\n";
			$stmt="UPDATE vicidial_list set called_since_last_reset='N' where list_id='$list_id';";
			$rslt=mysql_query($stmt, $link);
			### LOG RESET TO LOG FILE ###
			if ($WeBRooTWritablE > 0)
				{
				$fp = fopen ("./admin_changes_log.txt", "a");
				fwrite ($fp, "$date|RESET LIST CALLED   |$PHP_AUTH_USER|$ip|list_name='$list_name'|\n");
				fclose($fp);
				}
			}
		if ($campaign_id != "$old_campaign_id")
			{
			echo "<br>ΑΠΟΜΑΚΡΥΝΣΗ ΚΑΘΟΔΗΓΗΤΩΝ ΛΙΣΤΑΣ HOPPER ΑΠΟ ΠΑΛΑΙΑ HOPPER ΕΚΣΤΡΑΤΕΙΑ ($old_campaign_id)\n";
			$stmt="DELETE from vicidial_hopper where list_id='$list_id' and campaign_id='$old_campaign_id';";
			$rslt=mysql_query($stmt, $link);
			}

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|MODIFY LIST INFO    |$PHP_AUTH_USER|$ip|list_name='$list_name',campaign_id='$campaign_id',active='$active' where list_id='$list_id'|\n");
			fclose($fp);
			}
		}

$ADD=311;	# go to list modification form below
}


######################
# ADD=4111 modify in-group info in the system
######################

if ($ADD==4111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($group_name) < 2) or (strlen($group_color) < 2) )
		{
		 echo "<br>GROUP NOT MODIFIED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>το όνομα και χρώμα ομάδας πρέπει να είναι τουλάχιστον 2 χαρακτήρες\n";
		}
	 else
		{
		echo "<br><B>ΟΜΑΔΑ ΤΡΟΠΟΠΟΙΗΘΗΚΕ: $group_id</B>\n";

		$stmt="UPDATE vicidial_inbound_groups set group_name='$group_name', group_color='$group_color', active='$active', web_form_address='$web_form_address', voicemail_ext='$voicemail_ext', next_agent_call='$next_agent_call', fronter_display='$fronter_display', ingroup_script='$script_id', get_call_launch='$get_call_launch', xferconf_a_dtmf='$xferconf_a_dtmf',xferconf_a_number='$xferconf_a_number', xferconf_b_dtmf='$xferconf_b_dtmf',xferconf_b_number='$xferconf_b_number' where group_id='$group_id';";
		$rslt=mysql_query($stmt, $link);

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|MODIFY GROUP INFO   |$PHP_AUTH_USER|$ip|group_name='$group_name',group_color='$group_color',active='$active', web_form_address='$web_form_address', voicemail_ext='$voicemail_ext', next_agent_call='$next_agent_call', fronter_display='$fronter_display', ingroup_script='$script_id', get_call_launch='$get_call_launch', xferconf_a_dtmf='$xferconf_a_dtmf',xferconf_a_number='$xferconf_a_number', xferconf_b_dtmf='$xferconf_b_dtmf',xferconf_b_number='$xferconf_b_number'  where group_id='$group_id'|\n");
			fclose($fp);
			}
		}

$ADD=3111;	# go to in-group modification form below
}



######################
# ADD=41111 modify remote agents info in the system
######################

if ($ADD==41111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($server_ip) < 2) or (strlen($user_start) < 2)  or (strlen($campaign_id) < 2) or (strlen($conf_exten) < 2) )
		{
		 echo "<br>ΑΠΟΜΑΚΡΥΣΜΕΝΟΙ ΧΡΗΣΤΕΣ NOT MODIFIED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Το ID του χρήστη και η εξωτερική εσωτ.σύνδεση πρέπει να είναι τουλάχιστον 2 χαρακτήρες\n";
		}
	 else
		{
		$stmt="UPDATE vicidial_remote_agents set user_start='$user_start', number_of_lines='$number_of_lines', server_ip='$server_ip', conf_exten='$conf_exten', status='$status', campaign_id='$campaign_id', closer_campaigns='$groups_value' where remote_agent_id='$remote_agent_id';";
		$rslt=mysql_query($stmt, $link);

		echo "<br><B>ΑΠΟΜΑΚΡΥΣΜΕΝΟΙ ΧΡΗΣΤΕΣ ΤΡΟΠΟΠΟΙΗΘΗΚΑΝ</B>\n";

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|MODIFY ΑΠΟΜΑΚΡΥΣΜΕΝΟΙ ΧΡΗΣΤΕΣ ENTRY     |$PHP_AUTH_USER|$ip|set user_start='$user_start', number_of_lines='$number_of_lines', server_ip='$server_ip', conf_exten='$conf_exten', status='$status', campaign_id='$campaign_id', closer_campaigns='$groups_value' where remote_agent_id='$remote_agent_id'|\n");
			fclose($fp);
			}
		}

$ADD=31111;	# go to remote agents modification form below
}



######################
# ADD=411111 modify user group info in the system
######################

if ($ADD==411111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($user_group) < 2) or (strlen($group_name) < 2) )
		{
		 echo "<br>USER GROUP NOT MODIFIED - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Η ομάδα και η περιγραφή πρέπει να είναι τουλάχιστον 2 χαρακτήρες\n";
		}
	 else
		{
		$stmt="UPDATE vicidial_user_groups set user_group='$user_group', group_name='$group_name' where user_group='$OLDuser_group';";
		$rslt=mysql_query($stmt, $link);

		echo "<br><B>USER ΟΜΑΔΑ ΤΡΟΠΟΠΟΙΗΘΗΚΕ</B>\n";

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|MODIFY USER GROUP ENTRY     |$PHP_AUTH_USER|$ip|UPDATE vicidial_user_groups set user_group='$user_group', group_name='$group_name' where user_group='$OLDuser_group'|\n");
			fclose($fp);
			}
		}

$ADD=311111;	# go to user group modification form below
}

######################
# ADD=4111111 modify script in the system
######################

if ($ADD==4111111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($script_id) < 2) or (strlen($script_name) < 2) or (strlen($script_text) < 2) )
		{
		 echo "<br>ΧΕΙΡΟΓΡΑΦΟ ΤΡΟΠΟΠΟΙΗΜΕΝΟ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Το όνομα, η περιγραφή και το κείμενο χειρογράφων πρέπει να είναι τουλάχιστον 2 χαρακτήρες στο μήκος\n";
		}
	 else
		{
		$stmt="UPDATE vicidial_scripts set script_name='$script_name', script_comments='$script_comments', script_text='$script_text', active='$active' where script_id='$script_id';";
		$rslt=mysql_query($stmt, $link);

		echo "<br><B>ΧΕΙΡΟΓΡΑΦΟ ΤΡΟΠΟΠΟΙΗΜΕΝΟ</B>\n";

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|MODIFY SCRIPT ENTRY         |$PHP_AUTH_USER|$ip|UPDATE vicidial_scripts set script_name='$script_name', script_comments='$script_comments', script_text='$script_text', active='$active' where script_id='$script_id'|\n");
			fclose($fp);
			}
		}

$ADD=3111111;	# go to script modification form below
}


######################
# ADD=41111111 modify filter in the system
######################

if ($ADD==41111111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($lead_filter_id) < 2) or (strlen($lead_filter_name) < 2) or (strlen($lead_filter_sql) < 2) )
		{
		 echo "<br>ΦΙΛΤΡΟ ΤΡΟΠΟΠΟΙΗΜΕΝΟ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Η ταυτότητα φίλτρων, το όνομα και το SQL πρέπει να είναι τουλάχιστον 2 χαρακτήρες στο μήκος\n";
		}
	 else
		{
		$stmt="UPDATE vicidial_lead_filters set lead_filter_name='$lead_filter_name', lead_filter_comments='$lead_filter_comments', lead_filter_sql='$lead_filter_sql' where lead_filter_id='$lead_filter_id';";
		$rslt=mysql_query($stmt, $link);

		echo "<br><B>ΦΙΛΤΡΟ ΤΡΟΠΟΠΟΙΗΜΕΝΟ</B>\n";

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|MODIFY FILTER ENTRY         |$PHP_AUTH_USER|$ip|lead_filter_name='$lead_filter_name', lead_filter_comments='$lead_filter_comments', lead_filter_sql='$lead_filter_sql' where lead_filter_id='$lead_filter_id'|\n");
			fclose($fp);
			}
		}

$ADD=31111111;	# go to filter modification form below
}




######################################################################################################
######################################################################################################
#######   5 series, delete records confirmation
######################################################################################################
######################################################################################################


######################
# ADD=5 confirmation before deletion of user
######################

if ($ADD==5)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($user) < 2) or ($LOGdelete_users < 1) )
		{
		 echo "<br>ΧΡΗΣΤΗΣ ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>User be at least 2 characters in length\n";
		}
	 else
		{
		echo "<br><B>ΕΠΙΒΕΒΑΙΩΣΗ ΔΙΑΓΡΑΦΗΣ ΧΡΗΣΤΩΝ: $user</B>\n";
		echo "<br><br><a href=\"$PHP_SELF?ADD=6&user=$user&CoNfIrM=YES\">Χτυπήστε εδώ για να διαγράψετε το χρήστη $user</a><br><br><br>\n";
		}

$ADD='3';		# go to user modification below
}

######################
# ADD=51 confirmation before deletion of campaign
######################

if ($ADD==51)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($campaign_id) < 2) or ($LOGdelete_campaigns < 1) )
		{
		 echo "<br>ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ ΕΚΣΤΡΑΤΕΙΑ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Εκστρατείας_id be at least 2 characters in length\n";
		}
	 else
		{
		echo "<br><B>ΕΠΙΒΕΒΑΙΩΣΗ ΔΙΑΓΡΑΦΗΣ ΕΚΣΤΡΑΤΕΙΑΣ: $campaign_id</B>\n";
		echo "<br><br><a href=\"$PHP_SELF?ADD=61&campaign_id=$campaign_id&CoNfIrM=YES\">Χτυπήστε εδώ για να διαγράψετε την εκστρατεία $campaign_id</a><br><br><br>\n";
		}

$ADD='31';		# go to campaign modification below
}

######################
# ADD=52 confirmation before logging all agents out of campaign of campaign
######################

if ($ADD==52)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if (strlen($campaign_id) < 2)
		{
		 echo "<br>ΠΡΑΚΤΟΡΕΣ ΠΟΥ ΔΕΝ ΚΑΤΑΓΡΑΦΟΝΤΑΙ ΑΠΟ ΤΗΝ ΕΚΣΤΡΑΤΕΙΑ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Εκστρατείας_id be at least 2 characters in length\n";
		}
	 else
		{
		echo "<br><B>ΕΠΙΒΕΒΑΙΩΣΗ ΑΠΟΣΥΝΔΕΣΗΣ ΠΡΑΚΤΟΡΩΝ: $campaign_id</B>\n";
		echo "<br><br><a href=\"$PHP_SELF?ADD=62&campaign_id=$campaign_id&CoNfIrM=YES\">Χτυπήστε εδώ για να καταγράψετε όλους τους πράκτορες από $campaign_id</a><br><br><br>\n";
		}

$ADD='31';		# go to campaign modification below
}

######################
# ADD=511 confirmation before deletion of list
######################

if ($ADD==511)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($list_id) < 2) or ($LOGdelete_lists < 1) )
		{
		 echo "<br>ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ ΚΑΤΑΛΟΓΟΣ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>List_id be at least 2 characters in length\n";
		}
	 else
		{
		echo "<br><B>ΕΠΙΒΕΒΑΙΩΣΗ ΔΙΑΓΡΑΦΗΣ ΚΑΤΑΛΟΓΩΝ: $list_id</B>\n";
		echo "<br><br><a href=\"$PHP_SELF?ADD=611&list_id=$list_id&CoNfIrM=YES\">Χτυπήστε εδώ για να διαγράψετε τον κατάλογο και τους όλους μολύβδους του $list_id</a><br><br><br>\n";
		}

$ADD='311';		# go to campaign modification below
}

######################
# ADD=5111 confirmation before deletion of in-group
######################

if ($ADD==5111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($group_id) < 2) or ($LOGdelete_ingroups < 1) )
		{
		 echo "<br>ΣΤΗΝ-ΟΜΑΔΑ ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Group_id be at least 2 characters in length\n";
		}
	 else
		{
		echo "<br><B>ΣΤΗΝ-ΟΜΑΔΑ ΕΠΙΒΕΒΑΙΩΣΗ ΔΙΑΓΡΑΦΗΣ: $group_id</B>\n";
		echo "<br><br><a href=\"$PHP_SELF?ADD=6111&group_id=$group_id&CoNfIrM=YES\">Χτυπήστε εδώ για να διαγράψετε την-ΟΜΑΔΑ $group_id</a><br><br><br>\n";
		}

$ADD='3111';		# go to in-group modification below
}

######################
# ADD=51111 confirmation before deletion of remote agent record
######################

if ($ADD==51111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($remote_agent_id) < 1) or ($LOGdelete_remote_agents < 1) )
		{
		 echo "<br>ΜΑΚΡΙΝΟΣ ΠΡΑΚΤΟΡΑΣ ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Remote_agent_id be at least 2 characters in length\n";
		}
	 else
		{
		echo "<br><B>ΜΑΚΡΙΝΗ ΕΠΙΒΕΒΑΙΩΣΗ ΔΙΑΓΡΑΦΗΣ ΠΡΑΚΤΟΡΩΝ: $remote_agent_id</B>\n";
		echo "<br><br><a href=\"$PHP_SELF?ADD=61111&remote_agent_id=$remote_agent_id&CoNfIrM=YES\">Χτυπήστε εδώ για να διαγράψετε το μακρινό πράκτορα $remote_agent_id</a><br><br><br>\n";
		}

$ADD='31111';		# go to remote agent modification below
}

######################
# ADD=511111 confirmation before deletion of user group record
######################

if ($ADD==511111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($user_group) < 2) or ($LOGdelete_user_groups < 1) )
		{
		 echo "<br>ΟΜΑΔΑ ΧΡΗΣΤΩΝ ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>User_group be at least 2 characters in length\n";
		}
	 else
		{
		echo "<br><B>ΕΠΙΒΕΒΑΙΩΣΗ ΔΙΑΓΡΑΦΗΣ ΟΜΑΔΑΣ ΧΡΗΣΤΩΝ: $user_group</B>\n";
		echo "<br><br><a href=\"$PHP_SELF?ADD=611111&user_group=$user_group&CoNfIrM=YES\">Χτυπήστε εδώ για να διαγράψετε το χρήστη group $user_group</a><br><br><br>\n";
		}

$ADD='311111';		# go to user group modification below
}

######################
# ADD=5111111 confirmation before deletion of script record
######################

if ($ADD==5111111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($script_id) < 2) or ($LOGdelete_scripts < 1) )
		{
		 echo "<br>ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ ΧΕΙΡΟΓΡΑΦΟ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Script_id must be at least 2 characters in length\n";
		}
	 else
		{
		echo "<br><B>ΕΠΙΒΕΒΑΙΩΣΗ ΔΙΑΓΡΑΦΗΣ ΧΕΙΡΟΓΡΑΦΩΝ: $script_id</B>\n";
		echo "<br><br><a href=\"$PHP_SELF?ADD=6111111&script_id=$script_id&CoNfIrM=YES\">Χτυπήστε εδώ για να διαγράψετε το χειρόγραφο $script_id</a><br><br><br>\n";
		}

$ADD='3111111';		# go to script modification below
}

######################
# ADD=51111111 confirmation before deletion of filter record
######################

if ($ADD==51111111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($lead_filter_id) < 2) or ($LOGdelete_filters < 1) )
		{
		 echo "<br>ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ ΦΙΛΤΡΟ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Η ταυτότητα φίλτρων πρέπει να είναι τουλάχιστον 2 χαρακτήρες στο μήκος\n";
		}
	 else
		{
		echo "<br><B>FILTER DELETION CONFIRMATION: $lead_filter_id</B>\n";
		echo "<br><br><a href=\"$PHP_SELF?ADD=61111111&lead_filter_id=$lead_filter_id&CoNfIrM=YES\">Χτυπήστε εδώ για να διαγράψετε το φίλτρο$lead_filter_id</a><br><br><br>\n";
		}

$ADD='31111111';		# go to filter modification below
}





######################################################################################################
######################################################################################################
#######   6 series, delete records
######################################################################################################
######################################################################################################


######################
# ADD=6 delete user record
######################

if ($ADD==6)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( ( strlen($user) < 2) or ($CoNfIrM != 'YES') or ($LOGdelete_users < 1) )
		{
		 echo "<br>ΧΡΗΣΤΗΣ ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>User be at least 2 characters in length\n";
		}
	 else
		{
		$stmt="DELETE from vicidial_users where user='$user' limit 1;";
		$rslt=mysql_query($stmt, $link);

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|!!!DELETING USER!!!!|$PHP_AUTH_USER|$ip|user='$user'|\n");
			fclose($fp);
			}
		echo "<br><B>ΔΙΑΓΡΑΦΗ ΧΡΗΣΤΩΝ ΠΟΥ ΟΛΟΚΛΗΡΩΝΕΤΑΙ: $user</B>\n";
		echo "<br><br>\n";
		}

$ADD='0';		# go to user list
}

######################
# ADD=61 delete campaign record
######################

if ($ADD==61)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( ( strlen($campaign_id) < 2) or ($CoNfIrM != 'YES') or ($LOGdelete_campaigns < 1) )
		{
		 echo "<br>ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ ΕΚΣΤΡΑΤΕΙΑ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Εκστρατείας_id be at least 2 characters in length\n";
		}
	 else
		{
		$stmt="DELETE from vicidial_campaigns where campaign_id='$campaign_id' limit 1;";
		$rslt=mysql_query($stmt, $link);

		echo "<br>ΑΠΟΜΑΚΡΥΝΣΗ ΚΑΘΟΔΗΓΗΤΩΝ ΛΙΣΤΑΣ HOPPER ΑΠΟ ΠΑΛΑΙΑ HOPPER ΕΚΣΤΡΑΤΕΙΑ ($campaign_id)\n";
		$stmt="DELETE from vicidial_hopper where campaign_id='$campaign_id';";
		$rslt=mysql_query($stmt, $link);

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|!!DELETING CAMPAIGN!|$PHP_AUTH_USER|$ip|campaign_id='$campaign_id'|\n");
			fclose($fp);
			}
		echo "<br><B>ΔΙΑΓΡΑΦΗ ΕΚΣΤΡΑΤΕΙΑΣ ΠΟΥ ΟΛΟΚΛΗΡΩΝΕΤΑΙ: $campaign_id</B>\n";
		echo "<br><br>\n";
		}

$ADD='10';		# go to campaigns list
}

######################
# ADD=62 Logout all agents fro a campaign
######################

if ($ADD==62)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if (strlen($campaign_id) < 2)
		{
		 echo "<br>ΠΡΑΚΤΟΡΕΣ ΠΟΥ ΔΕΝ ΚΑΤΑΓΡΑΦΟΝΤΑΙ ΑΠΟ ΤΗΝ ΕΚΣΤΡΑΤΕΙΑ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Εκστρατείας_id be at least 2 characters in length\n";
		}
	 else
		{
		$stmt="DELETE from vicidial_live_agents where campaign_id='$campaign_id';";
		$rslt=mysql_query($stmt, $link);

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|!!ΠΡΑΚΤΟΡΑΣ LOGOUT!!!!!!|$PHP_AUTH_USER|$ip|campaign_id='$campaign_id'|\n");
			fclose($fp);
			}
		echo "<br><B>ΑΠΟΣΥΝΔΕΣΗ ΠΡΑΚΤΟΡΩΝ ΠΟΥ ΟΛΟΚΛΗΡΩΝΕΤΑΙ: $campaign_id</B>\n";
		echo "<br><br>\n";
		}

$ADD='31';		# go to campaign modification below
}
######################
# ADD=611 delete list record and all leads within it
######################

if ($ADD==611)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( ( strlen($list_id) < 2) or ($CoNfIrM != 'YES') or ($LOGdelete_lists < 1) )
		{
		 echo "<br>ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ ΚΑΤΑΛΟΓΟΣ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>List_id be at least 2 characters in length\n";
		}
	 else
		{
		$stmt="DELETE from vicidial_lists where list_id='$list_id' limit 1;";
		$rslt=mysql_query($stmt, $link);

		echo "<br>ΑΠΟΜΑΚΡΥΝΣΗ ΚΑΘΟΔΗΓΗΤΩΝ ΛΙΣΤΑΣ HOPPER ΑΠΟ ΠΑΛΑΙΑ HOPPER ΕΚΣΤΡΑΤΕΙΑ ($list_id)\n";
		$stmt="DELETE from vicidial_hopper where list_id='$list_id';";
		$rslt=mysql_query($stmt, $link);

		echo "<br>ΑΦΑΙΡΕΣΗ ΤΩΝ ΜΟΛΥΒΔΩΝ ΚΑΤΑΛΟΓΩΝ ΑΠΟ ΤΟΝ ΠΊΝΑΚΑ VICIDIAL_LIST\n";
		$stmt="DELETE from vicidial_list where list_id='$list_id';";
		$rslt=mysql_query($stmt, $link);

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|!!!DELETING LIST!!!!|$PHP_AUTH_USER|$ip|list_id='$list_id'|\n");
			fclose($fp);
			}
		echo "<br><B>ΔΙΑΓΡΑΦΗ ΚΑΤΑΛΟΓΩΝ ΠΟΥ ΟΛΟΚΛΗΡΩΝΕΤΑΙ: $list_id</B>\n";
		echo "<br><br>\n";
		}

$ADD='100';		# go to lists list
}

######################
# ADD=6111 delete in-group record
######################

if ($ADD==6111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($group_id) < 2) or ($CoNfIrM != 'YES') or ($LOGdelete_ingroups < 1) )
		{
		 echo "<br>ΣΤΗΝ-ΟΜΑΔΑ ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Group_id be at least 2 characters in length\n";
		}
	 else
		{
		$stmt="DELETE from vicidial_inbound_groups where group_id='$group_id' limit 1;";
		$rslt=mysql_query($stmt, $link);

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|!DELETING IN-GROUP!!|$PHP_AUTH_USER|$ip|group_id='$group_id'|\n");
			fclose($fp);
			}
		echo "<br><B>ΣΤΗΝ-ΟΜΑΔΑ ΔΙΑΓΡΑΦΗ ΠΟΥ ΟΛΟΚΛΗΡΩΝΕΤΑΙ: $group_id</B>\n";
		echo "<br><br>\n";
		}

$ADD='1000';		# go to in-group list
}

######################
# ADD=61111 delete remote agent record
######################

if ($ADD==61111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($remote_agent_id) < 1) or ($CoNfIrM != 'YES') or ($LOGdelete_remote_agents < 1) )
		{
		 echo "<br>ΜΑΚΡΙΝΟΣ ΠΡΑΚΤΟΡΑΣ ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Remote_agent_id be at least 2 characters in length\n";
		}
	 else
		{
		$stmt="DELETE from vicidial_remote_agents where remote_agent_id='$remote_agent_id' limit 1;";
		$rslt=mysql_query($stmt, $link);

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|!DELETING RMTAGENT!!|$PHP_AUTH_USER|$ip|remote_agent_id='$remote_agent_id'|\n");
			fclose($fp);
			}
		echo "<br><B>ΜΑΚΡΙΝΗ ΔΙΑΓΡΑΦΗ ΠΡΑΚΤΟΡΩΝ ΠΟΥ ΟΛΟΚΛΗΡΩΝΕΤΑΙ: $remote_agent_id</B>\n";
		echo "<br><br>\n";
		}

$ADD='10000';		# go to remote agents list
}

######################
# ADD=611111 delete user group record
######################

if ($ADD==611111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($user_group) < 2) or ($CoNfIrM != 'YES') or ($LOGdelete_user_groups < 1) )
		{
		 echo "<br>ΟΜΑΔΑ ΧΡΗΣΤΩΝ ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>User_group be at least 2 characters in length\n";
		}
	 else
		{
		$stmt="DELETE from vicidial_user_groups where user_group='$user_group' limit 1;";
		$rslt=mysql_query($stmt, $link);

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|!DELETING USRGROUP!!|$PHP_AUTH_USER|$ip|user_group='$user_group'|\n");
			fclose($fp);
			}
		echo "<br><B>ΔΙΑΓΡΑΦΗ ΟΜΑΔΑΣ ΧΡΗΣΤΩΝ ΠΟΥ ΟΛΟΚΛΗΡΩΝΕΤΑΙ: $user_group</B>\n";
		echo "<br><br>\n";
		}

$ADD='100000';		# go to user group list
}

######################
# ADD=6111111 delete script record
######################

if ($ADD==6111111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($script_id) < 2) or ($CoNfIrM != 'YES') or ($LOGdelete_scripts < 1) )
		{
		 echo "<br>ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ ΧΕΙΡΟΓΡΑΦΟ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Script_id be at least 2 characters in length\n";
		}
	 else
		{
		$stmt="DELETE from vicidial_scripts where script_id='$script_id' limit 1;";
		$rslt=mysql_query($stmt, $link);

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|!DELETING SCRIPT!!!!|$PHP_AUTH_USER|$ip|script_id='$script_id'|\n");
			fclose($fp);
			}
		echo "<br><B>ΔΙΑΓΡΑΦΗ ΧΕΙΡΟΓΡΑΦΩΝ ΠΟΥ ΟΛΟΚΛΗΡΩΝΕΤΑΙ: $script_id</B>\n";
		echo "<br><br>\n";
		}

$ADD='1000000';		# go to user group list
}


######################
# ADD=61111111 delete script record
######################

if ($ADD==61111111)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	 if ( (strlen($lead_filter_id) < 2) or ($CoNfIrM != 'YES') or ($LOGdelete_filters < 1) )
		{
		 echo "<br>ΠΟΥ ΔΕΝ ΔΙΑΓΡΑΦΕΤΑΙ ΦΙΛΤΡΟ - Παρακαλώ επιστρέψτε και εξετάστε τα στοιχεία που εισαγάγατε\n";
		 echo "<br>Η ταυτότητα φίλτρων πρέπει να είναι τουλάχιστον 2 χαρακτήρες στο μήκος\n";
		}
	 else
		{
		$stmt="DELETE from vicidial_lead_filters where lead_filter_id='$lead_filter_id' limit 1;";
		$rslt=mysql_query($stmt, $link);

		### LOG CHANGES TO LOG FILE ###
		if ($WeBRooTWritablE > 0)
			{
			$fp = fopen ("./admin_changes_log.txt", "a");
			fwrite ($fp, "$date|!DELETING FILTER!!!!|$PHP_AUTH_USER|$ip|lead_filter_id='$lead_filter_id'|\n");
			fclose($fp);
			}
		echo "<br><B>ΔΙΑΓΡΑΦΗ ΦΙΛΤΡΩΝ ΠΟΥ ΟΛΟΚΛΗΡΩΝΕΤΑΙ: $lead_filter_id</B>\n";
		echo "<br><br>\n";
		}

$ADD='10000000';		# go to user group list
}




######################################################################################################
######################################################################################################
#######   3 series, record modification forms
######################################################################################################
######################################################################################################




######################
# ADD=3 modify user info in the system
######################

if ($ADD==3)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_users where user='$user';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$user_level =			$row[4];
	$user_group =			$row[5];
	$phone_login =			$row[6];
	$phone_pass =			$row[7];
	$delete_users =			$row[8];
	$delete_user_groups =	$row[9];
	$delete_lists =			$row[10];
	$delete_campaigns =		$row[11];
	$delete_ingroups =		$row[12];
	$delete_remote_agents =	$row[13];
	$load_leads =			$row[14];
	$campaign_detail =		$row[15];
	$ast_admin_access =		$row[16];
	$ast_delete_phones =	$row[17];
	$delete_scripts =		$row[18];
	$modify_leads =			$row[19];
	$hotkeys_active =		$row[20];
	$change_agent_campaign =$row[21];
	$agent_choose_ingroups =$row[22];
	$scheduled_callbacks =	$row[24];
	$agentonly_callbacks =	$row[25];
	$agentcall_manual =		$row[26];
	$vicidial_recording =	$row[27];
	$vicidial_transfers =	$row[28];
	$delete_filters =		$row[29];
	$alter_agent_interface_options =$row[30];
	$closer_default_blended =		$row[31];

if ( ($user_level >= $LOGuser_level) and ($LOGuser_level < 9) )
	{
	echo "<br>Δεν έχετε τις άδειες να τροποποιήσετε αυτόν τον χρήστη: $row[1]\n";
	}
else
	{
	echo "<br>ΤΡΟΠΟΠΟΙΗΣΗ ΕΓΓΡΑΦΗΣ ΧΡΗΣΤΩΝ: $row[1]<form action=$PHP_SELF method=POST>\n";
	if ($LOGuser_level > 8)
		{echo "<input type=hidden name=ADD value=4A>\n";}
	else
		{
		if ($LOGalter_agent_interface == "1")
			{echo "<input type=hidden name=ADD value=4B>\n";}
		else
			{echo "<input type=hidden name=ADD value=4>\n";}
		}
	echo "<input type=hidden name=user value=\"$row[1]\">\n";
	echo "<center><TABLE width=600 cellspacing=3>\n";
	echo "<tr bgcolor=#B6D3FC><td align=right>Αριθμός Χρήστη: </td><td align=left><b>$row[1]</b>$NWB#vicidial_users-user$NWE</td></tr>\n";
	echo "<tr bgcolor=#B6D3FC><td align=right>Κωδικός:</td><td align=left><input type=text name=pass size=20 maxlength=10 value=\"$row[2]\">$NWB#vicidial_users-pass$NWE</td></tr>\n";
	echo "<tr bgcolor=#B6D3FC><td align=right>Πλήρες Ονομα: </td><td align=left><input type=text name=full_name size=30 maxlength=30 value=\"$row[3]\">$NWB#vicidial_users-full_name$NWE</td></tr>\n";
	echo "<tr bgcolor=#B6D3FC><td align=right>Επίπεδο Χρήστη: </td><td align=left><select size=1 name=user_level>";
	$h=1;
	while ($h<=$LOGuser_level)
		{
		echo "<option>$h</option>";
		$h++;
		}
	echo "<option SELECTED>$row[4]</option></select>$NWB#vicidial_users-user_level$NWE</td></tr>\n";
	echo "<tr bgcolor=#B6D3FC><td align=right>Ομάδα Χρήστη: </td><td align=left><select size=1 name=user_group>\n";

		$stmt="SELECT user_group,group_name from vicidial_user_groups order by user_group";
		$rsltx=mysql_query($stmt, $link);
		$Ugroups_to_print = mysql_num_rows($rsltx);
		$Ugroups_list='';

		$o=0;
		while ($Ugroups_to_print > $o) {
			$rowx=mysql_fetch_row($rsltx);
			$Ugroups_list .= "<option value=\"$rowx[0]\">$rowx[0] - $rowx[1]</option>\n";
			$o++;
		}
	echo "$Ugroups_list";
	echo "<option SELECTED>$user_group</option>\n";
	echo "</select>$NWB#vicidial_users-user_group$NWE</td></tr>\n";
	echo "<tr bgcolor=#B6D3FC><td align=right>Τηλεφωνική σύνδεση: </td><td align=left><input type=text name=phone_login size=20 maxlength=20 value=\"$phone_login\">$NWB#vicidial_users-phone_login$NWE</td></tr>\n";
	echo "<tr bgcolor=#B6D3FC><td align=right>Τηλεφωνικός κωδικός πρόσβασης: </td><td align=left><input type=text name=phone_pass size=20 maxlength=20 value=\"$phone_pass\">$NWB#vicidial_users-phone_pass$NWE</td></tr>\n";

	if ( ($LOGuser_level > 8) or ($LOGalter_agent_interface == "1") )
		{
		echo "<tr bgcolor=BLACK><td colspan=2 align=center><font color=white><B>ΕΠΙΛΟΓΕΣ ΔΙΕΠΑΦΩΝ ΠΡΑΚΤΟΡΩΝ:</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Ο πράκτορας επιλέγει Ingroups: </td><td align=left><select size=1 name=agent_choose_ingroups><option>0</option><option>1</option><option SELECTED>$agent_choose_ingroups</option></select>$NWB#vicidial_users-agent_choose_ingroups$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>HotKeys ενεργός: </td><td align=left><select size=1 name=hotkeys_active><option>0</option><option>1</option><option SELECTED>$hotkeys_active</option></select>$NWB#vicidial_users-hotkeys_active$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Σχέδισσες επανακλήσεις: </td><td align=left><select size=1 name=scheduled_callbacks><option>0</option><option>1</option><option SELECTED>$scheduled_callbacks</option></select>$NWB#vicidial_users-scheduled_callbacks$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Πράκτορας-μόνο επανακλήσεις: </td><td align=left><select size=1 name=agentonly_callbacks><option>0</option><option>1</option><option SELECTED>$agentonly_callbacks</option></select>$NWB#vicidial_users-agentonly_callbacks$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Εγχειρίδιο κλήσης πρακτόρων: </td><td align=left><select size=1 name=agentcall_manual><option>0</option><option>1</option><option SELECTED>$agentcall_manual</option></select>$NWB#vicidial_users-agentcall_manual$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Καταγραφή Vicidial: </td><td align=left><select size=1 name=vicidial_recording><option>0</option><option>1</option><option SELECTED>$vicidial_recording</option></select>$NWB#vicidial_users-vicidial_recording$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Μεταφορές Vicidial: </td><td align=left><select size=1 name=vicidial_transfers><option>0</option><option>1</option><option SELECTED>$vicidial_transfers</option></select>$NWB#vicidial_users-vicidial_transfers$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Η πιό στενή προεπιλογή συνδύασε: </td><td align=left><select size=1 name=closer_default_blended><option>0</option><option>1</option><option SELECTED>$closer_default_blended</option></select>$NWB#vicidial_users-closer_default_blended$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Εισερχόμενες Ομάδες: </td><td align=left>\n";
		echo "$groups_list";
		echo "$NWB#vicidial_users-closer_campaigns$NWE</td></tr>\n";
		}
	if ($LOGuser_level > 8)
		{
		echo "<tr bgcolor=BLACK><td colspan=2 align=center><font color=white><B>ΕΠΙΛΟΓΈΣ ΔΙΕΠΑΦΏΝ ADMIN:</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Αλλάξτε τις επιλογές διεπαφών πρακτόρων: </td><td align=left><select size=1 name=alter_agent_interface_options><option>0</option><option>1</option><option SELECTED>$alter_agent_interface_options</option></select>$NWB#vicidial_users-alter_agent_interface_options$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Διαγράψτε τους χρήστες: </td><td align=left><select size=1 name=delete_users><option>0</option><option>1</option><option SELECTED>$delete_users</option></select>$NWB#vicidial_users-delete_users$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Διαγράψτε τις ομάδες χρηστών: </td><td align=left><select size=1 name=delete_user_groups><option>0</option><option>1</option><option SELECTED>$delete_user_groups</option></select>$NWB#vicidial_users-delete_user_groups$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Διαγράψτε τους καταλόγους: </td><td align=left><select size=1 name=delete_lists><option>0</option><option>1</option><option SELECTED>$delete_lists</option></select>$NWB#vicidial_users-delete_lists$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Διαγράψτε τις εκστρατείες: </td><td align=left><select size=1 name=delete_campaigns><option>0</option><option>1</option><option SELECTED>$delete_campaigns</option></select>$NWB#vicidial_users-delete_campaigns$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Διαγράψτε τις-ΟΜΑΔΕΣ: </td><td align=left><select size=1 name=delete_ingroups><option>0</option><option>1</option><option SELECTED>$delete_ingroups</option></select>$NWB#vicidial_users-delete_ingroups$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Διαγράψτε τους μακρινούς πράκτορες: </td><td align=left><select size=1 name=delete_remote_agents><option>0</option><option>1</option><option SELECTED>$delete_remote_agents</option></select>$NWB#vicidial_users-delete_remote_agents$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Διαγράψτε το χειρόγραφοs: </td><td align=left><select size=1 name=delete_scripts><option>0</option><option>1</option><option SELECTED>$delete_scripts</option></select>$NWB#vicidial_users-delete_scripts$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Το φορτίο οδηγεί: </td><td align=left><select size=1 name=load_leads><option>0</option><option>1</option><option SELECTED>$load_leads</option></select>$NWB#vicidial_users-load_leads$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Λεπτομέρεια εκστρατείας: </td><td align=left><select size=1 name=campaign_detail><option>0</option><option>1</option><option SELECTED>$campaign_detail</option></select>$NWB#vicidial_users-campaign_detail$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Πρόσβαση AGC Admin: </td><td align=left><select size=1 name=ast_admin_access><option>0</option><option>1</option><option SELECTED>$ast_admin_access</option></select>$NWB#vicidial_users-ast_admin_access$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Το AGC διαγράφει τα τηλέφωνα: </td><td align=left><select size=1 name=ast_delete_phones><option>0</option><option>1</option><option SELECTED>$ast_delete_phones</option></select>$NWB#vicidial_users-ast_delete_phones$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Τροποποιήστε τους μολύβδους: </td><td align=left><select size=1 name=modify_leads><option>0</option><option>1</option><option SELECTED>$modify_leads</option></select>$NWB#vicidial_users-modify_leads$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Εκστρατεία πρακτόρων αλλαγής: </td><td align=left><select size=1 name=change_agent_campaign><option>0</option><option>1</option><option SELECTED>$change_agent_campaign</option></select>$NWB#vicidial_users-change_agent_campaign$NWE</td></tr>\n";
		echo "<tr bgcolor=#B6D3FC><td align=right>Διαγράψτε το φίλτροs: </td><td align=left><select size=1 name=delete_filters><option>0</option><option>1</option><option SELECTED>$delete_filters</option></select>$NWB#vicidial_users-delete_filters$NWE</td></tr>\n";
		}
	echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
	echo "</TABLE></center>\n";

	if ($LOGdelete_users > 0)
		{
		echo "<br><br><a href=\"$PHP_SELF?ADD=5&user=$row[1]\">ΔΙΑΓΡΑΨΤΕ ΑΥΤΟΝ ΤΟΝ ΧΡΗΣΤΗ</a>\n";
		}
	echo "<br><br><a href=\"./AST_agent_time_sheet.php?agent=$row[1]\">Χτυπήστε εδώ για το δελτίο παρουσίας χρηστών</a>\n";
	echo "<br><br><a href=\"./user_status.php?user=$row[1]\">Χτυπήστε εδώ για τη θέση χρηστών</a>\n";
	echo "<br><br><a href=\"./user_stats.php?user=$row[1]\">Πατήστε εδώ για στατιστικά χρήστη</a>\n";
	echo "<br><br><a href=\"$PHP_SELF?ADD=8&user=$row[1]\">Χτυπήστε εδώ για την πλάτη κλήσης χρηστών κρατά</a>\n";
	}

}


######################
# ADD=31 modify campaign info in the system - Detail view
######################

if ( ($LOGcampaign_detail < 1) and ($ADD==31) ) {$ADD=34;}	# send to Basic if not allowed

if ($ADD==31)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_campaigns where campaign_id='$campaign_id';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$dial_status_a = $row[3];
	$dial_status_b = $row[4];
	$dial_status_c = $row[5];
	$dial_status_d = $row[6];
	$dial_status_e = $row[7];
	$lead_order = $row[8];
	$hopper_level = $row[13];
	$auto_dial_level = $row[14];
	$next_agent_call = $row[15];
	$local_call_time = $row[16];
	$voicemail_ext = $row[17];
	$dial_timeout = $row[18];
	$dial_prefix = $row[19];
	$campaign_cid = $row[20];
	$campaign_vdad_exten = $row[21];
	$campaign_rec_exten = $row[22];
	$campaign_recording = $row[23];
	$campaign_rec_filename = $row[24];
	$script_id = $row[25];
	$get_call_launch = $row[26];
	$am_message_exten = $row[27];
	$amd_send_to_vmx = $row[28];
	$xferconf_a_dtmf = $row[29];
	$xferconf_a_number = $row[30];
	$xferconf_b_dtmf = $row[31];
	$xferconf_b_number = $row[32];
	$alt_number_dialing = $row[33];
	$scheduled_callbacks = $row[34];
	$lead_filter_id = $row[35];
		if ($lead_filter_id=='') {$lead_filter_id='NONE';}

echo "<br>ΤΡΟΠΟΠΟΙΗΣΗ ΕΓΓΡΑΦΗΣ ΕΚΣΤΡΑΤΕΙΩΝ: $row[0] - <a href=\"$PHP_SELF?ADD=34&campaign_id=$campaign_id\">Βασική Επισκόπηση</a> | Αναλυτική Επισκόπηση<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=41>\n";
echo "<input type=hidden name=campaign_id value=\"$campaign_id\">\n";
echo "<center><TABLE width=600 cellspacing=3>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>ID Εκστρατείας: </td><td align=left><b>$row[0]</b>$NWB#vicidial_campaigns-campaign_id$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ονομα Εκστρατείας: </td><td align=left><input type=text name=campaign_name size=40 maxlength=40 value=\"$row[1]\">$NWB#vicidial_campaigns-campaign_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ενεργός:</td><td align=left><select size=1 name=active><option>Y</option><option>N</option><option SELECTED>$row[2]</option></select>$NWB#vicidial_campaigns-active$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Τηλ.σύνδ. Στάθμευσης: </td><td align=left><input type=text name=park_ext size=10 maxlength=10 value=\"$row[9]\"> - Filename: <input type=text name=park_file_name size=10 maxlength=10 value=\"$row[10]\">$NWB#vicidial_campaigns-park_ext$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ιστο-σελίδα: </td><td align=left><input type=text name=web_form_address size=50 maxlength=255 value=\"$row[11]\">$NWB#vicidial_campaigns-web_form_address$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Επιτρέπω Τους Closers: </td><td align=left><select size=1 name=allow_closers><option>Y</option><option>N</option><option SELECTED>$row[12]</option></select>$NWB#vicidial_campaigns-allow_closers$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Κατάσταση κλήσης1: </td><td align=left><select size=1 name=dial_status_a>\n";

	$stmt="SELECT * from vicidial_statuses order by status";
	$rsltx=mysql_query($stmt, $link);
	$statuses_to_print = mysql_num_rows($rsltx);
	$statuses_list='';

	$o=0;
	while ($statuses_to_print > $o) {
		$rowx=mysql_fetch_row($rsltx);
		$statuses_list .= "<option value=\"$rowx[0]\">$rowx[0] - $rowx[1]</option>\n";
		$statname_list["$rowx[0]"] = "$rowx[1]";
		if (eregi("Y",$rowx[2]))
			{$HKstatuses_list .= "<option value=\"$rowx[0]-----$rowx[1]\">$rowx[0] - $rowx[1]</option>\n";}
		$o++;
	}

	$stmt="SELECT * from vicidial_campaign_statuses where campaign_id='$campaign_id' and selectable='Y' order by status";
	$rsltx=mysql_query($stmt, $link);
	$Cstatuses_to_print = mysql_num_rows($rsltx);

	$o=0;
	while ($Cstatuses_to_print > $o) {
		$rowx=mysql_fetch_row($rsltx);
		$statuses_list .= "<option value=\"$rowx[0]\">$rowx[0] - $rowx[1]</option>\n";
		$statname_list["$rowx[0]"] = "$rowx[1]";
		if (eregi("Y",$rowx[2]))
			{$HKstatuses_list .= "<option value=\"$rowx[0]-----$rowx[1]\">$rowx[0] - $rowx[1]</option>\n";}
		$o++;
	}
echo "$statuses_list";
echo "<option value=\"$dial_status_a\" SELECTED>$dial_status_a - $statname_list[$dial_status_a]</option>\n";
echo "</select>$NWB#vicidial_campaigns-dial_status$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Κατάσταση κλήσης2: </td><td align=left><select size=1 name=dial_status_b>\n";
echo "$statuses_list";
echo "<option value=\"$dial_status_b\" SELECTED>$dial_status_b - $statname_list[$dial_status_b]</option>\n";
echo "</select>$NWB#vicidial_campaigns-dial_status$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Κατάσταση κλήσης3: </td><td align=left><select size=1 name=dial_status_c>\n";
echo "$statuses_list";
echo "<option value=\"$dial_status_c\" SELECTED>$dial_status_c - $statname_list[$dial_status_c]</option>\n";
echo "</select>$NWB#vicidial_campaigns-dial_status$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Κατάσταση κλήσης4: </td><td align=left><select size=1 name=dial_status_d>\n";
echo "$statuses_list";
echo "<option value=\"$dial_status_d\" SELECTED>$dial_status_d - $statname_list[$dial_status_d]</option>\n";
echo "</select>$NWB#vicidial_campaigns-dial_status$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Κατάσταση κλήσης5: </td><td align=left><select size=1 name=dial_status_e>\n";
echo "$statuses_list";
echo "<option value=\"$dial_status_e\" SELECTED>$dial_status_e - $statname_list[$dial_status_e]</option>\n";
echo "</select>$NWB#vicidial_campaigns-dial_status$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Σειρά Λίστας: </td><td align=left><select size=1 name=lead_order><option>DOWN</option><option>UP</option><option>UP PHONE</option><option>DOWN PHONE</option><option>UP LAST NAME</option><option>DOWN LAST NAME</option><option>UP COUNT</option><option>DOWN COUNT</option><option>DOWN COUNT 2nd NEW</option><option>DOWN COUNT 3rd NEW</option><option>DOWN COUNT 4th NEW</option><option SELECTED>$lead_order</option></select>$NWB#vicidial_campaigns-lead_order$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right><a href=\"$PHP_SELF?ADD=31111111&lead_filter_id=$lead_filter_id\">Φίλτρο μολύβδου</a>: </td><td align=left><select size=1 name=lead_filter_id>\n";
echo "$filters_list";
echo "<option selected value=\"$lead_filter_id\">$lead_filter_id - $filtername_list[$lead_filter_id]</option>\n";
echo "</select>$NWB#vicidial_campaigns-lead_filter_id$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>ΕΠΙΠΕΔΟ Hopper: </td><td align=left><select size=1 name=hopper_level><option>1</option><option>5</option><option>10</option><option>50</option><option>100</option><option>200</option><option>500</option><option>1000</option><option SELECTED>$hopper_level</option></select>$NWB#vicidial_campaigns-hopper_level$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Αναγκαστική Επαναφορά του Hopper: </td><td align=left><select size=1 name=reset_hopper><option>Y</option><option SELECTED>N</option></select>$NWB#vicidial_campaigns-force_reset_hopper$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>ΕΠΙΠΕΔΟ ΑΥΤΟΜΑΤΗΣ ΚΛΗΣΗΣ: </td><td align=left><select size=1 name=auto_dial_level><option >0</option><option>1</option><option>1.1</option><option>1.2</option><option>1.3</option><option>1.4</option><option>1.5</option><option>1.6</option><option>1.7</option><option>1.8</option><option>1.9</option><option>2.0</option><option>2.2</option><option>2.5</option><option>2.7</option><option>3.0</option><option>3.5</option><option>4.0</option><option SELECTED>$auto_dial_level</option></select>(0 = off)$NWB#vicidial_campaigns-auto_dial_level$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Επόμενη Κλήση Χρήστη: </td><td align=left><select size=1 name=next_agent_call><option >random</option><option>oldest_call_start</option><option>oldest_call_finish</option><option>overall_user_level</option><option SELECTED>$next_agent_call</option></select>$NWB#vicidial_campaigns-next_agent_call$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Χρόνος Τοπικής Κλήσης: </td><td align=left><select size=1 name=local_call_time><option >24hours</option><option >9am-9pm</option><option>9am-5pm</option><option>12pm-5pm</option><option>12pm-9pm</option><option>5pm-9pm</option><option SELECTED>$local_call_time</option></select>$NWB#vicidial_campaigns-local_call_time$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>ΦΩΝΗΤΙΚΟ ΤΑΧΥΔΡΟΜΕΙΟ: </td><td align=left><input type=text name=voicemail_ext size=10 maxlength=10 value=\"$voicemail_ext\">$NWB#vicidial_campaigns-voicemail_ext$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Κλήση εκτός χρόνου: </td><td align=left><input type=text name=dial_timeout size=3 maxlength=3 value=\"$dial_timeout\"> <i>in seconds</i>$NWB#vicidial_campaigns-dial_timeout$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Πρόθεμα Κλήσης: </td><td align=left><input type=text name=dial_prefix size=20 maxlength=20 value=\"$dial_prefix\"> <font size=1>for 91NXXNXXXXXX value would be 9, for no dial prefix use X</font>$NWB#vicidial_campaigns-dial_prefix$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Εκστρατείας CallerID: </td><td align=left><input type=text name=campaign_cid size=20 maxlength=20 value=\"$campaign_cid\">$NWB#vicidial_campaigns-campaign_cid$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Εκστρατείας VDAD exten: </td><td align=left><input type=text name=campaign_vdad_exten size=10 maxlength=20 value=\"$campaign_vdad_exten\">$NWB#vicidial_campaigns-campaign_vdad_exten$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Εκστρατείας Rec exten: </td><td align=left><input type=text name=campaign_rec_exten size=10 maxlength=10 value=\"$campaign_rec_exten\">$NWB#vicidial_campaigns-campaign_rec_exten$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Εκστρατείας Recording: </td><td align=left><select size=1 name=campaign_recording><option>NEVER</option><option>ONDEMAND</option><option>ALLCALLS</option><option SELECTED>$campaign_recording</option></select>$NWB#vicidial_campaigns-campaign_recording$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Εκστρατείας Rec Filename: </td><td align=left><input type=text name=campaign_rec_filename size=50 maxlength=50 value=\"$campaign_rec_filename\">$NWB#vicidial_campaigns-campaign_rec_filename$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right><a href=\"$PHP_SELF?ADD=3111111&script_id=$script_id\">Script</a>: </td><td align=left><select size=1 name=script_id>\n";
echo "$scripts_list";
echo "<option selected value=\"$script_id\">$script_id - $scriptname_list[$script_id]</option>\n";
echo "</select>$NWB#vicidial_campaigns-campaign_script$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Πάρτε την έναρξη κλήσης: </td><td align=left><select size=1 name=get_call_launch><option selected>NONE</option><option>SCRIPT</option><option>WEBFORM</option><option selected>$get_call_launch</option></select>$NWB#vicidial_campaigns-get_call_launch$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Μήνυμα αυτόματων τηλεφωνητών: </td><td align=left><input type=text name=am_message_exten size=10 maxlength=20 value=\"$am_message_exten\">$NWB#vicidial_campaigns-am_message_exten$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>AMD στέλνει στο VM: </td><td align=left><select size=1 name=amd_send_to_vmx><option>Y</option><option>N</option><option SELECTED>$amd_send_to_vmx</option></select>$NWB#vicidial_campaigns-amd_send_to_vmx$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Μεταφορά- Conf DTMF 1: </td><td align=left><input type=text name=xferconf_a_dtmf size=20 maxlength=50 value=\"$xferconf_a_dtmf\">$NWB#vicidial_campaigns-xferconf_a_dtmf$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Μεταφορά- Conf αριθμός 1: </td><td align=left><input type=text name=xferconf_a_number size=20 maxlength=50 value=\"$xferconf_a_number\">$NWB#vicidial_campaigns-xferconf_a_dtmf$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Μεταφορά- Conf DTMF 2: </td><td align=left><input type=text name=xferconf_b_dtmf size=20 maxlength=50 value=\"$xferconf_b_dtmf\">$NWB#vicidial_campaigns-xferconf_a_dtmf$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Μεταφορά- Conf αριθμός 2: </td><td align=left><input type=text name=xferconf_b_number size=20 maxlength=50 value=\"$xferconf_b_number\">$NWB#vicidial_campaigns-xferconf_a_dtmf$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Σχέδισσες επανακλήσεις: </td><td align=left><select size=1 name=scheduled_callbacks><option>Y</option><option>N</option><option SELECTED>$scheduled_callbacks</option></select>$NWB#vicidial_campaigns-scheduled_callbacks$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Πράκτορας ALT Num που σχηματίζει: </td><td align=left><select size=1 name=alt_number_dialing><option>Y</option><option>N</option><option SELECTED>$alt_number_dialing</option></select>$NWB#vicidial_campaigns-alt_number_dialing$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center></FORM>\n";

	##### calculate what gmt_offset_now values are within the allowed local_call_time setting
	if ($local_call_time == '24hours')
		{
		$p='13';
		$GMT_allowed = '';
		while ($p > -13)
			{
			$tz = sprintf("%.2f", $p);	$GMT_allowed = "$GMT_allowed'$tz',";
			$p = ($p - 0.25);
			}
		}
	if ($local_call_time == '9am-9pm')
		{
		$p='13';
		$GMT_allowed = '';
		while ($p > -13)
			{
			$pzone=3600 * $p;
			$phour=gmdate("G", time() + $pzone);
			if ( ($phour >= 9) && ($phour <= 20) ){$tz = sprintf("%.2f", $p);	$GMT_allowed = "$GMT_allowed'$tz',";}
			$p = ($p - 0.25);
			}
		}
	if ($local_call_time == '9am-5pm')
		{
		$p='13';
		$GMT_allowed = '';
		while ($p > -13)
			{
			$pzone=3600 * $p;
			$phour=gmdate("G", time() + $pzone);
			if ( ($phour >= 9) && ($phour <= 16) ){$tz = sprintf("%.2f", $p);	$GMT_allowed = "$GMT_allowed'$tz',";}
			$p = ($p - 0.25);
			}
		}
	if ($local_call_time == '12pm-5pm')
		{
		$p='13';
		$GMT_allowed = '';
		while ($p > -13)
			{
			$pzone=3600 * $p;
			$phour=gmdate("G", time() + $pzone);
			if ( ($phour >= 12) && ($phour <= 16) ){$tz = sprintf("%.2f", $p);	$GMT_allowed = "$GMT_allowed'$tz',";}
			$p = ($p - 0.25);
			}
		}
	if ($local_call_time == '12pm-9pm')
		{
		$p='13';
		$GMT_allowed = '';
		while ($p > -13)
			{
			$pzone=3600 * $p;
			$phour=gmdate("G", time() + $pzone);
			if ( ($phour >= 12) && ($phour <= 20) ){$tz = sprintf("%.2f", $p);	$GMT_allowed = "$GMT_allowed'$tz',";}
			$p = ($p - 0.25);
			}
		}
	if ($local_call_time == '5pm-9pm')
		{
		$p='13';
		$GMT_allowed = '';
		while ($p > -13)
			{
			$pzone=3600 * $p;
			$phour=gmdate("G", time() + $pzone);
			if ( ($phour >= 17) && ($phour <= 20) ){$tz = sprintf("%.2f", $p);	$GMT_allowed = "$GMT_allowed'$tz',";}
			$p = ($p - 0.25);
			}
		}

	$GMT_allowed = "$GMT_allowed'99'";


echo "<center>\n";
echo "<br><b>ΛΙΣΤΕΣ ΣΤΗΝ ΕΚΣΤΡΑΤΕΙΑ: &nbsp; $NWB#vicidial_campaign_lists$NWE</b><br>\n";
echo "<TABLE width=400 cellspacing=3>\n";
echo "<tr><td>ID ΛΙΣΤΑΣ</td><td>ΟΝΟΜΑ ΛΙΣΤΑΣ</td><td>ΕΝΕΡΓΑ</td></tr>\n";

	$active_lists = 0;
	$inactive_lists = 0;
	$stmt="SELECT list_id,active,list_name from vicidial_lists where campaign_id='$campaign_id'";
	$rsltx=mysql_query($stmt, $link);
	$lists_to_print = mysql_num_rows($rsltx);
	$camp_lists='';

	$o=0;
	while ($lists_to_print > $o) {
		$rowx=mysql_fetch_row($rsltx);
		$o++;
	if (ereg("Y", $rowx[1])) {$active_lists++;   $camp_lists .= "'$rowx[0]',";}
	if (ereg("N", $rowx[1])) {$inactive_lists++;}

	if (eregi("1$|3$|5$|7$|9$", $o))
		{$bgcolor='bgcolor="#B9CBFD"';} 
	else
		{$bgcolor='bgcolor="#9BB9FB"';}

	echo "<tr $bgcolor><td><font size=1><a href=\"$PHP_SELF?ADD=311&list_id=$rowx[0]\">$rowx[0]</a></td><td><font size=1>$rowx[2]</td><td><font size=1>$rowx[1]</td></tr>\n";

	}

echo "</table></center><br>\n";
echo "<center><b>\n";

$filterSQL = $filtersql_list[$lead_filter_id];
$filterSQL = eregi_replace("^and|and$|^or|or$","",$filterSQL);
if (strlen($filterSQL)>4)
	{$fSQL = "and $filterSQL";}
else
	{$fSQL = '';}

	$camp_lists = eregi_replace(".$","",$camp_lists);
echo "Αυτή η εκστρατεία έχει$active_lists ενεργές λίστες και$inactive_lists Μη ενεργές λίστες<br><br>\n";
	$stmt="SELECT count(*) FROM vicidial_list where called_since_last_reset='N' and status IN('$dial_status_a','$dial_status_b','$dial_status_c','$dial_status_d','$dial_status_e') and list_id IN($camp_lists) and gmt_offset_now IN($GMT_allowed) $fSQL";
	if ($DB) {echo "$stmt\n";}
	$rsltx=mysql_query($stmt, $link);
	$rsltx_rows = mysql_num_rows($rsltx);
	if ($rsltx_rows)
		{
		$rowx=mysql_fetch_row($rsltx);
		$active_leads = "$rowx[0]";
		}
	else {$active_leads = '0';}

echo "Αυτή η εκστρατεία έχει$active_leads καθοδηγητές που καλούντε στις λίστες<br><br>\n";
	$stmt="SELECT count(*) FROM vicidial_hopper where campaign_id='$campaign_id' and status IN('READY')";
	if ($DB) {echo "$stmt\n";}
	$rsltx=mysql_query($stmt, $link);
	$rowx=mysql_fetch_row($rsltx);
	$hopper_leads = "$rowx[0]";

echo "Αυτή η εκστρατεία έχει$hopper_leads >καθοδηγητές στον hopper κλήσεων<<br><br>\n";
echo "<a href=\"./AST_VICIDIAL_hopperlist.php?group=$campaign_id\">Πατήστε εδώ για να δείτε ποιοι καθοδηγητές είναι στον hopper τώρα</a><br><br>\n";
echo "<a href=\"$PHP_SELF?ADD=81&campaign_id=$campaign_id\">Χτυπήστε εδώ για να δείτε όλη την πλάτη κλήσης κρατά σε αυτήν την εκστρατεία</a><BR><BR>\n";
echo "</b></center>\n";




echo "<center>\n";
echo "<br><b>ΠΡΟΣΑΡΜΟΣΜΕΝΕΣ ΚΑΤΑΣΤΑΣΕΙΣ ΣΤΗΝ ΕΚΣΤΡΑΤΕΙΑ: &nbsp; $NWB#vicidial_campaign_statuses$NWE</b><br>\n";
echo "<TABLE width=400 cellspacing=3>\n";
echo "<tr><td>ΚΑΤΑΣΤΑΣΗ</td><td>ΠΕΡΙΓΡΑΦΗ</td><td>ΕΠΙΛΕΞΙΜΟ</td><td>ΔΙΑΓΡΑΦΗ</td></tr>\n";

	$stmt="SELECT * from vicidial_campaign_statuses where campaign_id='$campaign_id'";
	$rsltx=mysql_query($stmt, $link);
	$statuses_to_print = mysql_num_rows($rsltx);
	$o=0;
	while ($statuses_to_print > $o) {
		$rowx=mysql_fetch_row($rsltx);
		$o++;

	if (eregi("1$|3$|5$|7$|9$", $o))
		{$bgcolor='bgcolor="#B9CBFD"';} 
	else
		{$bgcolor='bgcolor="#9BB9FB"';}

	echo "<tr $bgcolor><td><font size=1>$rowx[0]</td><td><font size=1>$rowx[1]</td><td><font size=1>$rowx[2]</td><td><font size=1><a href=\"$PHP_SELF?ADD=42&campaign_id=$campaign_id&status=$rowx[0]&action=DELETE\">ΔΙΑΓΡΑΦΗ</a></td></tr>\n";

	}

echo "</table>\n";

echo "<br>ΠΡΟΣΘΗΚΗ ΝΕΑΣ ΠΡΟΣΑΡΜΟΣΜΕΝΗΣ ΚΑΤΑΣΤΑΣΗΣ ΣΤΗΝ ΕΚΣΤΡΑΤΕΙΑ<BR><form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=22>\n";
echo "<input type=hidden name=campaign_id value=\"$campaign_id\">\n";
echo "Κατάσταση:<input type=text name=status size=10 maxlength=8> &nbsp; \n";
echo "Περιγραφή:<input type=text name=status_name size=20 maxlength=30> &nbsp; \n";
echo "Επιλέξιμο:<select size=1 name=selectable><option>Y</option><option>N</option></select> &nbsp; \n";
echo "<input type=submit name=submit value=ΠΡΟΣΘΗΚΗ><BR>\n";

echo "</FORM><br>\n";



echo "<br><b>ΠΡΟΣΑΡΜΟΣΜΕΝΑ ΚΛΕΙΔΙΑ ΣΤΗΝ ΕΚΣΤΡΑΤΕΙΑ: &nbsp; $NWB#vicidial_campaign_hotkeys$NWE</b><br>\n";
echo "<TABLE width=400 cellspacing=3>\n";
echo "<tr><td>ΚΛΕΙΔΙ</td><td>ΚΑΤΑΣΤΑΣΗ</td><td>ΠΕΡΙΓΡΑΦΗ</td><td>ΔΙΑΓΡΑΦΗ</td></tr>\n";

	$stmt="SELECT * from vicidial_campaign_hotkeys where campaign_id='$campaign_id' order by hotkey";
	$rsltx=mysql_query($stmt, $link);
	$statuses_to_print = mysql_num_rows($rsltx);
	$o=0;
	while ($statuses_to_print > $o) {
		$rowx=mysql_fetch_row($rsltx);
		$o++;

	if (eregi("1$|3$|5$|7$|9$", $o))
		{$bgcolor='bgcolor="#B9CBFD"';} 
	else
		{$bgcolor='bgcolor="#9BB9FB"';}

	echo "<tr $bgcolor><td><font size=1>$rowx[1]</td><td><font size=1>$rowx[0]</td><td><font size=1>$rowx[2]</td><td><font size=1><a href=\"$PHP_SELF?ADD=43&campaign_id=$campaign_id&status=$rowx[0]&hotkey=$rowx[1]&action=DELETE\">ΔΙΑΓΡΑΦΗ</a></td></tr>\n";

	}

echo "</table>\n";

echo "<br>ΠΡΟΣΘΗΚΗ ΝΕΟΥ ΠΡΟΣΑΡΜΟΣΜΕΝΟΥ ΚΛΕΙΔΙΟΥ ΕΚΣΤΡΑΤΕΙΑΣ<BR><form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=23>\n";
echo "<input type=hidden name=selectable value=Y>\n";
echo "<input type=hidden name=campaign_id value=\"$campaign_id\">\n";
echo "Κλειδί:<select size=1 name=hotkey>\n";
echo "<option>1</option>\n";
echo "<option>2</option>\n";
echo "<option>3</option>\n";
echo "<option>4</option>\n";
echo "<option>5</option>\n";
echo "<option>6</option>\n";
echo "<option>7</option>\n";
echo "<option>8</option>\n";
echo "<option>9</option>\n";
echo "</select> &nbsp; \n";
echo "Κατάσταση:<select size=1 name=HKstatus>\n";
echo "$HKstatuses_list\n";
echo "</select> &nbsp; \n";
echo "<input type=submit name=submit value=ΠΡΟΣΘΗΚΗ><BR>\n";

echo "</center></FORM><br>\n";

echo "<a href=\"$PHP_SELF?ADD=52&campaign_id=$campaign_id\">ΚΑΤΑΓΡΑΨΤΕ ΟΛΟΥΣ ΤΟΥΣ ΠΡΑΚΤΟΡΕΣ ΑΠΟ ΑΥΤΗΝ ΤΗΝ ΕΚΣΤΡΑΤΕΙΑ</a><BR><BR>\n";

if ($LOGdelete_campaigns > 0)
	{
	echo "<br><br><a href=\"$PHP_SELF?ADD=51&campaign_id=$campaign_id\">ΔΙΑΓΡΑΨΤΕ ΑΥΤΗΝ ΤΗΝ ΕΚΣΤΡΑΤΕΙΑ</a>\n";
	}

}


######################
# ADD=34 modify campaign info in the system - Basic View
######################

if ($ADD==34)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_campaigns where campaign_id='$campaign_id';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$dial_status_a = $row[3];
	$dial_status_b = $row[4];
	$dial_status_c = $row[5];
	$dial_status_d = $row[6];
	$dial_status_e = $row[7];
	$lead_order = $row[8];
	$hopper_level = $row[13];
	$auto_dial_level = $row[14];
	$next_agent_call = $row[15];
	$local_call_time = $row[16];
	$voicemail_ext = $row[17];
	$dial_timeout = $row[18];
	$dial_prefix = $row[19];
	$campaign_cid = $row[20];
	$campaign_vdad_exten = $row[21];
	$script_id = $row[25];
	$get_call_launch = $row[26];
	$lead_filter_id = $row[35];
		if ($lead_filter_id=='') {$lead_filter_id='NONE';}

echo "<br>MODIFY A CAMPAIGN'S RECORD: $row[0] - Βασική Επισκόπηση | <a href=\"$PHP_SELF?ADD=31&campaign_id=$campaign_id\">Αναλυτική Επισκόπηση</a><form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=44>\n";
echo "<input type=hidden name=campaign_id value=\"$campaign_id\">\n";
echo "<center><TABLE width=600 cellspacing=3>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>ID Εκστρατείας: </td><td align=left><b>$row[0]</b>$NWB#vicidial_campaigns-campaign_id$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ονομα Εκστρατείας: </td><td align=left><input type=text name=campaign_name size=40 maxlength=40 value=\"$row[1]\">$NWB#vicidial_campaigns-campaign_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ενεργός:</td><td align=left><select size=1 name=active><option>Y</option><option>N</option><option SELECTED>$row[2]</option></select>$NWB#vicidial_campaigns-active$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Τηλ.σύνδ. Στάθμευσης: </td><td align=left>$row[9] - $row[10]$NWB#vicidial_campaigns-park_ext$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ιστο-σελίδα: </td><td align=left>$row[11]$NWB#vicidial_campaigns-web_form_address$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Επιτρέπω Τους Closers: </td><td align=left>$row[12] $NWB#vicidial_campaigns-allow_closers$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Κατάσταση κλήσης1: </td><td align=left><select size=1 name=dial_status_a>\n";

	$stmt="SELECT * from vicidial_statuses order by status";
	$rsltx=mysql_query($stmt, $link);
	$statuses_to_print = mysql_num_rows($rsltx);
	$statuses_list='';

	$o=0;
	while ($statuses_to_print > $o) {
		$rowx=mysql_fetch_row($rsltx);
		$statuses_list .= "<option value=\"$rowx[0]\">$rowx[0] - $rowx[1]</option>\n";
		$statname_list["$rowx[0]"] = "$rowx[1]";
		$o++;
	}

	$stmt="SELECT * from vicidial_campaign_statuses where campaign_id='$campaign_id' order by status";
	$rsltx=mysql_query($stmt, $link);
	$Cstatuses_to_print = mysql_num_rows($rsltx);

	$o=0;
	while ($Cstatuses_to_print > $o) {
		$rowx=mysql_fetch_row($rsltx);
		$statuses_list .= "<option value=\"$rowx[0]\">$rowx[0] - $rowx[1]</option>\n";
		$statname_list["$rowx[0]"] = "$rowx[1]";
		$o++;
	}
echo "$statuses_list";
echo "<option value=\"$dial_status_a\" SELECTED>$dial_status_a - $statname_list[$dial_status_a]</option>\n";
echo "</select>$NWB#vicidial_campaigns-dial_status$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Κατάσταση κλήσης2: </td><td align=left><select size=1 name=dial_status_b>\n";
echo "$statuses_list";
echo "<option value=\"$dial_status_b\" SELECTED>$dial_status_b - $statname_list[$dial_status_b]</option>\n";
echo "</select>$NWB#vicidial_campaigns-dial_status$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Κατάσταση κλήσης3: </td><td align=left><select size=1 name=dial_status_c>\n";
echo "$statuses_list";
echo "<option value=\"$dial_status_c\" SELECTED>$dial_status_c - $statname_list[$dial_status_c]</option>\n";
echo "</select>$NWB#vicidial_campaigns-dial_status$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Κατάσταση κλήσης4: </td><td align=left><select size=1 name=dial_status_d>\n";
echo "$statuses_list";
echo "<option value=\"$dial_status_d\" SELECTED>$dial_status_d - $statname_list[$dial_status_d]</option>\n";
echo "</select>$NWB#vicidial_campaigns-dial_status$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Κατάσταση κλήσης5: </td><td align=left><select size=1 name=dial_status_e>\n";
echo "$statuses_list";
echo "<option value=\"$dial_status_e\" SELECTED>$dial_status_e - $statname_list[$dial_status_e]</option>\n";
echo "</select>$NWB#vicidial_campaigns-dial_status$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Σειρά Λίστας: </td><td align=left><select size=1 name=lead_order><option>DOWN</option><option>UP</option><option>UP PHONE</option><option>DOWN PHONE</option><option>UP LAST NAME</option><option>DOWN LAST NAME</option><option>UP COUNT</option><option>DOWN COUNT</option><option>DOWN COUNT 2nd NEW</option><option>DOWN COUNT 3rd NEW</option><option>DOWN COUNT 4th NEW</option><option SELECTED>$lead_order</option></select>$NWB#vicidial_campaigns-lead_order$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right><a href=\"$PHP_SELF?ADD=31111111&lead_filter_id=$lead_filter_id\">Φίλτρο μολύβδου</a>: </td><td align=left><select size=1 name=lead_filter_id>\n";
echo "$filters_list";
echo "<option selected value=\"$lead_filter_id\">$lead_filter_id - $filtername_list[$lead_filter_id]</option>\n";
echo "</select>$NWB#vicidial_campaigns-lead_filter_id$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>ΕΠΙΠΕΔΟ Hopper: </td><td align=left><select size=1 name=hopper_level><option>1</option><option>5</option><option>10</option><option>50</option><option>100</option><option>200</option><option>500</option><option>1000</option><option SELECTED>$hopper_level</option></select>$NWB#vicidial_campaigns-hopper_level$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Αναγκαστική Επαναφορά του Hopper: </td><td align=left><select size=1 name=reset_hopper><option>Y</option><option SELECTED>N</option></select>$NWB#vicidial_campaigns-force_reset_hopper$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>ΕΠΙΠΕΔΟ ΑΥΤΟΜΑΤΗΣ ΚΛΗΣΗΣ: </td><td align=left><select size=1 name=auto_dial_level><option >0</option><option>1</option><option>1.1</option><option>1.2</option><option>1.3</option><option>1.4</option><option>1.5</option><option>1.6</option><option>1.7</option><option>1.8</option><option>1.9</option><option>2.0</option><option>2.2</option><option>2.5</option><option>2.7</option><option>3.0</option><option>3.5</option><option>4.0</option><option SELECTED>$auto_dial_level</option></select>(0 = off)$NWB#vicidial_campaigns-auto_dial_level$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right><a href=\"$PHP_SELF?ADD=3111111&script_id=$script_id\">Script</a>: </td><td align=left>$script_id</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Πάρτε την έναρξη κλήσης: </td><td align=left>$get_call_launch</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center></FORM>\n";

	##### calculate what gmt_offset_now values are within the allowed local_call_time setting
	if ($local_call_time == '24hours')
		{
		$p='13';
		$GMT_allowed = '';
		while ($p > -13)
			{
			$tz = sprintf("%.2f", $p);	$GMT_allowed = "$GMT_allowed'$tz',";
			$p = ($p - 0.25);
			}
		}
	if ($local_call_time == '9am-9pm')
		{
		$p='13';
		$GMT_allowed = '';
		while ($p > -13)
			{
			$pzone=3600 * $p;
			$phour=gmdate("G", time() + $pzone);
			if ( ($phour >= 9) && ($phour <= 20) ){$tz = sprintf("%.2f", $p);	$GMT_allowed = "$GMT_allowed'$tz',";}
			$p = ($p - 0.25);
			}
		}
	if ($local_call_time == '9am-5pm')
		{
		$p='13';
		$GMT_allowed = '';
		while ($p > -13)
			{
			$pzone=3600 * $p;
			$phour=gmdate("G", time() + $pzone);
			if ( ($phour >= 9) && ($phour <= 16) ){$tz = sprintf("%.2f", $p);	$GMT_allowed = "$GMT_allowed'$tz',";}
			$p = ($p - 0.25);
			}
		}
	if ($local_call_time == '12pm-5pm')
		{
		$p='13';
		$GMT_allowed = '';
		while ($p > -13)
			{
			$pzone=3600 * $p;
			$phour=gmdate("G", time() + $pzone);
			if ( ($phour >= 12) && ($phour <= 16) ){$tz = sprintf("%.2f", $p);	$GMT_allowed = "$GMT_allowed'$tz',";}
			$p = ($p - 0.25);
			}
		}
	if ($local_call_time == '12pm-9pm')
		{
		$p='13';
		$GMT_allowed = '';
		while ($p > -13)
			{
			$pzone=3600 * $p;
			$phour=gmdate("G", time() + $pzone);
			if ( ($phour >= 12) && ($phour <= 20) ){$tz = sprintf("%.2f", $p);	$GMT_allowed = "$GMT_allowed'$tz',";}
			$p = ($p - 0.25);
			}
		}
	if ($local_call_time == '5pm-9pm')
		{
		$p='13';
		$GMT_allowed = '';
		while ($p > -13)
			{
			$pzone=3600 * $p;
			$phour=gmdate("G", time() + $pzone);
			if ( ($phour >= 17) && ($phour <= 20) ){$tz = sprintf("%.2f", $p);	$GMT_allowed = "$GMT_allowed'$tz',";}
			$p = ($p - 0.25);
			}
		}

	$GMT_allowed = "$GMT_allowed'99'";



echo "<center>\n";
echo "<br><b>ΛΙΣΤΕΣ ΣΤΗΝ ΕΚΣΤΡΑΤΕΙΑ: &nbsp; $NWB#vicidial_campaign_lists$NWE</b><br>\n";
echo "<TABLE width=400 cellspacing=3>\n";
echo "<tr><td>ID ΛΙΣΤΑΣ</td><td>ΟΝΟΜΑ ΛΙΣΤΑΣ</td><td>ΕΝΕΡΓΑ</td></tr>\n";

	$active_lists = 0;
	$inactive_lists = 0;
	$stmt="SELECT list_id,active,list_name from vicidial_lists where campaign_id='$campaign_id'";
	$rsltx=mysql_query($stmt, $link);
	$lists_to_print = mysql_num_rows($rsltx);
	$camp_lists='';

	$o=0;
	while ($lists_to_print > $o) {
		$rowx=mysql_fetch_row($rsltx);
		$o++;
	if (ereg("Y", $rowx[1])) {$active_lists++;   $camp_lists .= "'$rowx[0]',";}
	if (ereg("N", $rowx[1])) {$inactive_lists++;}

	if (eregi("1$|3$|5$|7$|9$", $o))
		{$bgcolor='bgcolor="#B9CBFD"';} 
	else
		{$bgcolor='bgcolor="#9BB9FB"';}

	echo "<tr $bgcolor><td><font size=1><a href=\"$PHP_SELF?ADD=311&list_id=$rowx[0]\">$rowx[0]</a></td><td><font size=1>$rowx[2]</td><td><font size=1>$rowx[1]</td></tr>\n";

	}

echo "</table></center><br>\n";
echo "<center><b>\n";

$filterSQL = $filtersql_list[$lead_filter_id];
$filterSQL = eregi_replace("^and|and$|^or|or$","",$filterSQL);
if (strlen($filterSQL)>4)
	{$fSQL = "and $filterSQL";}
else
	{$fSQL = '';}

	$camp_lists = eregi_replace(".$","",$camp_lists);
echo "Αυτή η εκστρατεία έχει$active_lists ενεργές λίστες και$inactive_lists Μη ενεργές λίστες<br><br>\n";
	$stmt="SELECT count(*) FROM vicidial_list where called_since_last_reset='N' and status IN('$dial_status_a','$dial_status_b','$dial_status_c','$dial_status_d','$dial_status_e') and list_id IN($camp_lists) and gmt_offset_now IN($GMT_allowed) $fSQL";
	if ($DB) {echo "$stmt\n";}
	$rsltx=mysql_query($stmt, $link);
	$rsltx_rows = mysql_num_rows($rsltx);
	if ($rsltx_rows)
		{
		$rowx=mysql_fetch_row($rsltx);
		$active_leads = "$rowx[0]";
		}
	else {$active_leads = '0';}

echo "Αυτή η εκστρατεία έχει$active_leads καθοδηγητές που καλούντε στις λίστες<br><br>\n";
	$stmt="SELECT count(*) FROM vicidial_hopper where campaign_id='$campaign_id' and status IN('READY')";
	if ($DB) {echo "$stmt\n";}
	$rsltx=mysql_query($stmt, $link);
	$rowx=mysql_fetch_row($rsltx);
	$hopper_leads = "$rowx[0]";

echo "Αυτή η εκστρατεία έχει$hopper_leads >καθοδηγητές στον hopper κλήσεων<<br><br>\n";
echo "<a href=\"./AST_VICIDIAL_hopperlist.php?group=$campaign_id\">Πατήστε εδώ για να δείτε ποιοι καθοδηγητές είναι στον hopper τώρα</a><br><br>\n";
echo "<a href=\"$PHP_SELF?ADD=81&campaign_id=$campaign_id\">Χτυπήστε εδώ για να δείτε όλη την πλάτη κλήσης κρατά σε αυτήν την εκστρατεία</a><BR><BR>\n";
echo "</b></center>\n";

echo "<br>\n";

echo "<a href=\"$PHP_SELF?ADD=52&campaign_id=$campaign_id\">ΚΑΤΑΓΡΑΨΤΕ ΟΛΟΥΣ ΤΟΥΣ ΠΡΑΚΤΟΡΕΣ ΑΠΟ ΑΥΤΗΝ ΤΗΝ ΕΚΣΤΡΑΤΕΙΑ</a><BR><BR>\n";


if ($LOGdelete_campaigns > 0)
	{
	echo "<br><br><a href=\"$PHP_SELF?ADD=51&campaign_id=$campaign_id\">ΔΙΑΓΡΑΨΤΕ ΑΥΤΗΝ ΤΗΝ ΕΚΣΤΡΑΤΕΙΑ</a>\n";
	}


}


######################
# ADD=311 modify list info in the system
######################

if ($ADD==311)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_lists where list_id='$list_id';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$campaign_id = $row[2];
	$active = $row[3];

	# grab names of global statuses and statuses in the selected campaign
	$stmt="SELECT * from vicidial_statuses order by status";
	$rsltx=mysql_query($stmt, $link);
	$statuses_to_print = mysql_num_rows($rsltx);

	$o=0;
	while ($statuses_to_print > $o) {
		$rowx=mysql_fetch_row($rsltx);
		$statuses_list["$rowx[0]"] = "$rowx[1]";
		$o++;
	}

	$stmt="SELECT * from vicidial_campaign_statuses where campaign_id='$campaign_id' order by status";
	$rsltx=mysql_query($stmt, $link);
	$Cstatuses_to_print = mysql_num_rows($rsltx);

	$o=0;
	while ($Cstatuses_to_print > $o) {
		$rowx=mysql_fetch_row($rsltx);
		$statuses_list["$rowx[0]"] = "$rowx[1]";
		$o++;
	}
	# end grab status names


echo "<br>ΤΡΟΠΟΠΟΙΗΣΗ ΕΓΓΡΑΦΗΣ ΛΙΣΤΑΣ: $row[0]<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=411>\n";
echo "<input type=hidden name=list_id value=\"$row[0]\">\n";
echo "<input type=hidden name=old_campaign_id value=\"$row[2]\">\n";
echo "<center><TABLE width=600 cellspacing=3>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>ID Λίστας: </td><td align=left><b>$row[0]</b>$NWB#vicidial_lists-list_id$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ονομα Λίστας: </td><td align=left><input type=text name=list_name size=20 maxlength=20 value=\"$row[1]\">$NWB#vicidial_lists-list_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right><a href=\"$PHP_SELF?ADD=34&campaign_id=$campaign_id\">Εκστρατείας</a>: </td><td align=left><select size=1 name=campaign_id>\n";

	$stmt="SELECT campaign_id,campaign_name from vicidial_campaigns order by campaign_id";
	$rsltx=mysql_query($stmt, $link);
	$campaigns_to_print = mysql_num_rows($rsltx);
	$campaigns_list='';

	$o=0;
	while ($campaigns_to_print > $o) {
		$rowx=mysql_fetch_row($rsltx);
		$campaigns_list .= "<option value=\"$rowx[0]\">$rowx[0] - $rowx[1]</option>\n";
		$o++;
	}
echo "$campaigns_list";
echo "<option SELECTED>$campaign_id</option>\n";
echo "</select>$NWB#vicidial_lists-campaign_id$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ενεργός:</td><td align=left><select size=1 name=active><option>Y</option><option>N</option><option SELECTED>$active</option></select>$NWB#vicidial_lists-active$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>ΕΠΑΝΑΦΟΡΑ ΚΑΤΑΣΤΑΣΗΣ ΚΛΗΣΗΣ ΚΑΘΟΔΗΓΗΣΗΣ ΓΙΑ ΤΗΝ ΛΙΣΤΑ: </td><td align=left><select size=1 name=reset_list><option>Y</option><option SELECTED>N</option></select>$NWB#vicidial_lists-reset_list$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center>\n";

echo "<center>\n";
echo "<br><b>ΚΑΤΑΣΤΑΣΕΙΣ ΣΤΗΝ ΛΙΣΤΑ:</b><br>\n";
echo "<TABLE width=500 cellspacing=3>\n";
echo "<tr><td>ΚΑΤΑΣΤΑΣΗ</td><td>ΟΝΟΜΑ ΘΕΣΗΣ</td><td>ΚΛΗΘΕΝΤΑ</td><td>ΜΗ ΚΛΗΘΕΝΤΑ</td></tr>\n";

	$leads_in_list = 0;
	$leads_in_list_N = 0;
	$leads_in_list_Y = 0;
	$stmt="SELECT status,called_since_last_reset,count(*) from vicidial_list where list_id='$list_id' group by status,called_since_last_reset order by status,called_since_last_reset";
	$rsltx=mysql_query($stmt, $link);
	$statuses_to_print = mysql_num_rows($rsltx);

	$o=0;
	$lead_list['count'] = 0;
	$lead_list['Y_count'] = 0;
	$lead_list['N_count'] = 0;
	while ($statuses_to_print > $o) 
	{
	    $rowx=mysql_fetch_row($rsltx);
	    
	    $lead_list['count'] = ($lead_list['count'] + $rowx[2]);
	    if ($rowx[1] == 'N') 
	    {
		$since_reset = 'N';
		$since_resetX = 'Y';
	    }
	    else 
	    {
		$since_reset = 'Y';
		$since_resetX = 'N';
	    } 
	    $lead_list[$since_reset][$rowx[0]] = $rowx[2];
	    $lead_list[$since_reset.'_count'] = ($lead_list[$since_reset.'_count'] + $rowx[2]);
	    #If opposite side is not set, it may not in the future so give it a value of zero
	    if (!isset($lead_list[$since_resetX][$rowx[0]])) 
	    {
		$lead_list[$since_resetX][$rowx[0]]=0;
	    }
	    $o++;
	}
 
	$o=0;
	while (list($dispo,) = each($lead_list[$since_reset]))
	{

	if (eregi("1$|3$|5$|7$|9$", $o))
		{$bgcolor='bgcolor="#B9CBFD"';} 
	else
		{$bgcolor='bgcolor="#9BB9FB"';}

	if ($dispo == 'CBHOLD')
		{
		$CLB="<a href=\"$PHP_SELF?ADD=811&list_id=$list_id\">";
		$CLE="</a>";
		}
	else
		{
		$CLB='';
		$CLE='';
		}

	echo "<tr $bgcolor><td><font size=1>$CLB$dispo$CLE</td><td><font size=1>$statuses_list[$dispo]</td><td><font size=1>".$lead_list['Y'][$dispo]."</td><td><font size=1>".$lead_list['N'][$dispo]." </td></tr>\n";
	$o++;
	}

echo "<tr><td colspan=2><font size=1>ΥΠΟΣΥΝΟΛΑ</td><td><font size=1>$lead_list[Y_count]</td><td><font size=1>$lead_list[N_count]</td></tr>\n";
echo "<tr bgcolor=\"#9BB9FB\"><td><font size=1>ΣΥΝΟΛΙΚΑ</td><td colspan=3 align=center><font size=1>$lead_list[count]</td></tr>\n";

echo "</table></center><br>\n";
unset($lead_list);





echo "<center>\n";
echo "<br><b>ΖΩΝΕΣ ΩΡΑΣ ΣΤΗΝ ΛΙΣΤΑ:</b><br>\n";
echo "<TABLE width=500 cellspacing=3>\n";
echo "<tr><td>GMT OFFSET (τοπικός χρόνος)</td><td>ΚΛΗΘΕΝΤΑ</td><td>ΜΗ ΚΛΗΘΕΝΤΑ</td></tr>\n";

	$stmt="SELECT gmt_offset_now,called_since_last_reset,count(*) from vicidial_list where list_id='$list_id' group by gmt_offset_now,called_since_last_reset order by gmt_offset_now,called_since_last_reset";
	$rsltx=mysql_query($stmt, $link);
	$statuses_to_print = mysql_num_rows($rsltx);

	$o=0;
	$plus='+';
	$lead_list['count'] = 0;
	$lead_list['Y_count'] = 0;
	$lead_list['N_count'] = 0;
	while ($statuses_to_print > $o) 
	{
	    $rowx=mysql_fetch_row($rsltx);
	    
	    $lead_list['count'] = ($lead_list['count'] + $rowx[2]);
	    if ($rowx[1] == 'N') 
	    {
		$since_reset = 'N';
		$since_resetX = 'Y';
	    }
	    else 
	    {
		$since_reset = 'Y';
		$since_resetX = 'N';
	    } 
	    $lead_list[$since_reset][$rowx[0]] = $rowx[2];
	    $lead_list[$since_reset.'_count'] = ($lead_list[$since_reset.'_count'] + $rowx[2]);
	    #If opposite side is not set, it may not in the future so give it a value of zero
	    if (!isset($lead_list[$since_resetX][$rowx[0]])) 
	    {
		$lead_list[$since_resetX][$rowx[0]]=0;
	    }
	    $o++;
	}

	while (list($tzone,) = each($lead_list[$since_reset]))
	{
	$LOCALzone=3600 * $tzone;
	$LOCALdate=gmdate("D M Y H:i", time() + $LOCALzone);

	if ($tzone >= 0) {$tzone = "$plus$tzone";}
	if (eregi("1$|3$|5$|7$|9$", $o))
		{$bgcolor='bgcolor="#B9CBFD"';} 
	else
		{$bgcolor='bgcolor="#9BB9FB"';}

		echo "<tr $bgcolor><td><font size=1>".$tzone." &nbsp; &nbsp; ($LOCALdate)</td><td><font size=1>".$lead_list['Y'][$tzone]."</td><td><font size=1>".$lead_list['N'][$tzone]."</td></tr>\n";
	}

echo "<tr><td><font size=1>ΥΠΟΣΥΝΟΛΑ</td><td><font size=1>$lead_list[Y_count]</td><td><font size=1>$lead_list[N_count]</td></tr>\n";
echo "<tr bgcolor=\"#9BB9FB\"><td><font size=1>ΣΥΝΟΛΙΚΑ</td><td colspan=2 align=center><font size=1>$lead_list[count]</td></tr>\n";

echo "</table></center><br>\n";
unset($lead_list);







	$leads_in_list = 0;
	$leads_in_list_N = 0;
	$leads_in_list_Y = 0;
	$stmt="SELECT status,called_count,count(*) from vicidial_list where list_id='$list_id' group by status,called_count order by status,called_count";
	$rsltx=mysql_query($stmt, $link);
	$status_called_to_print = mysql_num_rows($rsltx);

	$o=0;
	$sts=0;
	$first_row=1;
	$all_called_first=1000;
	$all_called_last=0;
	while ($status_called_to_print > $o) 
	{
	$rowx=mysql_fetch_row($rsltx);
	$leads_in_list = ($leads_in_list + $rowx[2]);
	$count_statuses[$o]			= "$rowx[0]";
	$count_called[$o]			= "$rowx[1]";
	$count_count[$o]			= "$rowx[2]";
	$all_called_count[$rowx[1]] = ($all_called_count[$rowx[1]] + $rowx[2]);

	if ( (strlen($status[$sts]) < 1) or ($status[$sts] != "$rowx[0]") )
		{
		if ($first_row) {$first_row=0;}
		else {$sts++;}
		$status[$sts] = "$rowx[0]";
		$status_called_first[$sts] = "$rowx[1]";
		if ($status_called_first[$sts] < $all_called_first) {$all_called_first = $status_called_first[$sts];}
		}
	$leads_in_sts[$sts] = ($leads_in_sts[$sts] + $rowx[2]);
	$status_called_last[$sts] = "$rowx[1]";
	if ($status_called_last[$sts] > $all_called_last) {$all_called_last = $status_called_last[$sts];}

	$o++;
	}




echo "<center>\n";
echo "<br><b>ΜΕΤΡΗΣΗ ΚΛΗΣΕΩΝ ΣΤΗΝ ΛΙΣΤΑ:</b><br>\n";
echo "<TABLE width=500 cellspacing=1>\n";
echo "<tr><td align=left><font size=1>ΚΑΤΑΣΤΑΣΗ</td><td align=center><font size=1>ΟΝΟΜΑ ΘΕΣΗΣ</td>";
$first = $all_called_first;
while ($first <= $all_called_last)
	{
	if (eregi("1$|3$|5$|7$|9$", $first)) {$AB='bgcolor="#AFEEEE"';} 
	else{$AB='bgcolor="#E0FFFF"';}
	echo "<td align=center $AB><font size=1>$first</td>";
	$first++;
	}
echo "<td align=center><font size=1>ΥΠΟΣΥΝΟΛΟ</td></tr>\n";

	$sts=0;
	$statuses_called_to_print = count($status);
	while ($statuses_called_to_print > $sts) 
	{
	$Pstatus = $status[$sts];
	if (eregi("1$|3$|5$|7$|9$", $sts))
		{$bgcolor='bgcolor="#B9CBFD"';   $AB='bgcolor="#9BB9FB"';} 
	else
		{$bgcolor='bgcolor="#9BB9FB"';   $AB='bgcolor="#B9CBFD"';}
#	echo "$status[$sts]|$status_called_first[$sts]|$status_called_last[$sts]|$leads_in_sts[$sts]|\n";
#	echo "$status[$sts]|";
	echo "<tr $bgcolor><td><font size=1>$Pstatus</td><td><font size=1>$statuses_list[$Pstatus]</td>";

	$first = $all_called_first;
	while ($first <= $all_called_last)
		{
		if (eregi("1$|3$|5$|7$|9$", $sts))
			{
			if (eregi("1$|3$|5$|7$|9$", $first)) {$AB='bgcolor="#9BB9FB"';} 
			else{$AB='bgcolor="#B9CBFD"';}
			}
		else
			{
			if (eregi("0$|2$|4$|6$|8$", $first)) {$AB='bgcolor="#9BB9FB"';} 
			else{$AB='bgcolor="#B9CBFD"';}
			}

		$called_printed=0;
		$o=0;
		while ($status_called_to_print > $o) 
			{
			if ( ($count_statuses[$o] == "$Pstatus") and ($count_called[$o] == "$first") )
				{
				$called_printed++;
				echo "<td $AB><font size=1> $count_count[$o]</td>";
				}


			$o++;
			}
		if (!$called_printed) 
			{echo "<td $AB><font size=1> &nbsp;</td>";}
		$first++;
		}
	echo "<td><font size=1>$leads_in_sts[$sts]</td></tr>\n\n";

	$sts++;
	}

echo "<tr><td align=center colspan=2><b><font size=1>ΣΥΝΟΛΙΚΑ</td>";
$first = $all_called_first;
while ($first <= $all_called_last)
	{
	if (eregi("1$|3$|5$|7$|9$", $first)) {$AB='bgcolor="#AFEEEE"';} 
	else{$AB='bgcolor="#E0FFFF"';}
	echo "<td align=center $AB><b><font size=1>$all_called_count[$first]</td>";
	$first++;
	}
echo "<td align=center><b><font size=1>$leads_in_list</td></tr>\n";

echo "</table></center><br>\n";





echo "<center><b>\n";

if ($LOGdelete_lists > 0)
	{
	echo "<br><br><a href=\"$PHP_SELF?ADD=511&list_id=$list_id\">ΔΙΑΓΡΑΨΤΕ ΑΥΤΟΝ ΤΟΝ ΚΑΤΑΛΟΓΟ</a>\n";
	}

}



######################
# ADD=3111 modify in-group info in the system
######################

if ($ADD==3111)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_inbound_groups where group_id='$group_id';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$group_name = $row[1];
	$group_color = $row[2];
	$active = $row[3];
	$web_form_address = $row[4];
	$voicemail_ext = $row[5];
	$next_agent_call = $row[6];
	$fronter_display = $row[7];
	$script_id = $row[8];
	$get_call_launch = $row[9];
	$xferconf_a_dtmf = $row[10];
	$xferconf_a_number = $row[11];
	$xferconf_b_dtmf = $row[12];
	$xferconf_b_number = $row[13];

echo "<br>ΤΡΟΠΟΠΟΙΗΣΗ ΕΓΓΡΑΦΗΣ ΟΜΑΔΩΝ: $row[0]<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=4111>\n";
echo "<input type=hidden name=group_id value=\"$row[0]\">\n";
echo "<center><TABLE width=600 cellspacing=3>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>ID Ομάδας: </td><td align=left><b>$row[0]</b>$NWB#vicidial_inbound_groups-group_id$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ονομα Ομάδας: </td><td align=left><input type=text name=group_name size=30 maxlength=30 value=\"$row[1]\">$NWB#vicidial_inbound_groups-group_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Χρώμα Ομάδας: </td><td align=left bgcolor=\"$row[2]\"><input type=text name=group_color size=7 maxlength=7 value=\"$row[2]\">$NWB#vicidial_inbound_groups-group_color$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ενεργός:</td><td align=left><select size=1 name=active><option>Y</option><option>N</option><option SELECTED>$active</option></select>$NWB#vicidial_inbound_groups-active$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ιστο-σελίδα: </td><td align=left><input type=text name=web_form_address size=50 maxlength=255 value=\"$web_form_address\">$NWB#vicidial_inbound_groups-web_form_address$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>ΦΩΝΗΤΙΚΟ ΤΑΧΥΔΡΟΜΕΙΟ: </td><td align=left><input type=text name=voicemail_ext size=10 maxlength=10 value=\"$voicemail_ext\">$NWB#vicidial_inbound_groups-voicemail_ext$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Επόμενη Κλήση Χρήστη: </td><td align=left><select size=1 name=next_agent_call><option >random</option><option>oldest_call_start</option><option>oldest_call_finish</option><option>overall_user_level</option><option SELECTED>$next_agent_call</option></select>$NWB#vicidial_inbound_groups-next_agent_call$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Οθόνη Μπροστινού: </td><td align=left><select size=1 name=fronter_display><option>Y</option><option>N</option><option SELECTED>$fronter_display</option></select>$NWB#vicidial_inbound_groups-fronter_display$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right><a href=\"$PHP_SELF?ADD=3111111&script_id=$script_id\">Script</a>: </td><td align=left><select size=1 name=script_id>\n";
echo "$scripts_list";
echo "<option selected value=\"$script_id\">$script_id - $scriptname_list[$script_id]</option>\n";
echo "</select>$NWB#vicidial_inbound_groups-ingroup_script$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Πάρτε την έναρξη κλήσης: </td><td align=left><select size=1 name=get_call_launch><option selected>NONE</option><option>SCRIPT</option><option>WEBFORM</option><option selected>$get_call_launch</option></select>$NWB#vicidial_inbound_groups-get_call_launch$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Μεταφορά- Conf DTMF 1: </td><td align=left><input type=text name=xferconf_a_dtmf size=20 maxlength=50 value=\"$xferconf_a_dtmf\">$NWB#vicidial_inbound_groups-xferconf_a_dtmf$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Μεταφορά- Conf αριθμός 1: </td><td align=left><input type=text name=xferconf_a_number size=20 maxlength=50 value=\"$xferconf_a_number\">$NWB#vicidial_inbound_groups-xferconf_a_dtmf$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Μεταφορά- Conf DTMF 2: </td><td align=left><input type=text name=xferconf_b_dtmf size=20 maxlength=50 value=\"$xferconf_b_dtmf\">$NWB#vicidial_inbound_groups-xferconf_a_dtmf$NWE</td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=right>Μεταφορά- Conf αριθμός 2: </td><td align=left><input type=text name=xferconf_b_number size=20 maxlength=50 value=\"$xferconf_b_number\">$NWB#vicidial_inbound_groups-xferconf_a_dtmf$NWE</td></tr>\n";


echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center>\n";

echo "</table></center><br>\n";

echo "<center><b>\n";

if ($LOGdelete_ingroups > 0)
	{
	echo "<br><br><a href=\"$PHP_SELF?ADD=5111&group_id=$group_id\">ΔΙΑΓΡΑΨΤΕ ΑΥΤΟΝ ΤΟΝ ΣΤΗΝ-ΟΜΑΔΑ</a>\n";
	}

}



######################
# ADD=31111 modify remote agents info in the system
######################

if ($ADD==31111)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_remote_agents where remote_agent_id='$remote_agent_id';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$remote_agent_id =	$row[0];
	$user_start =		$row[1];
	$number_of_lines =	$row[2];
	$server_ip =		$row[3];
	$conf_exten =		$row[4];
	$status =			$row[5];
	$campaign_id =		$row[6];

echo "<br>ΤΡΟΠΟΠΟΙΗΣΗ ΚΑΤΑΧΩΡΗΣΗΣ ΑΠΟΜΑΚΡΥΣΜΕΝΩΝ ΧΡΗΣΤΩΝ: $row[0]<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=41111>\n";
echo "<input type=hidden name=remote_agent_id value=\"$row[0]\">\n";
echo "<center><TABLE width=600 cellspacing=3>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>ID Χρήστη Ξεκίνημα: </td><td align=left><input type=text name=user_start size=6 maxlength=6 value=\"$user_start\"> (μόνο αριθμοί, incremented)$NWB#vicidial_remote_agents-user_start$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Αριθμός Γραμμών: </td><td align=left><input type=text name=number_of_lines size=3 maxlength=3 value=\"$number_of_lines\"> (μόνο αριθμοί)$NWB#vicidial_remote_agents-number_of_lines$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>IP Διακομιστή: </td><td align=left><select size=1 name=server_ip>\n";
echo "$servers_list";
echo "<option SELECTED>$row[3]</option>\n";
echo "</select>$NWB#vicidial_remote_agents-server_ip$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Εξωτερική Τηλ. Σύνδεση: </td><td align=left><input type=text name=conf_exten size=20 maxlength=20 value=\"$conf_exten\"> ()$NWB#vicidial_remote_agents-conf_exten$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Κατάσταση:</td><td align=left><select size=1 name=status><option SELECTED>ΕΝΕΡΓΑ</option><option>INACTIVE</option><option SELECTED>$status</option></select>$NWB#vicidial_remote_agents-status$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Εκστρατείας: </td><td align=left><select size=1 name=campaign_id>\n";
echo "$campaigns_list";
echo "<option SELECTED>$campaign_id</option>\n";
echo "</select>$NWB#vicidial_remote_agents-campaign_id$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Εισερχόμενες Ομάδες: </td><td align=left>\n";
echo "$groups_list";
echo "$NWB#vicidial_remote_agents-closer_campaigns$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center>\n";
echo "ΣΗΜΕΙΩΣΗ: Μπορεί να διαρκέσει και 30 δευτερόλεπτα για να καταχωρηθούν οι αλλαγές της οθόνης\n";


if ($LOGdelete_remote_agents > 0)
	{
	echo "<br><br><a href=\"$PHP_SELF?ADD=51111&remote_agent_id=$remote_agent_id\">ΔΙΑΓΡΑΨΤΕ ΑΥΤΟΝ ΤΟΝ ΜΑΚΡΙΝΟ ΠΡΑΚΤΟΡΑ</a>\n";
	}

}


######################
# ADD=311111 modify user group info in the system
######################

if ($ADD==311111)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_user_groups where user_group='$user_group';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$user_group =		$row[0];
	$group_name =		$row[1];
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

echo "<br>ΤΡΟΠΟΠΟΙΗΣΗ ΚΑΤΑΧΩΡΗΣΗΣ ΟΜΑΔΑΣ ΧΡΗΣΤΩΝ<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=411111>\n";
echo "<input type=hidden name=OLDuser_group value=\"$user_group\">\n";
echo "<center><TABLE width=600 cellspacing=3>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ομάδα:</td><td align=left><input type=text name=user_group size=15 maxlength=20 value=\"$user_group\"> (όχι κενά ή στίξη)$NWB#vicidial_user_groups-user_group$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Περιγραφή:</td><td align=left><input type=text name=group_name size=40 maxlength=40 value=\"$group_name\"> (περιγραφή ομάδας)$NWB#vicidial_user_groups-group_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center>\n";

if ($LOGdelete_user_groups > 0)
	{
	echo "<br><br><a href=\"$PHP_SELF?ADD=511111&user_group=$user_group\">ΔΙΑΓΡΑΨΤΕ ΑΥΤΟΝ ΤΟΝ ΧΡΗΣΤΗ GROUP</a>\n";
	}

}


######################
# ADD=3111111 modify script info in the system
######################

if ($ADD==3111111)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_scripts where script_id='$script_id';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$script_name =		$row[1];
	$script_comments =	$row[2];
	$script_text =		$row[3];
	$active =			$row[4];
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

echo "<br>ΤΡΟΠΟΠΟΙΗΣΤΕ ένα ΧΕΙΡΟΓΡΑΦΟ<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=4111111>\n";
echo "<input type=hidden name=script_id value=\"$script_id\">\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ταυτότητα χειρογράφων:: </td><td align=left><B>$script_id</B>$NWB#vicidial_scripts-script_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Όνομα χειρογράφων: </td><td align=left><input type=text name=script_name size=40 maxlength=50 value=\"$script_name\"> (τίτλος του χειρογράφου)$NWB#vicidial_scripts-script_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Τα σχόλια χειρογράφων: </td><td align=left><input type=text name=script_comments size=50 maxlength=255 value=\"$script_comments\"> $NWB#vicidial_scripts-script_comments$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ενεργός:</td><td align=left><select size=1 name=active><option SELECTED>Y</option><option>N</option><option selected>$active</option></select>$NWB#vicidial_scripts-active$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Κείμενο χειρογράφων: <BR><BR><B><a href=\"javascript:openNewWindow('$PHP_SELF?ADD=7111111&script_id=$script_id')\">Χειρόγραφο πρόβλεψης</a></B> </td><td align=left><TEXTAREA NAME=script_text ROWS=20 COLS=50>$script_text</TEXTAREA> $NWB#vicidial_scripts-script_text$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center>\n";

if ($LOGdelete_scripts > 0)
	{
	echo "<br><br><a href=\"$PHP_SELF?ADD=5111111&script_id=$script_id\">ΔΙΑΓΡΑΨΤΕ ΑΥΤΟ ΤΟ ΧΕΙΡΟΓΡΑΦΟ</a>\n";
	}

}


######################
# ADD=31111111 modify filter info in the system
######################

if ($ADD==31111111)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_lead_filters where lead_filter_id='$lead_filter_id';";
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$lead_filter_name =		$row[1];
	$lead_filter_comments =	$row[2];
	$lead_filter_sql =		$row[3];
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

echo "<br>ΤΡΟΠΟΠΟΙΗΣΤΕ ένα ΦΙΛΤΡΟ<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=41111111>\n";
echo "<input type=hidden name=lead_filter_id value=\"$lead_filter_id\">\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ταυτότητα φίλτρων:</td><td align=left><B>$lead_filter_id</B>$NWB#vicidial_lead_filters-lead_filter_id$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Όνομα φίλτρων:</td><td align=left><input type=text name=lead_filter_name size=40 maxlength=50 value=\"$lead_filter_name\"> (σύντομη περιγραφή του φίλτρου)$NWB#vicidial_lead_filters-lead_filter_name$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Το φίλτρο σχολιάζει: </td><td align=left><input type=text name=lead_filter_comments size=50 maxlength=255 value=\"$lead_filter_comments\"> $NWB#vicidial_lead_filters-lead_filter_comments$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Φίλτρο SQL:</td><td align=left><TEXTAREA NAME=lead_filter_sql ROWS=20 COLS=50>$lead_filter_sql</TEXTAREA> $NWB#vicidial_lead_filters-lead_filter_sql$NWE</td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=ΕΠΙΒΕΒΑΙΩΣΗ value=ΕΠΙΒΕΒΑΙΩΣΗ></td></tr>\n";
echo "</TABLE></center>\n";

if ($LOGdelete_filters > 0)
	{
	echo "<br><br><a href=\"$PHP_SELF?ADD=51111111&lead_filter_id=$lead_filter_id\">ΔΙΑΓΡΑΨΤΕ ΑΥΤΟ ΤΟ ΦΙΛΤΡΟ</a>\n";
	}

}







######################
# ADD=55 search form
######################

if ($ADD==55)
{
echo "<TABLE><TR><TD>\n";
echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

echo "<br>ΑΝΑΖΗΤΗΣΗ ΧΡΗΣΤΗ<form action=$PHP_SELF method=POST>\n";
echo "<input type=hidden name=ADD value=66>\n";
echo "<center><TABLE width=600 cellspacing=3>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Αριθμός Χρήστη: </td><td align=left><input type=text name=user size=20 maxlength=20></td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Πλήρες Ονομα: </td><td align=left><input type=text name=full_name size=30 maxlength=30></td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Επίπεδο Χρήστη: </td><td align=left><select size=1 name=user_level><option selected>0</option><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option></select></td></tr>\n";
echo "<tr bgcolor=#B6D3FC><td align=right>Ομάδα Χρήστη: </td><td align=left><select size=1 name=user_group>\n";

	$stmt="SELECT * from vicidial_user_groups order by user_group";
	$rslt=mysql_query($stmt, $link);
	$groups_to_print = mysql_num_rows($rslt);
	$o=0;
	$groups_list='';
	while ($groups_to_print > $o) {
		$rowx=mysql_fetch_row($rslt);
		$groups_list .= "<option value=\"$rowx[0]\">$rowx[0] - $rowx[1]</option>\n";
		$o++;
	}
echo "$groups_list</select></td></tr>\n";

echo "<tr bgcolor=#B6D3FC><td align=center colspan=2><input type=submit name=search value=search></td></tr>\n";
echo "</TABLE></center>\n";

}

######################
# ADD=66 user search results
######################

if ($ADD==66)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$SQL = '';
	if ($user) {$SQL .= " user LIKE \"%$user%\" and";}
	if ($full_name) {$SQL .= " full_name LIKE \"%$full_name%\" and";}
	if ($user_level > 0) {$SQL .= " user_level LIKE \"%$user_level%\" and";}
	if ($user_group) {$SQL .= " user_group = '$user_group' and";}
	$SQL = eregi_replace(" and$", "", $SQL);
	if (strlen($SQL)>5) {$SQL = "where $SQL";}

	$stmt="SELECT * from vicidial_users $SQL order by full_name desc;";
#	echo "\n|$stmt|\n";
	$rslt=mysql_query($stmt, $link);
	$people_to_print = mysql_num_rows($rslt);

echo "<br>ΑΝΑΖΗΤΗΣΗ ΑΠΟΤΕΛΕΣΜΑΤΩΝ:\n";
echo "<center><TABLE width=600 cellspacing=0 cellpadding=1>\n";

	$o=0;
	while ($people_to_print > $o) {
		$row=mysql_fetch_row($rslt);
		if (eregi("1$|3$|5$|7$|9$", $o))
			{$bgcolor='bgcolor="#B9CBFD"';} 
		else
			{$bgcolor='bgcolor="#9BB9FB"';}
		echo "<tr $bgcolor><td><font size=1>$row[1]</td><td><font size=1>$row[3]</td><td><font size=1>$row[4]</td><td><font size=1>$row[5]</td>";
		echo "<td><font size=1><a href=\"$PHP_SELF?ADD=3&user=$row[1]\">ΤΡΟΠΟΠΟΙΗΣΗ</a> | <a href=\"./user_stats.php?user=$row[1]\">ΣΤΑΤΙΣΤΙΚΑ</a> | <a href=\"./user_status.php?user=$row[1]\">ΚΑΤΑΣΤΑΣΗ</a> | <a href=\"./AST_agent_time_sheet.php?agent=$row[1]\">TIME</a></td></tr>\n";
		$o++;
	}

echo "</TABLE></center>\n";

}


######################################################################################################
######################################################################################################
#######   8 series, Callback lists
######################################################################################################
######################################################################################################

######################
# ADD=8 find all callbacks on hold by a User
######################
if ($ADD==8)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_callbacks where status IN('ACTIVE','LIVE') and user='$user' order by recipient,status desc,callback_time";
	$rslt=mysql_query($stmt, $link);
	$cb_to_print = mysql_num_rows($rslt);

echo "<br>USER CALLBACK HOLD LISTINGS: $user\n";
$ADD='82';
}

######################
# ADD=81 find all callbacks on hold within a Campaign
######################
if ($ADD==81)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_callbacks where status IN('ACTIVE','LIVE') and campaign_id='$campaign_id' order by recipient,status desc,callback_time";
	$rslt=mysql_query($stmt, $link);
	$cb_to_print = mysql_num_rows($rslt);

echo "<br>CAMPAIGN CALLBACK HOLD LISTINGS: $campaign_id\n";
$ADD='82';
}

######################
# ADD=811 find all callbacks on hold within a List
######################
if ($ADD==811)
{
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_callbacks where status IN('ACTIVE','LIVE') and list_id='$list_id' order by recipient,status desc,callback_time";
	$rslt=mysql_query($stmt, $link);
	$cb_to_print = mysql_num_rows($rslt);

echo "<br>LIST CALLBACK HOLD LISTINGS: $list_id\n";
$ADD='82';
}

######################
# ADD=82 display all callbacks on hold
######################
if ($ADD==82)
{
echo "<TABLE><TR><TD>\n";
echo "<center><TABLE width=600 cellspacing=0 cellpadding=1>\n";
echo "<tr bgcolor=black><td><font size=1 color=white>LEAD</td><td><font size=1 color=white>LIST</td><td><font size=1 color=white>CAMPAIGN</td><td><font size=1 color=white>ENTRY ΗΜΕΡΑ</td><td><font size=1 color=white>CALLBACK ΗΜΕΡΑ</td><td><font size=1 color=white>USER</td><td><font size=1 color=white>RECIPIENT</td><td><font size=1 color=white>ΚΑΤΑΣΤΑΣΗ</td></tr>\n";

	$o=0;
	while ($cb_to_print > $o) {
		$row=mysql_fetch_row($rslt);
		if (eregi("1$|3$|5$|7$|9$", $o))
			{$bgcolor='bgcolor="#B9CBFD"';} 
		else
			{$bgcolor='bgcolor="#9BB9FB"';}
		echo "<tr $bgcolor>";
		echo "<td><font size=1><A HREF=\"admin_modify_lead.php?lead_id=$row[1]\" target=\"_blank\">$row[1]</A></td>";
		echo "<td><font size=1><A HREF=\"$PHP_SELF?ADD=311&list_id=$row[2]\">$row[2]</A></td>";
		echo "<td><font size=1><A HREF=\"$PHP_SELF?ADD=31&campaign_id=$row[3]\">$row[3]</A></td>";
		echo "<td><font size=1>$row[5]</td>";
		echo "<td><font size=1>$row[6]</td>";
		echo "<td><font size=1><A HREF=\"$PHP_SELF?ADD=3&user=$row[8]\">$row[8]</A></td>";
		echo "<td><font size=1>$row[9]</td>";
		echo "<td><font size=1>$row[4]</td>";
		echo "</tr>\n";
		$o++;
	}

echo "</TABLE></center>\n";
}



######################################################################################################
######################################################################################################
#######   0 series, displays and searches
######################################################################################################
######################################################################################################

######################
# ADD=0 display all active users
######################
if ($ADD==0)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_users order by full_name";
	$rslt=mysql_query($stmt, $link);
	$people_to_print = mysql_num_rows($rslt);

echo "<br>ΛΙΣΤΕΣ ΧΡΗΣΤΗ:\n";
echo "<center><TABLE width=600 cellspacing=0 cellpadding=1>\n";

	$o=0;
	while ($people_to_print > $o) {
		$row=mysql_fetch_row($rslt);
		if (eregi("1$|3$|5$|7$|9$", $o))
			{$bgcolor='bgcolor="#B9CBFD"';} 
		else
			{$bgcolor='bgcolor="#9BB9FB"';}
		echo "<tr $bgcolor><td><font size=1>$row[1]</td><td><font size=1>$row[3]</td><td><font size=1>$row[4]</td><td><font size=1>$row[5]</td>";
		echo "<td><font size=1><a href=\"$PHP_SELF?ADD=3&user=$row[1]\">ΤΡΟΠΟΠΟΙΗΣΗ</a> | <a href=\"./user_stats.php?user=$row[1]\">ΣΤΑΤΙΣΤΙΚΑ</a> | <a href=\"./user_status.php?user=$row[1]\">ΚΑΤΑΣΤΑΣΗ</a> | <a href=\"./AST_agent_time_sheet.php?agent=$row[1]\">TIME</a></td></tr>\n";
		$o++;
	}

echo "</TABLE></center>\n";
}

######################
# ADD=10 display all campaigns
######################
if ($ADD==10)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_campaigns order by campaign_id";
	$rslt=mysql_query($stmt, $link);
	$people_to_print = mysql_num_rows($rslt);

echo "<br>ΕΝΤΑΓΜΕΝΕΣ ΕΚΣΤΡΑΤΕΙΕΣ:\n";
echo "<center><TABLE width=600 cellspacing=0 cellpadding=1>\n";

	$o=0;
	while ($people_to_print > $o) {
		$row=mysql_fetch_row($rslt);
		if (eregi("1$|3$|5$|7$|9$", $o))
			{$bgcolor='bgcolor="#B9CBFD"';} 
		else
			{$bgcolor='bgcolor="#9BB9FB"';}
		echo "<tr $bgcolor><td><font size=1><a href=\"$PHP_SELF?ADD=34&campaign_id=$row[0]\">$row[0]</a></td>";
		echo "<td><font size=1> $row[1] </td>";
		echo "<td><font size=1> $row[2]</td>";
		echo "<td><font size=1> $row[3]</td><td><font size=1>$row[4]</td><td><font size=1>$row[5]</td>";
		echo "<td><font size=1> $row[6]</td><td><font size=1>$row[7]</td><td><font size=1> &nbsp;</td>";
		echo "<td><font size=1><a href=\"$PHP_SELF?ADD=31&campaign_id=$row[0]\">ΤΡΟΠΟΠΟΙΗΣΗ</a></td></tr>\n";
		$o++;
	}

echo "</TABLE></center>\n";
}


######################
# ADD=100 display all lists
######################
if ($ADD==100)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_lists order by list_id";
	$rslt=mysql_query($stmt, $link);
	$people_to_print = mysql_num_rows($rslt);

echo "<br>ΕΝΤΑΓΜΕΝΕΣ ΛΙΣΤΕΣ:\n";
echo "<center><TABLE width=600 cellspacing=0 cellpadding=1>\n";

	$o=0;
	while ($people_to_print > $o) {
		$row=mysql_fetch_row($rslt);
		if (eregi("1$|3$|5$|7$|9$", $o))
			{$bgcolor='bgcolor="#B9CBFD"';} 
		else
			{$bgcolor='bgcolor="#9BB9FB"';}
		echo "<tr $bgcolor><td><font size=1>$row[0]</td>";
		echo "<td><font size=1> $row[1]</td>";
		echo "<td><font size=1> $row[2]</td><td><font size=1>$row[4]</td><td><font size=1>$row[5]</td>";
		echo "<td><font size=1> $row[3]</td><td><font size=1>$row[7]</td><td><font size=1> &nbsp;</td>";
		echo "<td><font size=1><a href=\"$PHP_SELF?ADD=311&list_id=$row[0]\">ΤΡΟΠΟΠΟΙΗΣΗ</a></td></tr>\n";
		$o++;
	}

echo "</TABLE></center>\n";
}



######################
# ADD=1000 display all inbound groups
######################
if ($ADD==1000)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_inbound_groups order by group_id";
	$rslt=mysql_query($stmt, $link);
	$people_to_print = mysql_num_rows($rslt);

echo "<br>ΕΝΤΑΓΜΕΝΕΣ ΕΙΣΕΡΧΟΜΕΝΕΣ ΟΜΑΔΕΣ:\n";
echo "<center><TABLE width=600 cellspacing=0 cellpadding=1>\n";

	$o=0;
	while ($people_to_print > $o) {
		$row=mysql_fetch_row($rslt);
		if (eregi("1$|3$|5$|7$|9$", $o))
			{$bgcolor='bgcolor="#B9CBFD"';} 
		else
			{$bgcolor='bgcolor="#9BB9FB"';}
		echo "<tr $bgcolor><td><font size=1>$row[0]</td>";
		echo "<td><font size=1> $row[1]</td>";
		echo "<td><font size=1> $row[3]</td>";
		echo "<td><font size=1> $row[5]</td>";
		echo "<td bgcolor=\"$row[2]\"><font size=1> &nbsp;</td>";
		echo "<td><font size=1><a href=\"$PHP_SELF?ADD=3111&group_id=$row[0]\">ΤΡΟΠΟΠΟΙΗΣΗ</a></td></tr>\n";
		$o++;
	}

echo "</TABLE></center>\n";
}


######################
# ADD=10000 display all remote agents
######################
if ($ADD==10000)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_remote_agents order by server_ip,campaign_id,user_start";
	$rslt=mysql_query($stmt, $link);
	$people_to_print = mysql_num_rows($rslt);

echo "<br>ΕΝΤΑΓΜΕΝΟΙ ΑΠΟΜΑΚΡΥΣΜΕΝΟΙ ΧΡΗΣΤΕΣ:\n";
echo "<center><TABLE width=600 cellspacing=0 cellpadding=1>\n";

	$o=0;
	while ($people_to_print > $o) {
		$row=mysql_fetch_row($rslt);
		if (eregi("1$|3$|5$|7$|9$", $o))
			{$bgcolor='bgcolor="#B9CBFD"';} 
		else
			{$bgcolor='bgcolor="#9BB9FB"';}
		echo "<tr $bgcolor><td><font size=1>$row[1]</td>";
		echo "<td><font size=1> $row[2]</td>";
		echo "<td><font size=1> $row[3]</td>";
		echo "<td><font size=1> $row[4]</td>";
		echo "<td><font size=1> $row[5]</td>";
		echo "<td><font size=1> $row[6]</td>";
		echo "<td><font size=1><a href=\"$PHP_SELF?ADD=31111&remote_agent_id=$row[0]\">ΤΡΟΠΟΠΟΙΗΣΗ</a></td></tr>\n";
		$o++;
	}

echo "</TABLE></center>\n";
}


######################
# ADD=100000 display all user groups
######################
if ($ADD==100000)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_user_groups order by user_group";
	$rslt=mysql_query($stmt, $link);
	$people_to_print = mysql_num_rows($rslt);

echo "<br>ΕΝΤΑΓΜΕΝΕΣ ΟΜΑΔΕΣ ΧΡΗΣΤΗ:\n";
echo "<center><TABLE width=600 cellspacing=0 cellpadding=1>\n";

	$o=0;
	while ($people_to_print > $o) {
		$row=mysql_fetch_row($rslt);
		if (eregi("1$|3$|5$|7$|9$", $o))
			{$bgcolor='bgcolor="#B9CBFD"';} 
		else
			{$bgcolor='bgcolor="#9BB9FB"';}
		echo "<tr $bgcolor><td><font size=1>$row[0]</td>";
		echo "<td><font size=1> $row[1]</td>";
		echo "<td><font size=1><a href=\"$PHP_SELF?ADD=311111&user_group=$row[0]\">ΤΡΟΠΟΠΟΙΗΣΗ</a></td></tr>\n";
		$o++;
	}

echo "</TABLE></center>\n";
}


######################
# ADD=1000000 display all scripts
######################
if ($ADD==1000000)
{
echo "<TABLE><TR><TD>\n";
	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_scripts order by script_id";
	$rslt=mysql_query($stmt, $link);
	$people_to_print = mysql_num_rows($rslt);

echo "<br>ΧΕΙΡΟΓΡΑΦΑ ΑΠΟΨΗΣ:\n";
echo "<center><TABLE width=600 cellspacing=0 cellpadding=1>\n";

	$o=0;
	while ($people_to_print > $o) {
		$row=mysql_fetch_row($rslt);
		if (eregi("1$|3$|5$|7$|9$", $o))
			{$bgcolor='bgcolor="#B9CBFD"';} 
		else
			{$bgcolor='bgcolor="#9BB9FB"';}
		echo "<tr $bgcolor><td><font size=1>$row[0]</td>";
		echo "<td><font size=1> $row[1]</td>";
		echo "<td><font size=1><a href=\"$PHP_SELF?ADD=3111111&script_id=$row[0]\">ΤΡΟΠΟΠΟΙΗΣΗ</a></td></tr>\n";
		$o++;
	}

echo "</TABLE></center>\n";
}


######################
# ADD=10000000 display all filters
######################
if ($ADD==10000000)
{
echo "<TABLE><TR><TD>\n";

	echo "<FONT FACE=\"ARIAL,HELVETICA\" COLOR=BLACK SIZE=2>";

	$stmt="SELECT * from vicidial_lead_filters order by lead_filter_id";
	$rslt=mysql_query($stmt, $link);
	$filters_to_print = mysql_num_rows($rslt);

echo "<br>ΛΙΣΤΕΣ ΦΙΛΤΡΩΝ ΜΟΛΥΒΔΟΥ:\n";
echo "<center><TABLE width=600 cellspacing=0 cellpadding=1>\n";

	$o=0;
	while ($filters_to_print > $o) {
		$row=mysql_fetch_row($rslt);
		if (eregi("1$|3$|5$|7$|9$", $o))
			{$bgcolor='bgcolor="#B9CBFD"';} 
		else
			{$bgcolor='bgcolor="#9BB9FB"';}
		echo "<tr $bgcolor><td><font size=1>$row[0]</td>";
		echo "<td><font size=1> $row[1]</td>";
		echo "<td><font size=1><a href=\"$PHP_SELF?ADD=31111111&lead_filter_id=$row[0]\">ΤΡΟΠΟΠΟΙΗΣΗ</a></td></tr>\n";
		$o++;
	}

echo "</TABLE></center>\n";
}




echo "</TD></TR></TABLE></center>\n";

$ENDtime = date("U");

$RUNtime = ($ENDtime - $STARTtime);

echo "\n\n\n<br><br><br>\n\n";


echo "<font size=0>\n\n\n<br><br><br>\nδιαδικασία που τρέχει: $RUNtime seconds";
echo " &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ΕΚΔΟΣΗ: $version";
echo " &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ΔΗΜΙΟΥΡΓΙΑ: $build</font>\n";


?>


</TD></TR><TABLE>
</body>
</html>

<?
	
exit; 

?>
