<?
### inbound_popup.php

### This script is designed to open up when a live_inbound call comes in giving the user
###   options of what to do with the call or options to lookup the callerID on various web sites
### This script depends on the server_ip being sent and also needs to have a valid user/pass from the vicidial_users table
### 
### required variables:
###  - $server_ip
###  - $session_name
###  - $uniqueid - ('1234567890.123456',...)
###  - $user
###  - $pass
### optional variables:
###  - $format - ('text','debug')
###  - $vmail_box - ('101','1234',...)
###  - $exten - ('cc101','testphone','49-1','1234','913125551212',...)
###  - $ext_context - ('default','demo',...)
###  - $ext_priority - ('1','2',...)
###  - $voicemail_dump_exten - ('85026666666666')
###  - $local_web_callerID_URL_enc - ( rawurlencoded custom callerid lookup URL)
### 

# changes
# 50428-1500 First build of script display only
# 50429-1241 some formatting, hangup and Vmail redirect, 30s timeout on actions, and CID web lookup links
# 50503-1244 added session_name checking for extra security
# 50711-1203 removed HTTP authentication in favor of user/pass vars
#

require("dbconnect.php");

#require_once("htglobalize.php");

### If you have globals turned off uncomment these lines
$user=$_GET["user"];					if (!$user) {$user=$_POST["user"];}
$pass=$_GET["pass"];					if (!$pass) {$pass=$_POST["pass"];}
$server_ip=$_GET["server_ip"];			if (!$server_ip) {$server_ip=$_POST["server_ip"];}
$session_name=$_GET["session_name"];	if (!$session_name) {$session_name=$_POST["session_name"];}
$uniqueid=$_GET["uniqueid"];			if (!$uniqueid) {$uniqueid=$_POST["uniqueid"];}
$format=$_GET["format"];				if (!$format) {$format=$_POST["format"];}
$exten=$_GET["exten"];					if (!$exten) {$exten=$_POST["exten"];}
$vmail_box=$_GET["vmail_box"];			if (!$vmail_box) {$vmail_box=$_POST["vmail_box"];}
$ext_context=$_GET["ext_context"];		if (!$ext_context) {$ext_context=$_POST["ext_context"];}
$ext_priority=$_GET["ext_priority"];	if (!$ext_priority) {$ext_priority=$_POST["ext_priority"];}
$voicemail_dump_exten=$_GET["voicemail_dump_exten"];	if (!$voicemail_dump_exten) 
	{$voicemail_dump_exten=$_POST["voicemail_dump_exten"];}
$local_web_callerID_URL_enc=$_GET["local_web_callerID_URL_enc"];	if (!$local_web_callerID_URL_enc) 
	{$local_web_callerID_URL_enc=$_POST["local_web_callerID_URL_enc"];}
	$local_web_callerID_URL = rawurldecode($local_web_callerID_URL_enc);

# default optional vars if not set
if (!$format)	{$format="text";}

$version = '0.0.4';
$build = '50711-1203';
$StarTtime = date("U");
$NOW_DATE = date("Y-m-d");
$NOW_TIME = date("Y-m-d H:i:s");
if (!$query_date) {$query_date = $NOW_DATE;}
$DO = '-1';
if ( (eregi("^Zap",$channel)) and (!eregi("-",$channel)) ) {$channel = "$channel$DO";}

	$stmt="SELECT count(*) from vicidial_users where user='$user' and pass='$pass' and user_level > 0;";
	if ($DB) {echo "|$stmt|\n";}
	$rslt=mysql_query($stmt, $link);
	$row=mysql_fetch_row($rslt);
	$auth=$row[0];

  if( (strlen($user)<2) or (strlen($pass)<2) or (!$auth))
	{
    echo "Unzulässig Benutzername/Kennwort: |$user|$pass|\n";
    exit;
	}
  else
	{

	if( ( (strlen($server_ip)<6) or (!$server_ip) ) or ( (strlen($session_name)<12) or (!$session_name) ) )
		{
		echo "Unzulässig server_ip: |$server_ip|  or  Unzulässig session_name: |$session_name|\n";
		exit;
		}
	else
		{
		$stmt="SELECT count(*) from web_client_sessions where session_name='$session_name' and server_ip='$server_ip';";
		if ($DB) {echo "|$stmt|\n";}
		$rslt=mysql_query($stmt, $link);
		$row=mysql_fetch_row($rslt);
		$SNauth=$row[0];
		  if(!$SNauth)
			{
			echo "Unzulässig session_name: |$session_name|$server_ip|\n";
			exit;
			}
		  else
			{
			# do nothing for now
			}
		}
	}

if ($format=='debug')
{
$forever_stop=0;
$user_abb = "$user$user$user$user";
while ( (strlen($user_abb) > 4) and ($forever_stop < 200) )
	{$user_abb = eregi_replace("^.","",$user_abb);   $forever_stop++;}

echo "<html>\n";
echo "<head>\n";
echo "<!-- VERSION: $version     BAU: $build    UNIQUEID: $uniqueid   server_ip: $server_ip-->\n";
?>
	<script language="Javascript">	
		var server_ip = '<? echo $server_ip ?>';
		var epoch_sec = '<? echo $StarTtime ?>';
		var user_abb = '<? echo $user_abb ?>';
		var vmail_box = '<? echo $vmail_box ?>';
		var ext_context = '<? echo $ext_context ?>';
		var ext_priority = '<? echo $ext_priority ?>';
		var voicemail_dump_exten = '<? echo $voicemail_dump_exten ?>';
		var session_name = '<? echo $session_name ?>';
		var user = '<? echo $user ?>';
		var pass = '<? echo $pass ?>';


// ################################################################################
// Send Hangup command for Live call connected to phone now to Manager
	function livehangup_send_hangup(taskvar) 
		{
		var xmlhttp=false;
		/*@cc_on @*/
		/*@if (@_jscript_version >= 5)
		// JScript gives us Conditional compilation, we can cope with old IE versions.
		// and security blocked creation of the objects.
		 try {
		  xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
		 } catch (e) {
		  try {
		   xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		  } catch (E) {
		   xmlhttp = false;
		  }
		 }
		@end @*/
		if (!xmlhttp && typeof XMLHttpRequest!='undefined')
			{
			xmlhttp = new XMLHttpRequest();
			}
		if (xmlhttp) 
			{ 
			var queryCID = "HLagcP" + epoch_sec + user_abb;
			var hangupvalue = taskvar;
			livehangup_query = "server_ip=" + server_ip + "&session_name=" + session_name + "&user=" + user + "&pass=" + pass + "&ACTION=Hangup&format=text&channel=" + hangupvalue + "&queryCID=" + queryCID;
			xmlhttp.open('POST', 'manager_send.php'); 
			xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');
			xmlhttp.send(livehangup_query); 
			xmlhttp.onreadystatechange = function() 
				{ 
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
					{
					Nactiveext = null;
					Nactiveext = xmlhttp.responseText;
					alert(xmlhttp.responseText);
					}
				}
			delete xmlhttp;
			}
		call_action_link_clear();
		}


// ################################################################################
// Send Redirect command for ringing call to go directly to your voicemail
	function liveredirect_send_vmail(taskvar,taskbox) 
		{
		var xmlhttp=false;
		/*@cc_on @*/
		/*@if (@_jscript_version >= 5)
		// JScript gives us Conditional compilation, we can cope with old IE versions.
		// and security blocked creation of the objects.
		 try {
		  xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
		 } catch (e) {
		  try {
		   xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		  } catch (E) {
		   xmlhttp = false;
		  }
		 }
		@end @*/
		if (!xmlhttp && typeof XMLHttpRequest!='undefined')
			{
			xmlhttp = new XMLHttpRequest();
			}
		if (xmlhttp) 
			{ 
			var queryCID = "RVagcP" + epoch_sec + user_abb;
			var hangupvalue = taskvar;
			var mailboxvalue = taskbox;
			liveredirect_query = "server_ip=" + server_ip + "&session_name=" + session_name + "&user=" + user + "&pass=" + pass + "&ACTION=Redirect&format=text&channel=" + hangupvalue + "&queryCID=" + queryCID + "&exten=" + voicemail_dump_exten + "" + mailboxvalue + "&ext_context=" + ext_context + "&ext_priority=" + ext_priority;
			xmlhttp.open('POST', 'manager_send.php'); 
			xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');
			xmlhttp.send(liveredirect_query); 
			xmlhttp.onreadystatechange = function() 
				{ 
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
					{
					Nactiveext = null;
					Nactiveext = xmlhttp.responseText;
					alert(xmlhttp.responseText);
					}
				}
			delete xmlhttp;
			}
		call_action_link_clear();
		}


// ################################################################################
// timeout to deactivate the call action links after 30 Sekunden
	function link_timeout() 
		{
		window.focus();
		setTimeout("call_action_link_clear()", 30000);
		}

// ################################################################################
// deactivates the call action links
	function call_action_link_clear() 
		{
		document.getElementById("callactions").innerHTML = "";		
		}

	</script>

<?
echo "<title>INBOUND LEBHAFTANRUF";
echo "</title>\n";
echo "</head>\n";
echo "<BODY BGCOLOR=\"#CCC2E0\" marginheight=0 marginwidth=0 leftmargin=0 topmargin=0 onload=\"link_timeout();\">\n";
echo "<CENTER><H2>INBOUND LEBHAFTANRUF</H2>\n";
echo "<B>$NOW_TIME</B><BR><BR>\n";
}


	$MT[0]='';
	$row='';   $rowx='';
	$channel_live=1;
	if (strlen($uniqueid)<9)
	{
	$channel_live=0;
	echo "Uniqueid $uniqueid ist unzulässig\n";
	exit;
	}
	else
	{
	$stmt="SELECT * FROM live_inbound where server_ip = '$server_ip' and uniqueid = '$uniqueid';";
		if ($format=='debug') {echo "\n<!-- $stmt -->";}
	$rslt=mysql_query($stmt, $link);
	$channels_list = mysql_num_rows($rslt);
		if ($channels_list>0)
		{
		$row=mysql_fetch_row($rslt);
#		echo "$LIuniqueid|$LIchannel|$LIcallerid|$LIdatetime|$row[8]|$row[9]|$row[10]|$row[11]|$row[12]|$row[13]|";
#		Zap/73|"V.I.C.I. MARKET" <7275338730>|2005-04-28 14:01:21|7274514936|Inbound direct to Matt|||||
		if ($format=='debug') {echo "\n<!-- $row[0]|$row[1]|$row[2]|$row[3]|$row[4]|$row[5]|$row[6]|$row[7]|$row[8]|$row[9]|$row[10]|$row[11]|$row[12]|$row[13]| -->";}
		echo "<table width=95% cellpadding=1 cellspacing=3>\n";
		echo "<tr bgcolor=\"#DDDDFF\"><td>Führung: </td><td align=left>$row[1]</td></tr>\n";
		echo "<tr bgcolor=\"#DDDDFF\"><td>CallerID: </td><td align=left>$row[3]</td></tr>\n";
		echo "<tr bgcolor=\"#DDDDFF\"><td colspan=2 align=center>\n";

		$phone = eregi_replace(".*\<","",$row[3]);
		$phone = eregi_replace("\>.*","",$phone);
		$NPA = substr($phone, 0, 3);
		$NXX = substr($phone, 3, 3);
		$XXXX = substr($phone, 6, 4);
		$D='-';
		echo "<a href=\"http://www.google.com/search?hl=en&lr=&client=firefox-a&rls=org.mozilla%3Aen-US%3Aofficial_s&q=$NPA+$NXX+$XXXX&btnG=Search\" target=\"_blank\">GOOGLE</a> - \n";
		echo "<a href=\"http://www.anywho.com/qry/wp_rl?npa=$NPA&telephone=$NXX$XXXX\" target=\"_blank\">ANYWHO</a> - \n";
		echo "<a href=\"http://www.switchboard.com/bin/cgirlookup.dll?SR=&MEM=1&LNK=32%3A36&type=BOTH&at=$NPA&e=$NXX&n=$XXXX&search.x=55&search.y=20\" target=\"_blank\">SWITCHBOARD</a> - \n";
		echo "<a href=\"http://yellowpages.superpages.com/listings.jsp?SRC=&STYPE=&PG=L&CB=&C=&N=&E=&T=&S=&Z=&A=727&X=533&P=8730&AXP=$NPA$NXX$XXXX&R=N&PS=15&search=Find+It\" target=\"_blank\">VERIZON</a> - \n";
		echo "<a href=\"http://www.whitepages.com/1014/log_click/search/Reverse_Telefon?npa=$NPA&phone=$NXX$XXXX\" target=\"_blank\">WHITEPAGES</a> - \n";
		echo "<a href=\"http://www.411.com/10742/search/Reverse_Telefon?phone=%28$NPA%29+$NXX$D$XXXX\" target=\"_blank\">411.COM</a> - \n";
		echo "<a href=\"http://www.phonenumber.com/10006/search/Reverse_Telefon?npa=$NPA&phone=$NXX$XXXX\" target=\"_blank\">411.COM</a> - \n";

			$local_web_callerID_QUERY_STRING ='';
			$local_web_callerID_QUERY_STRING.="?callerID_areacode=$NPA";
			$local_web_callerID_QUERY_STRING.="&callerID_prefix=$NXX";
			$local_web_callerID_QUERY_STRING.="&callerID_last4=$XXXX";
			$local_web_callerID_QUERY_STRING.="&callerID_Time=$row[6]";
			$local_web_callerID_QUERY_STRING.="&callerID_Führung=$row[1]";
			$local_web_callerID_QUERY_STRING.="&callerID_uniqueID=$row[0]";
			$local_web_callerID_QUERY_STRING.="&callerID_phone_ext=$row[5]";
			$local_web_callerID_QUERY_STRING.="&callerID_server_ip=$row[2]";
			$local_web_callerID_QUERY_STRING.="&callerID_extension=$row[4]";
			$local_web_callerID_QUERY_STRING.="&callerID_inbound_number=$row[8]";
			$local_web_callerID_QUERY_STRING.="&callerID_comment_a=$row[9]";
			$local_web_callerID_QUERY_STRING.="&callerID_comment_b=$row[10]";
			$local_web_callerID_QUERY_STRING.="&callerID_comment_c=$row[11]";
			$local_web_callerID_QUERY_STRING.="&callerID_comment_d=$row[12]";
			$local_web_callerID_QUERY_STRING.="&callerID_comment_e=$row[13]";
		echo "<a href=\"$local_web_callerID_URL$local_web_callerID_QUERY_STRING\" target=\"_blank\">GEWOHNHEIT</a> - \n";

		echo "</td></tr>\n";
		echo "<tr bgcolor=\"#DDDDFF\"><td>Nummer Gewählt: </td><td align=left>$row[8]</td></tr>\n";
		echo "<tr bgcolor=\"#DDDDFF\"><td>Anmerkungen: </td><td align=left>$row[9]|$row[10]|$row[11]|$row[12]|$row[13]|</td></tr>\n";
		echo "<tr bgcolor=\"#DDDDFF\"><td colspan=2 align=center>\n<span id=\"callactions\">";
		echo "<a href=\"#\" onclick=\"livehangup_send_hangup('$row[1]');return false;\">HÄNGEZUSTAND</a> - \n";
		echo "<a href=\"#\" onclick=\"liveredirect_send_vmail('$row[1]','$vmail_box');return false;\">SENDEN SIE ZU MEINEM VOICEMAIL</a>\n";
		echo "</span></td></tr>\n";
		echo "</table>\n";


		$stmt="UPDATE live_inbound set acknowledged='Y' where server_ip = '$server_ip' and uniqueid = '$uniqueid';";
			if ($format=='debug') {echo "\n<!-- $stmt -->";}
		$rslt=mysql_query($stmt, $link);


		}

	
	}


if ($format=='debug') 
	{
	$ENDtime = date("U");
	$RUNtime = ($ENDtime - $StarTtime);
	echo "\n<!-- Indexlaufzeit: $RUNtime Sekunden -->";
	echo "\n</body>\n</html>\n";
	}
	
exit; 

?>
